---
name: newsletter-mcp
description: Pilote le serveur MCP "newsletter" (Capgemini Innovation Watch & Upcoming Trends) - consulter l'état, ajouter/déplacer/supprimer des articles, gérer la section Capgemini, l'édito, et envoyer la newsletter. À utiliser dès que l'utilisateur veut consulter ou modifier le contenu de la newsletter, ou la générer/envoyer.
---

# Newsletter MCP

Ce skill documente comment piloter le serveur MCP `newsletter`, qui est un thin client passant toutes ses actions par `POST /api/skill` sur le backend FastAPI local.

## Prérequis

- Le serveur MCP `newsletter` est fourni par le plugin `nl` (déclaré dans son `.mcp.json`) : rien à
  enregistrer à la main. Il démarre le backend automatiquement au premier appel s'il ne répond pas.
- Si le serveur MCP n'est pas connecté (premier usage : environnement non installé) ou qu'un appel
  renvoie « Web server injoignable », utiliser le skill `nl:newsletter-server` (installation avec
  accord de l'utilisateur, démarrage, diagnostic), puis `/mcp` pour reconnecter `newsletter`.
- Les clés et réglages (LLM, Gmail, destinataires...) se saisissent dans la configuration du plugin
  (`/plugin` → `nl`), pas dans un fichier du dépôt.

## Séquence recommandée

1. `get_newsletter_state` — toujours commencer par lire l'état courant (numéro, articles, sections).
2. Appliquer les modifications demandées avec un ou plusieurs outils ci-dessous.
3. `render_preview` — régénérer l'aperçu HTML si des modifications manuelles ont été faites hors MCP.
4. Terminer par `send_newsletter` (génère le PDF et envoie par Gmail) ou `screenshot_newsletter` (capture JPEG de vérification) selon la demande.

## Outils disponibles

### État et rendu
- `get_newsletter_state` — état complet : numéro, articles, sections
- `render_preview` — régénère le HTML après modifications manuelles
- `screenshot_newsletter` — capture JPEG pleine page de la newsletter
- `set_newsletter_number(number)` — change le numéro de la newsletter. Si ce numéro a déjà été
  utilisé (une édition a été sauvegardée), elle est rechargée telle quelle, sans recherche RSS.
  Si c'est un numéro inédit, une nouvelle édition démarre (recherche RSS complète).
- `get_newsletter_date(number?)` — date de l'édition courante ou d'une édition existante
- `list_newsletters()` — liste les éditions existantes (numéro, date, titre, édito)
- `get_newsletter_title()` / `set_newsletter_title(title)` — lit / modifie le titre de la newsletter
- `set_newsletter_date(date)` — modifie la date de référence (AAAA-MM-JJ), utilisée pour juger
  de la fraîcheur des articles et affichée dans l'en-tête

### Articles marché
- `fetch_and_add_article(topic, position=-1)` — cherche un article RSS sur un thème (AI, EV, quantum, robotics, cloud, venture, energy, industry) et l'insère
- `search_and_add_article(query, position=-1)` — cherche sur le web (Tavily/DuckDuckGo) et insère
- `add_article_from_url(url, position=-1)` — scrape une URL et insère l'article
- `remove_article(position=None, title_keyword=None)` — supprime par position ou mot-clé
- `move_article(to_position, from_position=None, title_keyword=None)` — déplace un article
- `update_article_summary(summary, position=None, title_keyword=None, section="market")` — modifie le résumé

### Section Capgemini
- `set_capgemini_from_url(url)` — définit l'article Capgemini depuis une URL
- `refresh_capgemini_article()` — recharge depuis le flux RSS Capgemini
- `remove_capgemini_article()` — supprime la section Capgemini

### Édito
- `get_edito()` — lit l'édito actuel et vérifie la signature (« Sincerely yours » / « Patrice »)
- `set_edito(article_title, content)` — crée/remplace l'édito complet
- `update_edito(article_title=None, content=None)` — modifie un champ
- `remove_edito()` — supprime l'édito
- `check_edito_from_email()` — lit Gmail pour trouver l'édito de la semaine

### Actions globales
- `refresh_all_articles()` — recharge tout depuis les flux RSS
- `send_newsletter()` — génère le PDF et envoie par Gmail

## Contraintes importantes

- L'image Capgemini (`/assets/capgemini_square.png`) est fixe et ne doit jamais être modifiée sauf demande explicite.
- Section Reuters (« Keep a look outside ») : `get_reuters_video`, `set_reuters_video`, `update_reuters_video`, `remove_reuters_video`. Pour choisir une vidéo sur reuters.com/video (navigateur requis), utiliser le skill `nl:newsletter-reuters`.
- Toujours confirmer les actions effectuées (numéro de newsletter, article modifié, etc.) après chaque appel.
- Pour rouvrir une édition passée : `set_newsletter_number(number)` avec son numéro suffit — pas
  besoin de `refresh_all_articles` (qui écraserait son contenu par une recherche RSS neuve).
