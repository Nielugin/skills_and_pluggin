---
name: newsletter-server
description: Installe, démarre, arrête, redémarre ou vérifie le serveur de la NL Capgemini Innovation Watch (backend FastAPI + bridge WhatsApp) embarqué dans le plugin nl, de façon non interactive. À utiliser au premier usage du plugin (installation de l'environnement), quand l'utilisateur veut lancer/arrêter le serveur, ou quand le MCP `newsletter` n'est pas connecté ou ne joint pas le backend.
---

# Serveur de la NL

Tout le code de la NL est embarqué dans le plugin ; rien ne dépend d'un dépôt local.

| Emplacement | Contenu |
|---|---|
| `${CLAUDE_PLUGIN_ROOT}/app` | Code (backend, template, bridge WhatsApp, serveur MCP) — lecture seule |
| `${CLAUDE_PLUGIN_ROOT}/scripts/nl.py` | Lanceur (stdlib Python uniquement) |
| `${CLAUDE_PLUGIN_DATA}` | Données de l'utilisateur : `venv/`, `plugin-config.env`, `.env` facultatif, `output/` (éditions, logs), `credentials/`, `whatsapp-service/` (modules npm + session) |

## Lancer le script

Toujours passer `--data` (les variables du plugin ne sont pas exportées dans le shell Bash) :

```bash
"${CLAUDE_PLUGIN_DATA}/venv/bin/python" "${CLAUDE_PLUGIN_ROOT}/scripts/nl.py" status --data "${CLAUDE_PLUGIN_DATA}"
```

Si le venv n'existe pas encore (premier usage), lancer le script avec le Python système (3.10+) :
`py -3` sous Windows, `python3` sous macOS/Linux — vérifier qu'il répond avant (sous Windows,
`python` est souvent un alias du Microsoft Store qui n'exécute rien).

| Action | Effet |
|---|---|
| `start` (défaut) | Vérifie les dépendances, lance le bridge WhatsApp puis le backend, attend que l'API réponde |
| `status` | Indique si backend et bridge sont en ligne (code retour 1 si backend arrêté) |
| `stop` | Arrête backend et bridge (PID mémorisés, sinon PID trouvé via le port) |
| `restart` | `stop` puis `start` |
| `check` | Liste les dépendances manquantes sans rien installer ni lancer |

Options : `--install KEYS` (accord de l'utilisateur, voir ci-dessous), `--no-whatsapp` (backend
seul), `--timeout N` (attente max du backend, défaut 240 s).

## Dépendances manquantes : TOUJOURS demander l'accord avant d'installer

Le script n'installe **jamais** rien de lui-même. Si quelque chose manque, `start` (ou `check`)
n'installe rien, ne lance rien et **sort avec le code 2**. Il affiche alors la liste des manques,
puis une ligne `DEPS_JSON [...]` (champs `key`, `label`, `cmd`, `blocking`).

| key | Quoi | Bloquant |
|---|---|---|
| `venv` | venv du plugin dans `${CLAUDE_PLUGIN_DATA}/venv` + paquets de `app/requirements.txt` | oui |
| `pdf` | Chromium Playwright, seulement si ni Chrome ni Edge ne sont utilisables | non (envoi impossible) |
| `node` | Node.js v18+ pour le bridge WhatsApp (winget sous Windows, sinon installation manuelle) | non |
| `npm` | modules du bridge, installés dans `${CLAUDE_PLUGIN_DATA}/whatsapp-service` | non |

Conduite obligatoire quand le code retour est 2 :

1. Présenter à l'utilisateur ce qui manque, avec la commande d'installation de chaque élément.
2. **Demander son accord** avec `AskUserQuestion` (`multiSelect: true`, une option par `key`
   manquante, en indiquant les éléments bloquants). Ne jamais supposer l'accord.
3. Relancer avec les éléments acceptés : `start --install venv,pdf` (ou `--install all`).
   Si l'utilisateur refuse tout : `start --install none`. Si `venv` est refusé, le démarrage est
   impossible : le dire au lieu de relancer.
4. Laisser au moins 900 000 ms de timeout à la commande d'installation (pip et Chromium sont
   longs). L'installation de Node via winget peut ouvrir une fenêtre UAC à valider.
5. Après la création du venv, demander à l'utilisateur de taper `/mcp` pour reconnecter le serveur
   `newsletter` (il ne pouvait pas démarrer sans le venv).

## Configuration

Les clés (Anthropic/OpenAI, Gmail, destinataires, Tavily, Drive, WhatsApp...) se saisissent dans la
configuration du plugin : `/plugin` → `nl` → configurer (ou `/config`). À chaque session, le hook
`SessionStart` les écrit dans `${CLAUDE_PLUGIN_DATA}/plugin-config.env`. Un `.env` facultatif dans
le même dossier peut compléter (il ne prime jamais sur la configuration du plugin). Après une
modification de configuration, relancer une session puis `restart`.

Si `start` répond « Aucune configuration », demander à l'utilisateur de configurer le plugin puis
d'ouvrir une nouvelle session ; ne jamais lui faire saisir ses clés dans la conversation.

## Conduite à tenir

- `start` est idempotent : sans risque si le serveur tourne déjà. Le lancer au premier plan.
- Le serveur MCP `newsletter` démarre aussi le backend tout seul au premier appel d'outil, si
  l'environnement est installé.
- Si le statut WhatsApp est `qr`, indiquer à l'utilisateur d'ouvrir `<URL backend>/setup/whatsapp`
  pour scanner le QR code.
- En cas d'erreur, lire `${CLAUDE_PLUGIN_DATA}/output/logs/backend.log` (ou `whatsapp.log`) et
  rapporter la cause (clé API manquante, etc.) plutôt que relancer en boucle.
- Une fois le backend en ligne, enchaîner avec le skill `nl:newsletter-mcp` pour piloter le contenu.
