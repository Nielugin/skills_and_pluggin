---
name: "newsletter-weekly"
description: "Orchestre la génération complète d'une édition de la NL Capgemini Innovation Watch : pré-contrôles, numéro, date, agents par topic (config externalisée), agents dédiés Capgemini et Reuters en parallèle, top 10, abstracts, édito."
---

# Newsletter weekly — orchestrateur

Génère une édition de bout en bout avec le MCP `newsletter` et les skills `nl:newsletter-config`, `nl:newsletter-topic-scout`, `nl:newsletter-abstract`, `nl:newsletter-edito` et `nl:newsletter-reuters`. Tous les contenus (abstracts, édito) sont en **anglais**.

**Première action : lire le skill `nl:newsletter-config`.** Il contient la liste des topics et tous les paramètres (articles par NL, plafonds par topic et par site, fenêtre de dates, longueur des abstracts, sources). Rien de tout cela n'est en dur ici : les valeurs entre crochets ci-dessous, comme [max_par_topic], renvoient à cette configuration.

Outils MCP : charger leurs schémas avec ToolSearch avant usage (ils sont différés). Noms : `get_newsletter_state`, `set_newsletter_number`, `set_newsletter_date`, `add_article_from_url`, `remove_article`, `move_article`, `update_article_summary`, `update_edito`, `set_capgemini_from_url`, `refresh_capgemini_article`, `get_reuters_video`, `render_preview`, `screenshot_newsletter`.

## Étape 1 — Pré-contrôles (bloquants)

**Toujours relire l'état dans ce lancement** : ne jamais s'appuyer sur une lecture antérieure de la conversation, l'édition chargée peut avoir changé.

1. `get_newsletter_state` : numéro chargé N et articles présents. Noter les titres et sources de ces articles : ce sont les articles à ne pas redonner.
2. Le MCP ne renvoie ni la date de la NL ni la liste des éditions. Tant qu'un outil `list_editions` ou une date dans l'état n'existe pas :
   - date de l'édition chargée : la lire dans l'en-tête de l'aperçu (`render_preview` puis `screenshot_newsletter`, voir étape 9 pour décoder l'image), ou la demander à l'utilisateur ;
   - dernière édition existante : la demander à l'utilisateur. Ne jamais deviner.
3. Contrôles : la date de l'édition chargée est **strictement antérieure à aujourd'hui** (date réelle via `current_time`) ; la dernière édition existante porte **le numéro N**.
4. Si un contrôle échoue : **s'arrêter**, ne rien modifier, et poser la question via `AskUserQuestion` (reprendre une autre édition, forcer, annuler).

**Attention** : `set_newsletter_number(X)` recharge l'édition X si elle existe déjà (`loaded_existing: true`). Si X n'a jamais été construite (`loaded_existing: false`), il **crée une édition vide datée d'aujourd'hui** (avec recherche RSS). Ne jamais appeler cet outil juste pour « regarder » un numéro.

## Étape 2 — Nouvelle édition

1. `set_newsletter_number(N+1)`. Vérifier `loaded_existing: false`. Si c'est `true`, l'édition existait : s'arrêter et demander.
2. `set_newsletter_date` = **prochain jour de parution** (voir configuration), strictement après aujourd'hui, au format AAAA-MM-JJ, calculé avec la date réelle.
3. `get_newsletter_state` : si la NL a été préremplie (flux RSS) ou contient des articles, **ne pas tout vider : analyser** chaque article (ouvrir la page avec WebFetch). Le supprimer (`remove_article`) s'il remplit au moins un critère : publié hors fenêtre, hors sujet pour un lecteur CTO, doublon, source à cookie wall payant ou illisible, déjà publié dans une édition précédente. Les articles conservés entrent dans le pool avec la mention « déjà dans la NL ». Garder la liste des suppressions avec leur motif pour le point de contrôle. Une édition vide : passer.

## Étape 3 — Agents en parallèle : topics, Capgemini, Reuters

Lancer **dans un seul message, en parallèle** (outil `Agent`, type `general-purpose`) : un agent par topic actif, **un agent Capgemini** et **un agent Reuters**. Les deux derniers (voir « Agent Capgemini » et « Agent Reuters » plus bas) mettent chacun leur section en place pendant que l'orchestrateur classe les articles marché ; ils n'écrivent que dans leur propre section (jamais dans les articles marché ni dans l'édito).

### Agents par topic

Un agent par topic actif de la configuration, avec le skill `nl:newsletter-topic-scout`. Chaque prompt d'agent contient : la clé du topic et son périmètre (copiés de la configuration) ; la date du jour et la date de parution de la NL ; la **fenêtre de dates** (voir ci-dessous) ; la liste des articles à ne pas redonner (articles de l'édition précédente relevés à l'étape 1, plus les articles déjà conservés) ; le nombre maximal de candidats ; l'interdiction d'écrire dans la NL.

**Fenêtre de dates** : les [fenêtre_jours] jours se terminant à la date du jour. La date de parution est dans le futur : ne pas chercher après aujourd'hui. Exemple : NL datée du vendredi 9 octobre, lancement le dimanche 4 octobre → articles du 27 septembre au 4 octobre.

### Agent Capgemini

Prompt : la date du jour, la date de parution, la configuration (topics actifs et leur périmètre, `fenêtre_jours`, `ancienneté_max_article_capgemini_jours`, les 3 sources ordonnées de « Sources de l'article Capgemini » dans `nl:newsletter-config`), la consigne d'utiliser `nl:newsletter-abstract`, et la liste des outils MCP autorisés (`get_newsletter_state`, `set_capgemini_from_url`, `update_article_summary` avec `section="capgemini"`, `refresh_capgemini_article` en dernier recours). Méthode imposée :

1. Parcourir les sources **dans l'ordre** (communiqués de presse, témoignages clients, inside stories). Pour chaque source : lire la page de listing (WebFetch ; si elle est illisible ou vide, WebSearch avec `site:capgemini.com/news/...` pour retrouver les derniers contenus), puis examiner les **8 contenus les plus récents** au plus.
2. **Ouvrir chaque contenu examiné** pour relever sa date de publication réelle et juger son rapport avec les topics actifs. Un contenu est retenu s'il est **récent** (dans la fenêtre de [fenêtre_jours] jours se terminant aujourd'hui) **et en rapport avec au moins un topic actif**. Dès qu'une source en fournit un, **arrêter** : ne pas ouvrir les sources suivantes. S'il y en a plusieurs dans la même source, prendre le plus pertinent (puis le plus récent).
3. Si aucune des 3 sources ne donne de contenu retenu, faire une **seconde passe** dans le même ordre en élargissant à [ancienneté_max_article_capgemini_jours] jours, et marquer le résultat « hors fenêtre ».
4. Si toujours rien : ne **rien** forcer. Essayer `refresh_capgemini_article()` ; si le résultat n'a pas de rapport avec les topics ou est trop ancien, ne pas le garder et le dire dans le rapport.
5. Mettre en place : `set_capgemini_from_url(url)`, puis rédiger l'abstract avec `nl:newsletter-abstract` après lecture complète de la page (communiqué de l'entreprise : factuel, non promotionnel, signaler ce qui n'est pas détaillé : montant, conditions) et l'appliquer avec `update_article_summary(summary, section="capgemini")`.
6. Rapport : titre, URL, source (laquelle des 3), date, topic de rattachement et pourquoi, mention « hors fenêtre » le cas échéant, les 2 meilleurs autres candidats vus, abstract appliqué. Aucune donnée inventée.

### Agent Reuters

Prompt : demander d'appliquer le skill `nl:newsletter-reuters` (parcours de `reuters.com/video` dans Chrome via Claude in Chrome, choix selon les topics de `nl:newsletter-config`, puis `set_reuters_video` avec titre, lien, description et capture), la date de parution de la NL, et de rendre un rapport : titre, lien, topic retenu et pourquoi, vidéos écartées. Il n'écrit que la section Reuters. **Non bloquant** : si Chrome n'est pas connecté ou si la page est bloquée, l'agent s'arrête sans rien contourner et le dit ; l'orchestrateur le signale à l'étape 4 et la section existante reste telle quelle.

## Étape 4 — Pool, classement, sélection

1. Pool = articles conservés à l'étape 2 + candidats des agents ; dédoublonner (même sujet : garder la meilleure source). Un agent qui renvoie peu de candidats est normal (fenêtre courte) : le noter, ne pas combler avec des articles hors fenêtre.
2. Classer par pertinence pour un lecteur CTO / innovation leader : impact stratégique, nouveauté du signal, portée entreprise, solidité de la source (1 à 5 par critère, total sur 20 visible).
3. Retenir les [articles_marché] premiers, avec **max [max_par_topic] par topic** et **max [max_par_site] par site/source**. Si un plafond bloque, passer au suivant du classement. Un article n'a qu'un topic de rattachement (celui de l'agent qui l'a trouvé).
4. Le plus pertinent est en position 1.
5. Signaler explicitement tout article à faible fiabilité (source anonyme, non confirmé, chiffres contradictoires, tribune de fournisseur) et tout article concernant l'éditeur du modèle qui fait tourner ce workflow (Anthropic) : l'utilisateur décide de le garder ou non, avec une alternative proposée.
6. **Point de contrôle utilisateur** : présenter le tableau (rang, titre avec lien, topic, source, date, score), les articles supprimés à l'étape 2 avec leur motif, et les topics peu couverts. Ajouter les rapports des **agents Capgemini et Reuters** (article ou vidéo déjà mis en place, source, date, topic, alternatives, échecs éventuels). Attendre validation ou ajustements avant de peupler ; le remplacement de l'article Capgemini (`set_capgemini_from_url`) ou de la vidéo (`update_reuters_video` / `set_reuters_video`) reste possible à ce stade.

## Étape 5 — Peuplement

Après validation :
- supprimer (`remove_article`) les articles conservés mais non retenus ;
- ajouter les nouveaux avec `add_article_from_url(url, position=-1)` **dans l'ordre du classement** (les appels en parallèle avec position=-1 restent ordonnés) ;
- ordonner avec `move_article` si des articles conservés sont mélangés ;
- vérifier avec `get_newsletter_state` : nombre d'articles et ordre. Les tags de topics renvoyés par le MCP sont approximatifs et sans importance.

## Étape 6 — Abstracts (1 agent par article)

Lancer **un agent par article, en parallèle**, avec le skill `nl:newsletter-abstract` (prompt : titre, source, URL, règles, consigne de lire l'article ; pour un article à faible fiabilité, demander de le dire dans l'abstract). L'orchestrateur applique chaque abstract avec `update_article_summary(summary, position=i)`.

Contrôles avant application : longueur ≤ [abstract_max_mots] ; **les verbes correspondent à l'article** (par exemple « ciblé » n'est pas « détruit ») ; pas de formule « Included because… » ; aucune mention de « CTO » ni d'une autre désignation du lecteur (reformuler l'implication sans nommer personne). Relire soi-même l'article n°1 (utilisé pour l'édito) et vérifier son abstract contre le texte.

## Étape 7 — Édito

Appliquer le skill `nl:newsletter-edito` sur l'article en **position 1** : prise de recul, regard objectif de CTO, du fond et pas du buzz, sans résumer l'article ; trouver un **titre d'édito** (emojis inclus). Proposer le texte à l'utilisateur et attendre son accord, puis enregistrer :
- avec **`update_edito(article_title=<titre de l'édito>, content=<HTML sans le titre>)`** ;
- le **titre de l'édito remplace l'en-tête** de l'édito dans la NL : ne jamais y mettre « Capgemini Innovation Watch & Upcoming Trends #N », et ne pas répéter le titre dans le corps ;
- `set_edito` rejette actuellement tout appel (erreur `unexpected keyword argument 'closing'`, décalage entre le serveur MCP et le backend) : utiliser `update_edito`.

## Étape 8 — Contrôle des sections Capgemini et Reuters

Ces sections sont mises en place **à l'étape 3** par leurs agents dédiés ; ici on ne les refait pas, on contrôle.

1. Capgemini : relire le rapport de l'agent et vérifier avec `get_newsletter_state` que la section est présente. Si l'article est « hors fenêtre » ou date de plus de [ancienneté_max_article_capgemini_jours] jours, le signaler à l'utilisateur (il peut le garder). Si l'agent n'a rien trouvé, demander une URL à l'utilisateur et utiliser `set_capgemini_from_url(url)`, puis refaire l'abstract avec `nl:newsletter-abstract` et `update_article_summary(summary, section="capgemini")`.
2. Reuters : `get_reuters_video`, vérifier titre, lien, description et image. Si l'agent a échoué, proposer à l'utilisateur de relancer le skill `nl:newsletter-reuters` ou de fournir un lien et un titre.
3. Si l'utilisateur a demandé un remplacement au point de contrôle de l'étape 4, l'appliquer ici.

## Étape 9 — Vérification finale

1. `get_newsletter_state` : numéro, nombre d'articles, section Capgemini présente. L'état ne renvoie pas l'édito ni la date : les contrôler sur l'aperçu.
2. `render_preview` puis `screenshot_newsletter`. La capture revient en JSON avec une image base64 (`image_b64`), trop grosse pour être lue directement : le fichier de résultat est enregistré sur disque ; en extraire l'image avec Python (regex sur la plus longue chaîne base64, décodage, enregistrement en JPEG), puis la découper en tranches d'environ 1 400 pixels de haut avec Pillow et les ouvrir avec Read.
3. Contrôler : date en en-tête, titre de l'édito, absence de doublon de titre, 10 articles avec abstracts, section Capgemini. Contrôler aussi la section « Keep a look outside » (vidéo Reuters : titre, lien, description, image) : elle ne doit pas être celle de la semaine précédente.
4. Résumer en quelques lignes ce qui est prêt. **Ne jamais appeler `send_newsletter` sans demande explicite.**

## Règles transverses

- Aucun article, chiffre ou fait inventé : tout vient d'une page réellement lue.
- Fenêtre de dates stricte pour les articles marché. Pour l'article Capgemini : fenêtre d'abord, élargissement signalé ensuite.
- Les agents Capgemini et Reuters ne touchent que leur section ; aucun contournement de protection anti-bot (voir `nl:newsletter-reuters`).
- Un agent qui échoue ou renvoie 0 candidat : le signaler, ne pas combler avec du contenu inventé.
- Les topics, thèmes et seuils viennent de `nl:newsletter-config`, jamais de ce skill.