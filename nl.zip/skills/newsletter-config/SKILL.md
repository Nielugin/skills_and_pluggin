---
name: "newsletter-config"
description: "Configuration partagée du workflow NL Capgemini Innovation Watch : liste des topics, plafonds, fenêtre de dates, langue, sources. Lue par newsletter-weekly, newsletter-topic-scout et les agents Capgemini / Reuters."
---

# Configuration du workflow newsletter

Source unique de vérité : les autres skills (`nl:newsletter-weekly`, `nl:newsletter-topic-scout`, `nl:newsletter-abstract`) ne contiennent aucune liste de topics ni aucun seuil en dur, ils renvoient ici. Pour ajouter un topic, ajouter une ligne dans le tableau ci-dessous : aucun autre skill n'est à modifier.

## Topics

Un agent de recherche est lancé par ligne du tableau. La colonne « périmètre » est transmise à l'agent pour cadrer ses recherches. La colonne « MCP » indique si l'outil `fetch_and_add_article` du serveur MCP connaît ce topic (information seulement : le workflow ajoute les articles par URL).

| clé | actif | périmètre | MCP |
|---|---|---|---|
| AI | oui | modèles frontier, agents, outils IA pour l'entreprise, régulation IA, plateformes | oui |
| EV | oui | véhicules électriques, batteries, recharge, conduite autonome, chaîne d'approvisionnement automobile | oui |
| quantum | oui | calcul quantique, communication et capteurs quantiques, cryptographie post-quantique, financements et feuilles de route | oui |
| robotics | oui | robots humanoïdes et industriels, IA embarquée, déploiements en entrepôt ou usine, financements | oui |
| cloud | oui | hyperscalers, cloud souverain, infrastructure IA et data centers, cybersécurité cloud, pannes, réglementation UE | oui |
| venture | oui | levées de fonds significatives, M&A, IPO, valorisations dans la tech et la deep tech | oui |
| energy | oui | nucléaire et SMR, renouvelables, stockage, réseau, énergie pour data centers IA, hydrogène | oui |
| industry | oui | industrie 4.0, jumeaux numériques, semi-conducteurs, supply chain, cybersécurité industrielle, politiques industrielles et souveraineté technologique | oui |
| aerospace | oui | lanceurs, satellites et constellations, observation de la Terre, aéronautique civile et défense, agences spatiales et marchés publics | non |

Pour désactiver un topic sans le supprimer, passer « actif » à « non ».

## Paramètres

| paramètre | valeur |
|---|---|
| articles_marché | 10 |
| max_par_topic | 4 |
| max_par_site | 2 |
| candidats_par_topic_max | 6 |
| fenêtre_jours | 7 |
| jour_de_parution | vendredi |
| abstract_max_mots | 80 |
| langue_contenus | anglais (abstracts, édito) |
| ancienneté_max_article_capgemini_jours | 30 (au-delà, signaler à l'utilisateur) |

## Sources

Privilégiées (lisibles dans l'UE, refus des cookies gratuit) : TechCrunch, The Verge, Ars Technica, The Register, MIT Technology Review, VentureBeat, Wired, Engadget, ZDNET, IEEE Spectrum, The Hacker News, The Next Web, blogs officiels d'entreprises et de laboratoires, arXiv, sites de régulateurs et d'agences, médias spécialisés sans paywall (The Quantum Insider, Data Center Knowledge, Spaceflight Now).

À éviter (cookie wall payant dans l'UE) : The Washington Post, Daily Mail, The Sun, The Independent, Mirror, Daily Express.

Sites souvent inaccessibles à la lecture automatique (prévoir une source alternative) : Business Insider, SpaceNews, Satellite Today, Space.com.

## Sources de l'article Capgemini

Pages de listing à parcourir **dans cet ordre** pour trouver l'article Capgemini de la NL (la première source qui offre un article récent et en rapport avec un topic actif l'emporte, on ne passe à la suivante que s'il n'y en a pas) :

| ordre | source | URL |
|---|---|---|
| 1 | Communiqués de presse | https://www.capgemini.com/news/press-releases/ |
| 2 | Témoignages clients | https://www.capgemini.com/news/client-stories/ |
| 3 | Inside stories | https://www.capgemini.com/news/inside-stories/ |

Paramètres de sélection : voir `fenêtre_jours` et `ancienneté_max_article_capgemini_jours` ci-dessus (même fenêtre que les articles marché en premier choix ; élargissement jusqu'à l'ancienneté max en second choix, signalé à l'utilisateur). « En rapport avec les topics » = lien net avec le périmètre d'au moins un topic actif du tableau « Topics ».

## Calendrier

La date de la NL est le prochain « jour_de_parution » strictement après la date du jour, calculé avec la date réelle (outil `current_time`).