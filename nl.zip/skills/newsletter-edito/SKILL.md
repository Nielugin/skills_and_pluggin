---
name: "newsletter-edito"
description: "Rédige l'édito de la newsletter Capgemini Innovation Watch (signé Patrice Duboé) à partir d'un article de la NL, avec son propre titre et un regard critique pouvant contredire l'article."
---

# Édito — Capgemini Innovation Watch & Upcoming Trends

Rédige l'édito hebdomadaire signé **Patrice Duboé** (Executive Vice President, CTIO Global AeroSpace & Defense / CTIO Southern & Central Europe), à partir d'un article sélectionné dans la newsletter.

## Étape 0 — Choisir et comprendre l'article

Si l'utilisateur n'a pas désigné d'article, prendre l'article en position 1 de la NL courante (`get_newsletter_state`). **Toujours récupérer et lire le contenu réel de l'article** (`WebFetch`, ou `WebSearch` si le fetch échoue) avant d'écrire : l'édito doit contenir des chiffres et détails exacts, jamais des approximations. Ne pas se contenter de l'abstract ni du rapport d'un autre agent.

Si l'article a moins de 2 faits chiffrés vérifiables, le signaler à l'utilisateur et proposer un autre article : cet édito repose sur la précision factuelle.

Pour situer l'article, faire aussi 1 à 3 recherches (`WebSearch`) sur la réalité du marché ou la tendance de fond autour du sujet : données récentes, chiffres concurrents, précédents, positions contraires. C'est ce qui permet de prendre position à bon escient (voir ci-dessous).

## Le fond : un regard de CTO, pas un résumé

L'édito ne résume pas l'article. Il en tire un regard objectif et pris avec du recul : ce que l'article révèle vraiment, ce qu'il ne dit pas, ce qu'un décideur technique doit en retenir. Du fond, pas du buzz.

**Il peut se poser en faux par rapport à l'article** : confronter ses affirmations à la réalité du marché, aux tendances de fond, aux ordres de grandeur et aux précédents, et dire quand une thèse est surestimée, incomplète ou contredite par les faits. Il nomme aussi l'intérêt de la source quand elle défend une thèse (un éditeur de sécurité qui qualifie une menace décrit aussi sa catégorie de produits).

Garde-fous du contrepoint :
- il repose sur un **fait vérifié** (chiffre, tendance, événement, source identifiable), jamais sur une posture ni sur une intuition ;
- le désaccord est assumé mais mesuré : dire ce que l'article a raison de pointer avant de nuancer ou de contredire ;
- si l'article est solide, le dire : le contrepoint n'est pas obligatoire, il est là quand la réalité du marché l'impose ;
- ne jamais prêter à l'article une affirmation qu'il ne fait pas pour la réfuter.

## Structure (à respecter strictement)

```
TITRE (va dans article_title, PAS dans le corps) : [emoji(s)] [accroche courte, souvent avec deux-points ou jeu de mots]

[Phrase d'ouverture : le fait principal, avec le chiffre clé en gras.]

[emoji] **[Accroche en gras.]** [1-2 phrases de développement.]

[emoji] **[Accroche en gras.]** [1-2 phrases de développement.]

[emoji] **[Accroche en gras.]** [1-2 phrases de développement.]

[emoji] **[Accroche en gras.]** [1-2 phrases de développement.]

[Chute : une observation ou un trait d'humour sec, ancré dans le sujet précis de l'article.]

Enjoy your [variante] reading[,.]
Sincerely yours,
Patrice
```

- **Anglais uniquement.** Registre professionnel, direct, jamais promotionnel.
- **4 à 5 points** dans le corps. En dessous c'est maigre, au-dessus ça devient une liste de courses.
- **Longueur cible : 200-280 mots** au total.
- **Le titre de l'édito est enregistré dans `article_title` et remplace l'en-tête de l'édito dans la NL.** Il ne doit pas figurer dans le corps, et ne doit jamais être le nom de la newsletter ni son numéro.
- **L'édito se termine TOUJOURS par les deux lignes « Sincerely yours, » puis « Patrice ».** Les écrire explicitement dans le HTML : l'outil ne les ajoute pas.

## Ton

La signature de cet édito, c'est le **regard de CTO** : pas de résumé d'actualité, mais l'angle stratégique que le lecteur n'aurait pas vu seul. Chaque point doit apporter une information ou une lecture, pas du remplissage.

Marqueurs récurrents à réutiliser :

- Formules de bascule : « Bottom line: », « Key takeaway: », « The concern is real: », « But key nuance: », « Translation: »
- Analogies concrètes tirées du monde physique (transport, bâtiment, aéronautique, finance classique) plutôt que du jargon tech
- Références aux implications entreprise : souveraineté, dépendance fournisseur, résilience opérationnelle, contrôle de la donnée
- Nuance systématique : quand un acteur pousse une thèse, nommer son intérêt (« Karp is also preaching for his own church ») et la confronter aux faits du marché, quitte à la contredire (« The market data says otherwise: … », « That is the pitch; the trend line points the other way »)
- Ordre de grandeur remis en perspective (« 10 gigawatts is roughly the output of 10 nuclear reactors »)

## Emojis

- 1 à 2 dans le titre, 1 par point du corps.
- Choisis pour leur **rapport littéral au contenu du point** : 🔌 pour l'énergie, 🛰️ pour le spatial, 💰 pour le financement, 🔁 pour la circularité, 🏠 pour l'infrastructure possédée, 🔐 pour la sécurité, 🌍 pour la géopolitique, 💡 pour l'angle mort révélé.
- Jamais d'emoji décoratif ou générique (🚀 ✨ 🔥 en ouverture creuse).

## La chute — le point le plus délicat

Trait d'humour **sec, court, spécifique à cet article**. Elle doit pouvoir se lire comme une remarque lâchée en réunion par quelqu'un qui connaît le dossier.

Ce qui marche :
- Rapprochement avec une pratique ancienne et banale qui démystifie la nouveauté : « Nvidia financing the customer who then spends that money on Nvidia chips has a name in accounting: vendor financing. Car dealerships have run the same play for decades — Nvidia just added a few zeros and moved it to Ohio. »
- Litote sur un détail concret de l'article : « batteries that refuse to retire », « if a pencil can defeat AI, imagine what a motivated attacker could do »
- Ironie douce sur un décalage réel : « definitely not something you want roaming around without a badge »
- Un fait de l'article retourné contre lui-même : « The employee did delete the secret from the issue. GitHub kept a copy in the edit history, the one component in this story that retained data exactly as designed. »

**À proscrire absolument** — la punchline générique d'IA générative :
- Le champ lexical de la ruée vers l'or : pioches, pelles, chercheurs d'or, « selling shovels »
- « as long as the music doesn't stop », « the house always wins », « what could possibly go wrong »
- Les triplés rythmiques en cascade (« chipmaker, landlord, loan officer. Next stop, real estate agent. »)
- « Welcome to the future », « one thing is certain », « only time will tell »
- L'humour qui plane au-dessus du sujet sans s'accrocher à un fait précis de l'article

Test de validation : si la chute pourrait être recollée sur un autre édito d'un autre sujet, elle est trop générique — la réécrire.

## Formule de clôture

Toujours « Enjoy your ... reading », avec un qualificatif qui fait un clin d'œil au sujet ou à la saison. Variantes déjà utilisées, à ne pas répéter deux semaines de suite : safe human, cool, safe, slow, human, safe non agentic, cool sunny summer, safely supervised. La NL #612 a utilisé « safe » : ne pas la réutiliser pour #613.

Pour un sujet cybersécurité → « safe ». Pour un sujet agents autonomes → « safe human » ou « safe non agentic ». Pour l'été → une variante saisonnière.

La formule est suivie, sans exception, de :

```
Sincerely yours,
Patrice
```

## Format de sortie

L'édito est enregistré avec **`update_edito`** du MCP newsletter (`set_edito` rejette actuellement tout appel à cause d'un décalage de paramètre `closing` entre le serveur MCP et le backend). Le corps est en **HTML**, **sans le titre** :

```html
<p><span style="mso-fareast-language:EN-US">[Ouverture avec <b>chiffres clés</b>]</span></p>
<p><span style='font-family:"Segoe UI Emoji",sans-serif;mso-fareast-language:EN-US'>[emoji]</span><span style="mso-fareast-language:EN-US"> <b>[Accroche]</b> [développement]</span></p>
<p><span style="mso-fareast-language:EN-US">[Chute]</span></p>
<p><span style="mso-fareast-language:EN-US">Enjoy your [variante] reading.</span></p>
<p><span style="mso-fareast-language:EN-US">Sincerely yours,</span></p>
<p><span style="mso-fareast-language:EN-US">Patrice</span></p>
```

Les emojis sont enveloppés dans le span `Segoe UI Emoji` pour un rendu correct dans Outlook.

Paramètres de `update_edito` :
- `article_title` : le **titre de l'édito**, emojis compris (par exemple « 🔑🗑️ Nobody Hacked Azure: Someone Pasted the Key »). Jamais le nom de la newsletter ni son numéro.
- `content` : le HTML ci-dessus, sans le titre.
- `closing` : ne pas le passer.

## Avant d'enregistrer

1. Vérifier chaque chiffre contre la source (page lue par soi-même), y compris ceux du contrepoint.
2. Si l'édito contredit ou nuance l'article : le contrepoint repose sur un fait vérifié et ne prête pas à l'article une affirmation qu'il ne fait pas.
3. Relire la chute : est-elle spécifique à CET article ?
4. Vérifier que la formule « Enjoy your ... » diffère de la semaine précédente.
5. Vérifier que le texte se termine bien par « Sincerely yours, » puis « Patrice ».
6. Vérifier que le titre est dans `article_title` et absent du corps.
7. Proposer l'édito en texte lisible à l'utilisateur avant de l'écrire dans la NL, sauf s'il a demandé de l'appliquer directement.
8. Après enregistrement : `render_preview` et contrôle visuel de l'en-tête de l'édito.