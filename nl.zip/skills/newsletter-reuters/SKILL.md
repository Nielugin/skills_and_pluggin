---
name: "newsletter-reuters"
description: "Remplit la section « Keep a look outside » (Reuters) de la NL : parcourt reuters.com/video dans le vrai Chrome de l'utilisateur (Claude in Chrome), choisit une vidéo en rapport avec les topics de la NL, puis renseigne titre, lien, description et capture. Sert aussi à lire, modifier ou supprimer cette section."
---

# Section Reuters « Keep a look outside »

Une vidéo Reuters par édition : un titre, un lien, une description courte et une capture de la vidéo.

## Pourquoi un vrai Chrome

`reuters.com/video` renvoie **HTTP 401** à tout navigateur automatisé (Playwright headless ou non) : la
protection anti-bot du site bloque la page. Ce skill utilise donc **le Chrome de l'utilisateur via Claude
in Chrome** (outils `mcp__claude-in-chrome__*`). Conséquences :

- il faut Chrome avec l'extension Claude in Chrome connectée ; ce n'est **pas** utilisable en serveur
  headless ;
- **ne jamais contourner la protection** (modules « stealth », proxys, résolution de CAPTCHA, faux
  user-agent…). Si la page affiche un CAPTCHA, un mur ou une erreur, s'arrêter, le dire à l'utilisateur
  et lui proposer le repli ci-dessous.

Repli sans navigateur : l'agent de la NL (interface web / WhatsApp) dispose de `set_reuters_from_url`
(vidéo YouTube Reuters ou page web par URL) ; il n'est pas exposé dans le MCP.

## Outils de la NL (serveur MCP `newsletter`)

| Outil | Usage |
|---|---|
| `get_reuters_video` | Lit titre, lien, description, URL de l'image de la section actuelle |
| `set_reuters_video` | Remplace tout : `title`, `video_url`, `description`, `thumbnail_path` (capture locale, prioritaire) ou `thumbnail_url` |
| `update_reuters_video` | Ne modifie que les champs fournis (titre, lien, description, image) |
| `remove_reuters_video` | Supprime la section |

Modifier un seul champ : `update_reuters_video` (inutile de tout renvoyer). Sauf demande contraire, ne
rien changer d'autre que ce que l'utilisateur a demandé.

## Rythme : 15 secondes entre chaque action

Pendant toute la construction de la section Reuters, **attendre 15 secondes entre chaque action**.
Cela laisse les pages se charger et évite d'enchaîner les requêtes en rafale sur reuters.com.

- **Actions concernées** : chaque action de navigateur (`tabs_create_mcp`, `navigate`, clic,
  défilement, `javascript_tool`, `get_page_text`, `find`, `read_page`, `computer` capture ou zoom,
  `tabs_close_mcp`) et chaque appel d'écriture ou de lecture du serveur MCP `newsletter`
  (`get_reuters_video`, `set_reuters_video`, `update_reuters_video`, `render_preview`,
  `screenshot_newsletter`).
- **Comment attendre** : `computer` avec l'action `wait` et `duration: 15` (Claude in Chrome) ; à
  défaut, `sleep 15` dans le shell. Une pause = une attente de 15 secondes complète, jamais moins.
- **Pas de pause** avant la toute première action ni après la dernière.
- **Une action à la fois** : ne pas lancer plusieurs actions en parallèle dans le même message pour
  contourner la pause ; chaque action attend la fin de la précédente puis les 15 secondes.
- **Si cette tâche est confiée à un agent**, recopier cette règle dans son prompt.
- Les pauses ne remplacent pas les règles de la section « Pourquoi un vrai Chrome » : en cas de
  CAPTCHA, de mur ou d'erreur, s'arrêter plutôt que de réessayer en boucle.

## Workflow : choisir et renseigner une vidéo

Chaque étape ci-dessous est composée d'actions ; appliquer la pause de 15 secondes entre chaque
action, y compris entre deux actions d'une même étape.

1. **Préparer**
   - Lire `nl:newsletter-config` : topics actifs (colonne « périmètre »), `langue_contenus`
     (anglais), `fenêtre_jours`.
   - `get_newsletter_date` : la fraîcheur se juge par rapport à la date de la NL, pas à la date du jour.
   - `get_reuters_video` : noter ce qui est déjà en place (ne pas reprendre la même vidéo).
   - Charger les outils Chrome en **un seul** `ToolSearch` :
     `select:mcp__claude-in-chrome__tabs_context_mcp,mcp__claude-in-chrome__tabs_create_mcp,mcp__claude-in-chrome__navigate,mcp__claude-in-chrome__computer,mcp__claude-in-chrome__get_page_text,mcp__claude-in-chrome__javascript_tool,mcp__claude-in-chrome__find,mcp__claude-in-chrome__read_page,mcp__claude-in-chrome__tabs_close_mcp`

2. **Ouvrir la page** : `tabs_context_mcp`, puis un **nouvel onglet** (`tabs_create_mcp`) et
   `navigate` vers `https://www.reuters.com/video/`. Bandeau cookies : choisir l'option la plus
   protectrice (refuser le non essentiel). Ne pas déclencher de boîte de dialogue JavaScript.

3. **Lister les candidats** : la page présente une vidéo à la une et une colonne de vidéos
   **à droite**. Relever pour chaque vidéo titre + lien (`javascript_tool` sur les ancres
   `a[href*="/video/"]`, ou `get_page_text` / `find` / `read_page`). Les sélecteurs de Reuters
   changent : vérifier ce que la page contient réellement avant de supposer une structure.
   Faire défiler la colonne pour en voir davantage. **Maximum 15 candidats examinés**.

4. **Choisir** la vidéo la plus pertinente pour les topics actifs (AI, EV, quantum, robotics, cloud,
   venture, energy, industry, aerospace). Critères, par ordre : (a) lien net avec un topic ;
   (b) publiée dans la fenêtre de dates de la NL ; (c) angle tech/industrie/innovation plutôt que
   politique ou faits divers. Si aucune ne convient, le dire à l'utilisateur avec les 3 meilleurs
   candidats plutôt que d'en forcer une.

5. **Ouvrir la vidéo choisie** (clic ou `navigate`) et relever, depuis la page (`javascript_tool`) :
   - titre : `meta[property="og:title"]` ou `h1` ;
   - lien : `link[rel="canonical"]` / `og:url` (sinon l'URL courante), **sans paramètres de suivi** ;
   - description : `meta[property="og:description"]`, reformulée si besoin ;
   - image : `meta[property="og:image"]` (repli pour `thumbnail_url`).
   Ne rien inventer : si le titre ou la description reste introuvable, le signaler.

6. **Capturer la vidéo** : mettre la lecture en pause (touche `k` ou clic sur le lecteur) sur une
   image représentative, puis `computer` → `screenshot` ou `zoom` sur la zone du lecteur avec
   **`save_to_disk: true`**. Le résultat donne le chemin du fichier : c'est le `thumbnail_path`.
   La capture est réduite à 706 px de large par la NL.

7. **Renseigner** :
   `set_reuters_video(title, video_url, description, thumbnail_path=<chemin>, thumbnail_url=<og:image>)`.
   - `title` : titre de la vidéo tel que publié.
   - `description` : **300 caractères maximum**, en anglais, factuelle, reprise de la page (pas de
     commentaire personnel).
   - Si la capture échoue, l'`og:image` en `thumbnail_url` suffit.

8. **Vérifier et nettoyer** : `get_reuters_video` pour relire ce qui est enregistré, puis
   `render_preview` ; au besoin `screenshot_newsletter` pour contrôler le rendu. Fermer l'onglet ouvert
   (`tabs_close_mcp`). Rapporter à l'utilisateur : titre, lien, topic retenu, et pourquoi.

## Conduite à tenir

- Ne jamais télécharger ni retransmettre le fichier vidéo : la NL ne contient que le lien, un
  titre, une courte description et une capture.
- Au plus **une** vidéo par édition ; toute autre demande passe par `update_reuters_video`.
- Respecter la pause de **15 secondes entre chaque action** (voir « Rythme : 15 secondes entre chaque
  action »), y compris lors des vérifications et du nettoyage de l'étape 8.
- Si Chrome n'est pas connecté, ou si la page est bloquée (401, CAPTCHA, mur de consentement
  impossible à refuser), s'arrêter après 2 ou 3 tentatives et proposer le repli ou une saisie
  manuelle (lien + titre fournis par l'utilisateur, puis `set_reuters_video`).
- L'agent conversationnel de la NL (interface web / WhatsApp) dispose des mêmes quatre outils pour
  lire et éditer la section, mais ne navigue pas : le parcours de `reuters.com/video` n'existe que
  dans ce skill.
