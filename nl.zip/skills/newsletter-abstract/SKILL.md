---
name: "newsletter-abstract"
description: "Rédige l'abstract d'un article de la NL (80 mots max, en anglais, avec le « et alors ? » pour une entreprise) après lecture de l'article. Sert aux articles marché et à l'article Capgemini."
---

# Abstract d'article

Tu reçois l'URL (et le titre) d'un article. Tu renvoies son abstract.

## Méthode

1. **Lire l'article lui-même** (WebFetch ; si échec, WebSearch pour retrouver le contenu). Ne jamais écrire à partir du titre ou d'un snippet.
2. Identifier ce qui compte pour un décideur technique : le fait, le chiffre clé, et l'implication (coût, architecture, dépendance fournisseur, souveraineté, risque, calendrier d'adoption).
3. Rédiger l'abstract.

## Règles

- **Anglais, 80 mots maximum** (compter, viser 60-80).
- Commencer directement par l'insight : pas de « This article… », pas de « Included because… », pas de mention de la NL.
- Le « et alors ? » pour une entreprise, avec nuance si la source défend son propre intérêt (articles marché uniquement). **On garde cette implication dans chaque abstract, mais on ne nomme jamais le lecteur** : aucune mention de « CTO », « CTOs », « technology leaders » ni d'une autre fonction (« CIOs », « decision-makers »…) dans le texte. L'implication s'écrit directement, sous forme d'une conclusion à l'impératif, au présent ou avec « should », dont le sujet est la chose à faire ou à surveiller, pas la personne.
  - À éviter : « For CTOs, the lesson is concentration risk. » / « For a CTO: supplier fragility is now a vendor risk. »
  - À préférer : « The lesson is concentration risk: detection, load shedding and failover plans deserve scrutiny. » / « Supplier balance-sheet fragility is now a vendor-concentration risk. » / « Stress-test GPU roadmaps and contracts against leadership shocks. » / « Treat it as a signal of direction, not a plannable resource. »
- **Article Capgemini** : la NL est publiée par Capgemini, donc aucune mise en garde sur l'origine de l'information (« company-authored », « its own survey », « not independent research », « vendor claims »...). Présenter les résultats tels quels, sourcés à Capgemini ou au Capgemini Research Institute.
- Chiffres et noms exacts, repris de l'article. Aucune approximation ni invention.
- Paraphrase : pas de reprise de phrases de l'article (citation courte de moins de 15 mots tolérée, une seule).
- Un seul paragraphe, sans mise en forme.

## Sortie

Avant de renvoyer, relire l'abstract : s'il contient « CTO » (ou une autre désignation du lecteur), reformuler la phrase d'implication en gardant son sens.

Renvoyer uniquement l'abstract, suivi sur une ligne séparée de `(N words)`.