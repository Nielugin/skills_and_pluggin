"""
Persists each newsletter edition to disk (output/newsletters/<number>.json)
so a previously-built edition can be reopened later by its number without
re-fetching anything from RSS — see web.agent.load_or_create_newsletter.
"""
import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

from paths import SNAPSHOTS_DIR


def _snapshot_path(number: int) -> Path:
    return SNAPSHOTS_DIR / f"{number}.json"


def snapshot_exists(number: int) -> bool:
    return _snapshot_path(number).exists()


def save_snapshot(state) -> None:
    """Write the current in-memory newsletter state to disk, keyed by its number.
    Best-effort — a write failure must never break the caller's render/edit flow."""
    SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    data = {
        "newsletter_number": state.newsletter_number,
        "newsletter_title": state.newsletter_title,
        "newsletter_date": state.newsletter_date,
        "market_articles": state.market_articles,
        "capgemini_article": state.capgemini_article,
        "reuters_video": state.reuters_video,
        "edito": state.edito,
    }
    try:
        _snapshot_path(state.newsletter_number).write_text(
            json.dumps(data, ensure_ascii=False, default=str, indent=2), encoding="utf-8"
        )
    except OSError as exc:
        logger.warning("Could not save newsletter snapshot #%s: %s", state.newsletter_number, exc)


def load_snapshot(number: int) -> Optional[dict]:
    path = _snapshot_path(number)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("Could not load newsletter snapshot #%s: %s", number, exc)
        return None


def list_snapshot_numbers() -> list[int]:
    """Numbers of all saved editions, ascending."""
    if not SNAPSHOTS_DIR.exists():
        return []
    return sorted(int(p.stem) for p in SNAPSHOTS_DIR.glob("*.json") if p.stem.isdigit())
