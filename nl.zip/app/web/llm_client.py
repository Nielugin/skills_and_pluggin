"""
Provider-agnostic LLM client for the newsletter agent.

Supports either Anthropic (Claude) or OpenAI as the backing model, each with
its own configurable API endpoint (useful for proxies, Azure OpenAI-compatible
gateways, OpenRouter, self-hosted OpenAI-compatible servers, etc.):

  LLM_PROVIDER        anthropic | openai — optional, see resolution rules below
  ANTHROPIC_API_KEY   required to use Anthropic
  ANTHROPIC_BASE_URL  optional override of the Anthropic API endpoint —
                      defaults to the public Anthropic API if unset
  OPENAI_API_KEY      required to use OpenAI
  OPENAI_BASE_URL     optional override of the OpenAI API endpoint —
                      defaults to the public OpenAI API if unset
  LLM_MODEL           optional override of the main conversational model
  LLM_MODEL_FAST      optional override of the cheap/fast model (edito parsing)

Provider resolution — LLM_PROVIDER always wins when set explicitly; otherwise
the active provider is inferred from which API key(s) are present. If both
ANTHROPIC_API_KEY and OPENAI_API_KEY are set and LLM_PROVIDER is unset,
Anthropic is used (set LLM_PROVIDER=openai to force OpenAI in that case).

Conversation history and tool schemas are kept in Anthropic's native shape
(list of {"type": "text"|"tool_use"|"tool_result", ...} dict blocks) since
that's the richer of the two schemas; the OpenAI path translates to/from it
on every call so callers never need to know which provider is active.
"""
import json
import logging
import os
from types import SimpleNamespace
from typing import Optional

logger = logging.getLogger(__name__)


def _resolve_provider() -> str:
    explicit = os.getenv("LLM_PROVIDER", "").strip().lower()
    if explicit in ("anthropic", "openai"):
        return explicit
    if explicit:
        logger.warning("LLM_PROVIDER inconnu (%r) — détection automatique via les clés API", explicit)

    has_anthropic = bool(os.getenv("ANTHROPIC_API_KEY", "").strip())
    has_openai = bool(os.getenv("OPENAI_API_KEY", "").strip())

    if has_anthropic and has_openai:
        logger.info(
            "ANTHROPIC_API_KEY et OPENAI_API_KEY sont tous deux renseignés — "
            "utilisation d'Anthropic par défaut (LLM_PROVIDER=openai pour forcer OpenAI)"
        )
        return "anthropic"
    if has_openai and not has_anthropic:
        return "openai"
    if not has_anthropic and not has_openai:
        logger.warning(
            "Aucune clé API LLM trouvée (ANTHROPIC_API_KEY / OPENAI_API_KEY) — "
            "repli sur Anthropic par défaut, l'agent ne pourra pas répondre"
        )
    return "anthropic"


PROVIDER = _resolve_provider()

_DEFAULT_MODELS = {
    "anthropic": {"main": "claude-sonnet-4-6", "fast": "claude-haiku-4-5-20251001"},
    "openai":    {"main": "gpt-4.1",           "fast": "gpt-4.1-mini"},
}

MAIN_MODEL = os.getenv("LLM_MODEL", "").strip() or _DEFAULT_MODELS[PROVIDER]["main"]
FAST_MODEL = os.getenv("LLM_MODEL_FAST", "").strip() or _DEFAULT_MODELS[PROVIDER]["fast"]


def is_configured() -> bool:
    """Whether the API key needed for the active provider is set."""
    if PROVIDER == "openai":
        return bool(os.getenv("OPENAI_API_KEY", "").strip())
    return bool(os.getenv("ANTHROPIC_API_KEY", "").strip())


# ── Anthropic backend ──────────────────────────────────────────────────────

_anthropic_client = None


def _get_anthropic_client():
    global _anthropic_client
    if _anthropic_client is None:
        import anthropic

        kwargs = {}
        api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
        if api_key:
            kwargs["api_key"] = api_key
        base_url = os.getenv("ANTHROPIC_BASE_URL", "").strip()
        if base_url:
            kwargs["base_url"] = base_url
            logger.info("Anthropic : endpoint personnalisé %s", base_url)
        else:
            logger.debug("Anthropic : ANTHROPIC_BASE_URL non défini — endpoint public par défaut")
        _anthropic_client = anthropic.Anthropic(**kwargs)
    return _anthropic_client


def _anthropic_block_to_dict(block) -> dict:
    if block.type == "text":
        return {"type": "text", "text": block.text}
    if block.type == "tool_use":
        return {"type": "tool_use", "id": block.id, "name": block.name, "input": block.input}
    return {"type": block.type}


def _create_anthropic(system: Optional[str], messages: list, tools: Optional[list], model: str, max_tokens: int):
    client = _get_anthropic_client()
    kwargs = {"model": model, "max_tokens": max_tokens, "messages": messages}
    if system:
        kwargs["system"] = system
    if tools:
        kwargs["tools"] = tools
    resp = client.messages.create(**kwargs)
    content = [_anthropic_block_to_dict(b) for b in resp.content]
    return SimpleNamespace(content=content, usage=resp.usage, stop_reason=resp.stop_reason)


# ── OpenAI backend ──────────────────────────────────────────────────────────

_openai_client = None


def _get_openai_client():
    global _openai_client
    if _openai_client is None:
        import openai

        kwargs = {}
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if api_key:
            kwargs["api_key"] = api_key
        base_url = os.getenv("OPENAI_BASE_URL", "").strip()
        if base_url:
            kwargs["base_url"] = base_url
            logger.info("OpenAI : endpoint personnalisé %s", base_url)
        else:
            logger.debug("OpenAI : OPENAI_BASE_URL non défini — endpoint public par défaut")
        _openai_client = openai.OpenAI(**kwargs)
    return _openai_client


def _tools_to_openai(tools: list) -> list:
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": t.get("input_schema") or {"type": "object", "properties": {}},
            },
        }
        for t in tools
    ]


def _history_to_openai(system: Optional[str], messages: list) -> list:
    out = []
    if system:
        out.append({"role": "system", "content": system})

    for msg in messages:
        role, content = msg["role"], msg["content"]

        if isinstance(content, str):
            out.append({"role": role, "content": content})
            continue

        if role == "assistant":
            texts = [b.get("text", "") for b in content if b.get("type") == "text"]
            tool_uses = [b for b in content if b.get("type") == "tool_use"]
            assistant_msg = {"role": "assistant", "content": "".join(texts) or None}
            if tool_uses:
                assistant_msg["tool_calls"] = [
                    {
                        "id": tu["id"],
                        "type": "function",
                        "function": {
                            "name": tu["name"],
                            "arguments": json.dumps(tu["input"], ensure_ascii=False),
                        },
                    }
                    for tu in tool_uses
                ]
            out.append(assistant_msg)
            continue

        # role == "user": either tool results from a prior turn, or plain text blocks
        tool_results = [b for b in content if b.get("type") == "tool_result"]
        if tool_results:
            for tr in tool_results:
                out.append({
                    "role": "tool",
                    "tool_call_id": tr["tool_use_id"],
                    "content": tr.get("content", ""),
                })
        else:
            text = "".join(b.get("text", "") for b in content if b.get("type") == "text")
            out.append({"role": "user", "content": text})

    return out


def _openai_response_to_canonical(resp):
    choice = resp.choices[0]
    msg = choice.message

    content = []
    if msg.content:
        content.append({"type": "text", "text": msg.content})
    for tc in (msg.tool_calls or []):
        try:
            args = json.loads(tc.function.arguments or "{}")
        except json.JSONDecodeError:
            args = {}
        content.append({"type": "tool_use", "id": tc.id, "name": tc.function.name, "input": args})

    stop_reason = "tool_use" if choice.finish_reason == "tool_calls" else "end_turn"
    usage = SimpleNamespace(
        input_tokens=getattr(resp.usage, "prompt_tokens", 0) or 0,
        output_tokens=getattr(resp.usage, "completion_tokens", 0) or 0,
    )
    return content, stop_reason, usage


def _create_openai(system: Optional[str], messages: list, tools: Optional[list], model: str, max_tokens: int):
    client = _get_openai_client()
    oa_messages = _history_to_openai(system, messages)
    kwargs = {"model": model, "max_tokens": max_tokens, "messages": oa_messages}
    if tools:
        kwargs["tools"] = _tools_to_openai(tools)
    resp = client.chat.completions.create(**kwargs)
    content, stop_reason, usage = _openai_response_to_canonical(resp)
    return SimpleNamespace(content=content, usage=usage, stop_reason=stop_reason)


# ── Public entry point ──────────────────────────────────────────────────────

def create_message(
    *,
    messages: list,
    model: str,
    max_tokens: int = 1024,
    system: Optional[str] = None,
    tools: Optional[list] = None,
):
    """
    Send a chat/tool-use turn to the configured provider.

    Returns an object with `.content` (list of canonical dict blocks,
    {"type": "text", "text": ...} or {"type": "tool_use", "id", "name", "input"}),
    `.usage` (`.input_tokens` / `.output_tokens`) and `.stop_reason`
    ("tool_use" or "end_turn").
    """
    if PROVIDER == "openai":
        return _create_openai(system, messages, tools, model, max_tokens)
    return _create_anthropic(system, messages, tools, model, max_tokens)
