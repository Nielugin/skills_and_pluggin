'use strict';

// ── DOM refs ──────────────────────────────────────────────────
const $  = id => document.getElementById(id);
const messages    = $('messages');
const chatInput   = $('chat-input');
const btnSend     = $('btn-send');
const btnMic      = $('btn-mic');
const voiceHint   = $('voice-hint');
const connStatus  = $('conn-status');
const connLabel   = $('conn-label');
const loadOverlay = $('load-overlay');
const loadMsg     = $('load-msg');
const previewFrame = $('preview-frame');
const updatedAt   = $('updated-at');
const mainLayout  = $('main-layout');
const btnMute     = $('btn-mute');
const altList     = $('alternative-list');

// ── State ─────────────────────────────────────────────────────
let isProcessing = false;
let pendingAssistantEl = null;   // current streaming assistant bubble
let ttsEnabled = true;
let alternativeItems = [];

// ── WebSocket with auto-reconnect ─────────────────────────────
let ws = null;
let _wsReconnectTimer = null;

function connectWS() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;

  ws = new WebSocket(`ws://${location.host}/ws/chat`);

  ws.addEventListener('open', () => {
    setConn('connected', 'Connecté');
    if (_wsReconnectTimer) { clearTimeout(_wsReconnectTimer); _wsReconnectTimer = null; }
    // Re-enable input if it was locked by a dropped connection
    if (isProcessing) {
      isProcessing = false;
      pendingAssistantEl = null;
      setInputEnabled(true);
      removeEphemeral();
    }
  });

  ws.addEventListener('close', () => {
    setConn('error', 'Déconnecté — reconnexion…');
    // Unlock the UI immediately so the user isn't stuck
    if (isProcessing) {
      isProcessing = false;
      pendingAssistantEl = null;
      setInputEnabled(true);
      removeEphemeral();
    }
    _wsReconnectTimer = setTimeout(connectWS, 3000);
  });

  ws.addEventListener('error', () => setConn('error', 'Erreur WS'));

  ws.addEventListener('message', e => {
    let data;
    try { data = JSON.parse(e.data); } catch { return; }
    handleMsg(data);
  });
}

connectWS();

function setConn(cls, label) {
  connStatus.className = `conn-status ${cls}`;
  connLabel.textContent = label;
}

// ── Server message handler ────────────────────────────────────
const TOOL_LABELS = {
  get_newsletter_state:  '📋 Lecture de la newsletter…',
  fetch_and_add_article: '🔍 Recherche d\'articles RSS…',
  remove_article:        '🗑 Suppression d\'article…',
  move_article:          '↕ Déplacement d\'article…',
  refresh_all_articles:  '↻ Rafraîchissement RSS…',
  render_preview:        '🖼 Rendu HTML…',
  send_newsletter:         '📤 Génération PDF et envoi e-mail…',
  check_edito_from_email:  '📬 Vérification de la boîte Gmail…',
  search_and_add_article:  '🔎 Recherche web d\'article…',
};

function handleMsg(data) {
  switch (data.type) {

    case 'status':
      addSysMsg(data.message);
      break;

    case 'text': {
      removeEphemeral();
      if (!pendingAssistantEl) {
        pendingAssistantEl = addBubble('assistant', '');
      }
      pendingAssistantEl.querySelector('.bubble').textContent = data.content;
      speakText(data.content);
      scrollDown();
      break;
    }

    case 'tool_start': {
      removeEphemeral();
      const chip = document.createElement('div');
      chip.className = 'msg assistant ephemeral';
      chip.innerHTML = `<div class="tool-chip">
        <div class="tool-chip-spin"></div>
        <span>${TOOL_LABELS[data.tool] || data.tool}</span>
      </div>`;
      messages.appendChild(chip);
      scrollDown();
      break;
    }

    case 'tool_result':
      removeEphemeral();
      break;

    case 'crop_request':
      openCropModal(data);
      break;

    case 'newsletter_updated':
      refreshPreview();
      fetchNlNumber();
      fetchNlDate();
      loadAlternativeSuggestions();
      break;

    case 'done':
      pendingAssistantEl = null;
      isProcessing = false;
      setInputEnabled(true);
      removeEphemeral();
      break;
  }
}

// ── Send helpers ──────────────────────────────────────────────
function sendMessage(text) {
  text = text.trim();
  if (!text || isProcessing || ws.readyState !== WebSocket.OPEN) return;

  isProcessing = true;
  pendingAssistantEl = null;
  setInputEnabled(false);

  addBubble('user', text);
  chatInput.value = '';

  // typing indicator
  const typing = document.createElement('div');
  typing.className = 'msg assistant ephemeral';
  typing.innerHTML = `<div class="typing">
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>
  </div>`;
  messages.appendChild(typing);

  ws.send(JSON.stringify({ type: 'chat', message: text }));
  scrollDown();
}

btnSend.addEventListener('click', () => sendMessage(chatInput.value));
chatInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(chatInput.value); }
});
document.querySelectorAll('.quick-pill').forEach(btn => {
  btn.addEventListener('click', () => sendMessage(btn.dataset.msg));
});

// ── Newsletter number badge ───────────────────────────────────
const nlNumberDisplay = $('nl-number');
const nlNumberInput   = $('nl-number-input');

async function fetchNlNumber() {
  try {
    const res  = await fetch('/api/newsletter/number');
    const json = await res.json();
    if (json.number) nlNumberDisplay.textContent = json.number;
  } catch { /* ignore */ }
}

function startEditNlNumber() {
  nlNumberInput.value = nlNumberDisplay.textContent;
  nlNumberDisplay.classList.add('hidden');
  nlNumberInput.classList.remove('hidden');
  nlNumberInput.focus();
  nlNumberInput.select();
}

async function commitNlNumber() {
  const val = parseInt(nlNumberInput.value, 10);
  nlNumberInput.classList.add('hidden');
  nlNumberDisplay.classList.remove('hidden');
  if (!val || val < 1) return;
  try {
    const res  = await fetch('/api/newsletter/number', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number: val }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      nlNumberDisplay.textContent = val;
      refreshPreview();
      addSysMsg(`Numéro de newsletter mis à jour : #${val}`);
    } else {
      addSysMsg(`Erreur : ${json.message}`);
    }
  } catch (err) {
    addSysMsg(`Erreur réseau : ${err.message}`);
  }
}

$('nl-number-wrap').addEventListener('click', () => {
  if (!nlNumberInput.classList.contains('hidden')) return;
  startEditNlNumber();
});
nlNumberInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') { e.preventDefault(); nlNumberInput.blur(); }
  if (e.key === 'Escape') { nlNumberInput.classList.add('hidden'); nlNumberDisplay.classList.remove('hidden'); }
});
nlNumberInput.addEventListener('blur', commitNlNumber);

// ── Newsletter date badge ─────────────────────────────────────
const nlDateDisplay = $('nl-date');
const nlDateInput   = $('nl-date-input');

async function fetchNlDate() {
  try {
    const res  = await fetch('/api/newsletter/date');
    const json = await res.json();
    if (json.date) nlDateDisplay.textContent = json.date;
  } catch { /* ignore */ }
}

function startEditNlDate() {
  nlDateInput.value = nlDateDisplay.textContent;
  nlDateDisplay.classList.add('hidden');
  nlDateInput.classList.remove('hidden');
  nlDateInput.focus();
}

async function commitNlDate() {
  const val = nlDateInput.value;
  nlDateInput.classList.add('hidden');
  nlDateDisplay.classList.remove('hidden');
  if (!val) return;
  try {
    const res  = await fetch('/api/newsletter/date', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ date: val }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      nlDateDisplay.textContent = val;
      refreshPreview();
      addSysMsg(`Date de référence de la newsletter mise à jour : ${val}`);
    } else {
      addSysMsg(`Erreur : ${json.message}`);
    }
  } catch (err) {
    addSysMsg(`Erreur réseau : ${err.message}`);
  }
}

$('nl-date-wrap').addEventListener('click', () => {
  if (!nlDateInput.classList.contains('hidden')) return;
  startEditNlDate();
});
nlDateInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') { e.preventDefault(); nlDateInput.blur(); }
  if (e.key === 'Escape') { nlDateInput.classList.add('hidden'); nlDateDisplay.classList.remove('hidden'); }
});
nlDateInput.addEventListener('blur', commitNlDate);
fetchNlDate();

fetchNlNumber();

// ── Refresh / Clear ───────────────────────────────────────────
$('btn-refresh').addEventListener('click', async () => {
  const btn = $('btn-refresh');
  btn.disabled = true;
  btn.classList.add('spinning');
  showLoading('Rafraîchissement en cours…');

  try {
    const res  = await fetch('/api/newsletter/refresh', { method: 'POST' });
    const json = await res.json();
    if (json.status === 'ok') {
      refreshPreview();
      addSysMsg(`Newsletter rafraîchie — ${json.count} articles sélectionnés.`);
    } else {
      addBubble('assistant', `❌ Erreur rafraîchissement : ${json.message || res.statusText}`);
    }
  } catch (err) {
    addBubble('assistant', `❌ Erreur réseau (rafraîchissement) : ${err.message}`);
  } finally {
    btn.disabled = false;
    btn.classList.remove('spinning');
    hideLoading();
  }
});

$('btn-clear').addEventListener('click', async () => {
  await fetch('/api/conversation/clear', { method: 'POST' });
  messages.innerHTML = '';
  addBubble('assistant', 'Conversation effacée. Comment puis-je vous aider ?');
});

// ── Send newsletter button ────────────────────────────────────
$('btn-send-mail').addEventListener('click', async () => {
  const btn = $('btn-send-mail');
  btn.disabled = true;
  btn.innerHTML = '<span class="btn-icon" style="display:inline-block;animation:spin .8s linear infinite">↻</span> Envoi…';

  addSysMsg('📤 Génération du PDF et envoi de la newsletter…');

  try {
    const res  = await fetch('/api/newsletter/send', { method: 'POST' });
    const json = await res.json();
    if (json.status === 'ok') {
      const dest = json.recipients?.join(', ') || '';
      addBubble('assistant', `✅ Newsletter envoyée avec succès à : ${dest}`);
      speakText('Newsletter envoyée avec succès.');
    } else {
      addBubble('assistant', `❌ Erreur d'envoi : ${json.message}`);
      speakText('Erreur lors de l\'envoi de la newsletter.');
    }
  } catch (err) {
    addBubble('assistant', `❌ Erreur réseau (envoi) : ${err.message}`);
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<span class="btn-icon">📤</span> Envoyer';
  }
});

// ── Preview ───────────────────────────────────────────────────
function refreshPreview() {
  showLoading('Mise à jour de l\'aperçu…');
  previewFrame.src = `/api/newsletter/preview?t=${Date.now()}`;
}

async function loadAlternativeSuggestions() {
  if (!altList) return;
  try {
    const res = await fetch('/api/newsletter/alternatives');
    const json = await res.json();
    if (json.status === 'ok') {
      alternativeItems = json.items || [];
      renderAlternativeSuggestions();
    }
  } catch (err) {
    altList.innerHTML = '<div class="alternative-empty">Impossible de charger les suggestions.</div>';
  }
}

function renderAlternativeSuggestions() {
  if (!altList) return;
  if (!alternativeItems.length) {
    altList.innerHTML = '<div class="alternative-empty">Aucune suggestion disponible pour le moment.</div>';
    return;
  }

  altList.innerHTML = '';
  alternativeItems.forEach(item => {
    const card = document.createElement('div');
    card.className = 'alternative-card';
    card.draggable = true;
    card.dataset.url = item.url || '';
    card.innerHTML = `
      <img src="${esc(item.image_url || '')}" alt="${esc(item.title || 'Article')}" onerror="this.style.display='none'" />
      <div class="alternative-card-body">
        <a class="alternative-card-title" href="${esc(item.url || '#')}" target="_blank" rel="noopener">${esc(item.title || 'Sans titre')}</a>
        <div class="alternative-actions">
          <button class="alternative-action" data-action="append" title="Ajouter en fin de newsletter">+</button>
          <button class="alternative-action" data-action="dismiss" title="Masquer cette suggestion">−</button>
        </div>
      </div>
    `;
    card.addEventListener('dragstart', e => {
      e.dataTransfer?.setData('application/json', JSON.stringify(item));
      e.dataTransfer?.setData('text/plain', item.url || '');
      if (e.dataTransfer) e.dataTransfer.effectAllowed = 'copy';
    });
    card.querySelector('[data-action="append"]').addEventListener('click', () => appendAlternative(item));
    card.querySelector('[data-action="dismiss"]').addEventListener('click', () => dismissAlternative(item));
    altList.appendChild(card);
  });
}

function getDropTargetUrl(e) {
  if (!previewFrame || !previewFrame.contentDocument) return '';
  const rect = previewFrame.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  const target = previewFrame.contentDocument.elementFromPoint(x, y);
  const row = target?.closest?.('.article-row');
  return row?.dataset?.articleUrl || row?.getAttribute?.('data-article-url') || '';
}

function parseDroppedSuggestion(e) {
  const raw = e.dataTransfer?.getData('application/json') || e.dataTransfer?.getData('text/plain') || '';
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return { url: raw }; }
}

async function replaceAlternativeArticle(e) {
  const suggestion = parseDroppedSuggestion(e);
  if (!suggestion?.url) return;
  const targetUrl = getDropTargetUrl(e);
  if (!targetUrl) {
    addSysMsg('⚠ Déposez l’article sur une carte de la newsletter.');
    return;
  }

  try {
    const res = await fetch('/api/newsletter/alternatives/replace', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target_url: targetUrl, suggestion }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      addSysMsg(`✅ Article remplacé par : ${suggestion.title || 'nouvelle suggestion'}`);
      refreshPreview();
      await loadAlternativeSuggestions();
    } else {
      addSysMsg(`⚠ ${json.message || 'Remplacement impossible'}`);
    }
  } catch (err) {
    addSysMsg(`⚠ Erreur réseau : ${err.message}`);
  }
}

async function appendAlternative(item) {
  try {
    const res = await fetch('/api/newsletter/alternatives/append', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ article: item }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      addSysMsg(`✅ Article ajouté en fin de newsletter : ${item.title}`);
      refreshPreview();
      await loadAlternativeSuggestions();
    } else {
      addSysMsg(`⚠ ${json.message || 'Impossible d’ajouter cet article'}`);
    }
  } catch (err) {
    addSysMsg(`⚠ Erreur réseau : ${err.message}`);
  }
}

async function dismissAlternative(item) {
  try {
    const excluded = alternativeItems.map(i => i.url).filter(Boolean);
    const res = await fetch('/api/newsletter/alternatives/dismiss', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ excluded_urls: [...excluded, item.url] }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      if (json.item) {
        alternativeItems = alternativeItems.filter(i => i.url !== item.url);
        alternativeItems.push(json.item);
        renderAlternativeSuggestions();
      } else {
        alternativeItems = alternativeItems.filter(i => i.url !== item.url);
        renderAlternativeSuggestions();
      }
    }
  } catch (err) {
    addSysMsg(`⚠ Erreur réseau : ${err.message}`);
  }
}

previewFrame.addEventListener('load', () => {
  hideLoading();
  updatedAt.textContent = `Mis à jour ${new Date().toLocaleTimeString('fr-FR')}`;
  loadAlternativeSuggestions();
});

['dragenter', 'dragover'].forEach(evt => {
  previewFrame.addEventListener(evt, e => {
    if (!e.dataTransfer) return;
    const hasPayload = e.dataTransfer.types?.includes('application/json') || e.dataTransfer.types?.includes('text/plain');
    if (!hasPayload) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  });
});

previewFrame.addEventListener('drop', e => {
  e.preventDefault();
  replaceAlternativeArticle(e);
});

$('btn-fullscreen').addEventListener('click', () => {
  mainLayout.classList.toggle('fs-preview');
});

// ── UI helpers ────────────────────────────────────────────────
function addBubble(role, text) {
  const div = document.createElement('div');
  div.className = `msg ${role}`;
  div.innerHTML = `<div class="bubble">${esc(text)}</div>`;
  messages.appendChild(div);
  scrollDown();
  return div;
}

function addSysMsg(text) {
  const div = document.createElement('div');
  div.className = 'msg system';
  div.innerHTML = `<div class="bubble">${esc(text)}</div>`;
  messages.appendChild(div);
  scrollDown();
}

function removeEphemeral() {
  messages.querySelectorAll('.ephemeral').forEach(el => el.remove());
}

function setInputEnabled(on) {
  chatInput.disabled = !on;
  btnSend.disabled   = !on;
  btnMic.disabled    = !on;
}

function scrollDown() {
  messages.scrollTop = messages.scrollHeight;
}

function showLoading(msg) {
  loadMsg.textContent = msg || 'Chargement…';
  loadOverlay.classList.remove('hidden');
}

function hideLoading() {
  loadOverlay.classList.add('hidden');
}

function esc(str) {
  const d = document.createElement('div');
  d.appendChild(document.createTextNode(str));
  return d.innerHTML;
}

// ── Voice input (STT) ─────────────────────────────────────────
const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let isListening = false;

if (SpeechRec) {
  recognition = new SpeechRec();
  recognition.lang = 'fr-FR';
  recognition.continuous = false;
  recognition.interimResults = true;

  recognition.addEventListener('start', () => {
    isListening = true;
    btnMic.classList.add('listening');
    btnMic.querySelector('.mic-lbl').textContent = 'Écoute…';
    voiceHint.textContent = '🎙 Parlez maintenant…';
  });

  recognition.addEventListener('result', e => {
    const transcript = Array.from(e.results).map(r => r[0].transcript).join('');
    chatInput.value  = transcript;
    voiceHint.textContent = `"${transcript}"`;
  });

  recognition.addEventListener('end', () => {
    isListening = false;
    btnMic.classList.remove('listening');
    btnMic.querySelector('.mic-lbl').textContent = 'Parler';
    const text = chatInput.value.trim();
    if (text) {
      voiceHint.textContent = '';
      sendMessage(text);
    } else {
      voiceHint.textContent = 'Rien entendu. Réessayez.';
      setTimeout(() => { voiceHint.textContent = ''; }, 2500);
    }
  });

  recognition.addEventListener('error', e => {
    isListening = false;
    btnMic.classList.remove('listening');
    btnMic.querySelector('.mic-lbl').textContent = 'Parler';
    const msgs = {
      'not-allowed':  'Microphone non autorisé (vérifiez les permissions)',
      'no-speech':    'Aucune parole détectée.',
      'network':      'Erreur réseau.',
      'aborted':      '',
    };
    voiceHint.textContent = msgs[e.error] ?? `Erreur : ${e.error}`;
    setTimeout(() => { voiceHint.textContent = ''; }, 3000);
  });

} else {
  btnMic.disabled = true;
  btnMic.title    = 'Reconnaissance vocale non supportée (utilisez Chrome ou Edge)';
  voiceHint.textContent = 'Vocal non disponible dans ce navigateur';
}

btnMic.addEventListener('click', () => {
  if (!recognition) return;
  isListening ? recognition.stop() : recognition.start();
});

// ── Voice output (TTS) ────────────────────────────────────────
let ttsVoice = null;

function loadVoices() {
  const voices = speechSynthesis.getVoices();
  ttsVoice = voices.find(v => v.lang.startsWith('fr-FR') && v.localService)
          || voices.find(v => v.lang.startsWith('fr'))
          || null;
}

if ('speechSynthesis' in window) {
  loadVoices();
  speechSynthesis.addEventListener('voiceschanged', loadVoices);
}

function speakText(text) {
  if (!('speechSynthesis' in window)) return;
  if (!ttsEnabled) return;
  // Limit length to avoid very long TTS reads
  const trimmed = text.length > 400 ? text.slice(0, 400) + '…' : text;
  speechSynthesis.cancel();
  const utt    = new SpeechSynthesisUtterance(trimmed);
  utt.lang     = 'fr-FR';
  utt.rate     = 1.05;
  utt.pitch    = 1.0;
  if (ttsVoice) utt.voice = ttsVoice;
  speechSynthesis.speak(utt);
}

// Stop TTS when user starts typing
chatInput.addEventListener('focus', () => speechSynthesis.cancel?.());

// ── Mute toggle ───────────────────────────────────────────────
function setMute(muted) {
  ttsEnabled = !muted;
  btnMute.textContent = muted ? '🔇' : '🔊';
  btnMute.classList.toggle('muted', muted);
  btnMute.title = muted
    ? 'Voix coupée — cliquer ou M pour réactiver'
    : 'Couper la voix de l\'assistant (touche M)';
  if (muted) speechSynthesis.cancel?.();
}

btnMute.addEventListener('click', () => setMute(ttsEnabled)); // toggle

document.addEventListener('keydown', e => {
  const tag = document.activeElement?.tagName;
  if (tag === 'TEXTAREA' || tag === 'INPUT') return;  // don't capture when typing
  if (e.key === 'm' || e.key === 'M') setMute(ttsEnabled);
});

// ── Crop modal ────────────────────────────────────────────────

let _cropData   = null;   // { url, image_url, title, position }
let _cropPoints = [];     // max 2 × { x, y } in natural-image pixels

const cropModal   = $('crop-modal');
const cropImg     = $('crop-img');
const cropCanvas  = $('crop-canvas');
const cropConfirm = $('crop-confirm');

// Server sends this when add_article_from_url returns needs_crop:true
function openCropModal(data) {
  _cropData   = data;
  _cropPoints = [];
  $('crop-title').textContent = `Recadrer : ${data.title.slice(0, 65)}${data.title.length > 65 ? '…' : ''}`;
  cropImg.src = '';
  cropImg.onload = () => {
    syncCanvasToImage();
    redrawCanvas();
  };
  cropImg.src = data.image_url;
  updateCoordDisplay();
  cropConfirm.disabled = true;
  cropModal.classList.remove('hidden');
}

function closeCropModal() {
  cropModal.classList.add('hidden');
  _cropData   = null;
  _cropPoints = [];
}

// Align canvas exactly over the displayed <img>
function syncCanvasToImage() {
  const r = cropImg.getBoundingClientRect();
  const wrap = $('crop-canvas-wrap').getBoundingClientRect();
  cropCanvas.width  = r.width;
  cropCanvas.height = r.height;
  cropCanvas.style.width   = r.width  + 'px';
  cropCanvas.style.height  = r.height + 'px';
  cropCanvas.style.left    = (r.left - wrap.left) + 'px';
  cropCanvas.style.top     = (r.top  - wrap.top)  + 'px';
}

function redrawCanvas() {
  const ctx = cropCanvas.getContext('2d');
  const W = cropCanvas.width, H = cropCanvas.height;
  ctx.clearRect(0, 0, W, H);

  // ── Grid ──────────────────────────────────────────────
  ctx.strokeStyle = 'rgba(255,255,255,0.18)';
  ctx.lineWidth   = 0.5;
  const COLS = 10, ROWS = 10;
  for (let c = 1; c < COLS; c++) {
    const x = (W / COLS) * c;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  }
  for (let r = 1; r < ROWS; r++) {
    const y = (H / ROWS) * r;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }

  if (_cropPoints.length === 0) return;

  const scaleX = W / cropImg.naturalWidth;
  const scaleY = H / cropImg.naturalHeight;

  // ── Square highlight (when 2 points set) ──────────────
  if (_cropPoints.length === 2) {
    const p1 = _cropPoints[0], p2 = _cropPoints[1];
    const sideNat = Math.abs(p2.x - p1.x);
    const left    = Math.min(p1.x, p2.x) * scaleX;
    const top     = Math.min(p1.y, p2.y) * scaleY;
    const side    = sideNat * scaleX;

    // Darken everything outside the square
    ctx.fillStyle = 'rgba(0,0,0,0.52)';
    ctx.fillRect(0,    0,   W,    top);               // above
    ctx.fillRect(0,    top + side, W, H - top - side); // below
    ctx.fillRect(0,    top,  left, side);              // left
    ctx.fillRect(left + side, top, W - left - side, side); // right

    // Square fill tint
    ctx.fillStyle = 'rgba(88,166,255,0.12)';
    ctx.fillRect(left, top, side, side);

    // Square border (dashed)
    ctx.strokeStyle   = '#58a6ff';
    ctx.lineWidth     = 2;
    ctx.setLineDash([6, 3]);
    ctx.strokeRect(left + 1, top + 1, side - 2, side - 2);
    ctx.setLineDash([]);

    // Corner markers
    const cs = 10;
    ctx.strokeStyle = '#58a6ff';
    ctx.lineWidth   = 2;
    [ [left, top], [left + side, top], [left, top + side], [left + side, top + side] ]
      .forEach(([cx, cy]) => {
        ctx.beginPath();
        ctx.moveTo(cx - cs, cy); ctx.lineTo(cx + cs, cy);
        ctx.moveTo(cx, cy - cs); ctx.lineTo(cx, cy + cs);
        ctx.stroke();
      });
  }

  // ── Click-point markers ────────────────────────────────
  const COLORS = ['#58a6ff', '#3fb950'];
  _cropPoints.forEach((pt, i) => {
    const dx = pt.x * scaleX;
    const dy = pt.y * scaleY;

    // Outer ring
    ctx.strokeStyle = COLORS[i];
    ctx.lineWidth   = 2;
    ctx.beginPath();
    ctx.arc(dx, dy, 9, 0, Math.PI * 2);
    ctx.stroke();

    // Inner dot
    ctx.fillStyle = COLORS[i];
    ctx.beginPath();
    ctx.arc(dx, dy, 4, 0, Math.PI * 2);
    ctx.fill();

    // Label
    ctx.fillStyle   = '#fff';
    ctx.font        = 'bold 11px system-ui, sans-serif';
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur  = 3;
    ctx.fillText(`P${i + 1}`, dx + 12, dy - 5);
    ctx.shadowBlur  = 0;
  });
}

// Canvas click — collect up to 2 points
cropCanvas.addEventListener('click', e => {
  if (_cropPoints.length >= 2) return;

  const r      = cropCanvas.getBoundingClientRect();
  const scaleX = cropImg.naturalWidth  / cropCanvas.width;
  const scaleY = cropImg.naturalHeight / cropCanvas.height;
  const x = Math.round((e.clientX - r.left) * scaleX);
  const y = Math.round((e.clientY - r.top)  * scaleY);

  _cropPoints.push({ x, y });
  redrawCanvas();
  updateCoordDisplay();
  if (_cropPoints.length === 2) cropConfirm.disabled = false;
});

function updateCoordDisplay() {
  const p1 = _cropPoints[0], p2 = _cropPoints[1];
  $('coord-p1').textContent = p1 ? `P1 : (${p1.x}, ${p1.y})` : 'P1 : —';
  $('coord-p2').textContent = p2 ? `P2 : (${p2.x}, ${p2.y})` : 'P2 : —';
  if (p1 && p2) {
    const w = Math.abs(p2.x - p1.x);
    $('coord-size').textContent = `Carré : ${w} × ${w} px`;
  } else {
    $('coord-size').textContent = 'Carré : —';
  }
}

// Buttons
$('crop-reset').addEventListener('click', () => {
  _cropPoints = [];
  redrawCanvas();
  updateCoordDisplay();
  cropConfirm.disabled = true;
});

cropConfirm.addEventListener('click', () => {
  if (!_cropData || _cropPoints.length < 2) return;
  if (!ws || ws.readyState !== WebSocket.OPEN) { addSysMsg('⚠️ Connexion perdue — rechargez la page.'); return; }
  const [p1, p2] = _cropPoints;
  ws.send(JSON.stringify({
    type:     'crop_done',
    url:      _cropData.url,
    x1: p1.x, y1: p1.y,
    x2: p2.x, y2: p2.y,
    position: _cropData.position,
  }));
  closeCropModal();
  addSysMsg('Recadrage confirmé — insertion en cours…');
});

$('crop-skip').addEventListener('click', () => {
  if (!_cropData) return;
  if (!ws || ws.readyState !== WebSocket.OPEN) { addSysMsg('⚠️ Connexion perdue — rechargez la page.'); return; }
  ws.send(JSON.stringify({
    type:       'crop_done',
    url:        _cropData.url,
    position:   _cropData.position,
    skip_crop:  true,
  }));
  closeCropModal();
  addSysMsg('Image conservée sans recadrage — insertion en cours…');
});

$('crop-close').addEventListener('click', closeCropModal);
// Click outside the box
$('crop-modal').addEventListener('click', e => {
  if (e.target === cropModal || e.target.classList.contains('crop-backdrop')) closeCropModal();
});

// Resync canvas if window resizes while modal is open
window.addEventListener('resize', () => {
  if (!cropModal.classList.contains('hidden') && cropImg.complete && cropImg.naturalWidth) {
    syncCanvasToImage();
    redrawCanvas();
  }
});

// ── Voice dictation inside crop modal ────────────────────────

function parseCropCoords(text) {
  // "P1 120, 45 P2 330, 45"  or  "point 1 à 120 45 point 2 à 330 45"
  const m = text.match(/[Pp](?:oint\s*)?1\D{1,6}(\d+)\D{1,6}(\d+)\D{1,10}[Pp](?:oint\s*)?2\D{1,6}(\d+)\D{1,6}(\d+)/);
  if (m) return [{ x: +m[1], y: +m[2] }, { x: +m[3], y: +m[4] }];

  // "x1 120 y1 45 x2 330 y2 45"
  const m2 = text.match(/x1?\D{0,3}(\d+)\D{1,6}y1?\D{0,3}(\d+)\D{1,6}x2?\D{0,3}(\d+)\D{1,6}y2?\D{0,3}(\d+)/i);
  if (m2) return [{ x: +m2[1], y: +m2[2] }, { x: +m2[3], y: +m2[4] }];

  // Last resort: first 4 numbers
  const nums = (text.match(/\d+/g) || []).map(Number);
  if (nums.length >= 4) return [{ x: nums[0], y: nums[1] }, { x: nums[2], y: nums[3] }];
  return null;
}

const cropMicBtn   = $('crop-mic-btn');
const cropVoiceHint = $('crop-voice-hint');
let cropListening  = false;
let cropRecog      = null;

if (SpeechRec) {
  cropRecog = new SpeechRec();
  cropRecog.lang = 'fr-FR';
  cropRecog.continuous = false;
  cropRecog.interimResults = false;

  cropRecog.addEventListener('start', () => {
    cropListening = true;
    cropMicBtn.classList.add('listening');
    cropMicBtn.querySelector('.mic-lbl').textContent = 'Écoute…';
    cropVoiceHint.textContent = '🎙 Dites les coordonnées…';
  });

  cropRecog.addEventListener('result', e => {
    const transcript = e.results[0][0].transcript;
    cropVoiceHint.textContent = `"${transcript}"`;
    const pts = parseCropCoords(transcript);
    if (pts) {
      _cropPoints = pts;
      redrawCanvas();
      updateCoordDisplay();
      cropConfirm.disabled = false;
      cropVoiceHint.textContent = `✓ P1(${pts[0].x},${pts[0].y}) · P2(${pts[1].x},${pts[1].y})`;
    } else {
      cropVoiceHint.textContent = `Pas compris : "${transcript}". Format : P1 X, Y P2 X, Y`;
    }
  });

  cropRecog.addEventListener('end', () => {
    cropListening = false;
    cropMicBtn.classList.remove('listening');
    cropMicBtn.querySelector('.mic-lbl').textContent = 'Dicter';
  });

  cropRecog.addEventListener('error', e => {
    cropListening = false;
    cropMicBtn.classList.remove('listening');
    cropMicBtn.querySelector('.mic-lbl').textContent = 'Dicter';
    cropVoiceHint.textContent = `Erreur : ${e.error}`;
  });
} else {
  cropMicBtn.disabled = true;
  cropVoiceHint.textContent = 'Vocal non disponible (utilisez Chrome/Edge)';
}

cropMicBtn.addEventListener('click', () => {
  if (!cropRecog) return;
  cropListening ? cropRecog.stop() : cropRecog.start();
});

// ── Tab navigation ───────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;

    document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b === btn));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.toggle('active', p.id === `tab-${tab}`));

    const previewMeta = $('preview-meta');
    if (previewMeta) previewMeta.style.visibility = tab === 'preview' ? '' : 'hidden';

    if (tab === 'admin') { loadAdminConfig(); loadWaFilter(); }
  });
});

// ── Administration panel ──────────────────────────────────────
function pill(text) {
  const s = document.createElement('span');
  s.className = 'admin-pill';
  s.textContent = text;
  return s;
}

// ── Recipients management ─────────────────────────────────────
let _recipients = [];

function renderRecipients(editMode) {
  const recipEl  = $('adm-recipients');
  const addRow   = $('adm-recipients-add-row');
  const btnEdit  = $('btn-recipients-edit');
  const btnSave  = $('btn-recipients-save');
  const btnCancel = $('btn-recipients-cancel');
  if (!recipEl) return;

  recipEl.innerHTML = '';
  if (_recipients.length) {
    _recipients.forEach(r => {
      if (editMode) {
        const span = document.createElement('span');
        span.className = 'admin-pill';
        span.style.cssText = 'display:inline-flex;align-items:center;gap:3px;';
        span.appendChild(document.createTextNode(r));
        const x = document.createElement('button');
        x.textContent = '×';
        x.title = 'Retirer';
        x.style.cssText = 'border:none;background:none;cursor:pointer;color:inherit;font-size:14px;line-height:1;padding:0 0 0 3px;';
        x.addEventListener('click', () => {
          _recipients = _recipients.filter(e => e !== r);
          renderRecipients(true);
        });
        span.appendChild(x);
        recipEl.appendChild(span);
      } else {
        recipEl.appendChild(pill(r));
      }
    });
  } else {
    recipEl.textContent = '(aucun destinataire)';
  }

  if (addRow)    addRow.style.display   = editMode ? 'flex' : 'none';
  if (btnEdit)   btnEdit.style.display  = editMode ? 'none' : '';
  if (btnSave)   btnSave.style.display  = editMode ? ''     : 'none';
  if (btnCancel) btnCancel.style.display = editMode ? ''    : 'none';
}

document.addEventListener('click', async e => {
  if (e.target.id === 'btn-recipients-edit') {
    renderRecipients(true);
    return;
  }
  if (e.target.id === 'btn-recipients-cancel') {
    try {
      const res  = await fetch('/api/admin/config');
      const data = await res.json();
      _recipients = (data.email.recipients || []).slice();
    } catch { /* keep current */ }
    renderRecipients(false);
    return;
  }
  if (e.target.id === 'btn-recipients-save') {
    try {
      const res = await fetch('/api/admin/recipients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipients: _recipients }),
      });
      const json = await res.json();
      if (json.status === 'ok') {
        renderRecipients(false);
        addSysMsg(`✅ Destinataires mis à jour : ${_recipients.join(', ') || '(aucun)'}`);
      } else {
        addSysMsg(`⚠ ${json.message || 'Erreur lors de la mise à jour'}`);
      }
    } catch (err) {
      addSysMsg(`⚠ Erreur réseau : ${err.message}`);
    }
    return;
  }
  if (e.target.id === 'btn-recipients-add') {
    const input = $('adm-recipients-new');
    if (!input) return;
    const email = input.value.trim();
    if (!email || !email.includes('@')) { input.focus(); return; }
    if (!_recipients.includes(email)) {
      _recipients.push(email);
      renderRecipients(true);
    }
    input.value = '';
    input.focus();
  }
});

// Allow Enter key in the new-email input
document.addEventListener('keydown', e => {
  if (e.target.id === 'adm-recipients-new' && e.key === 'Enter') {
    e.preventDefault();
    const btn = $('btn-recipients-add');
    if (btn) btn.click();
  }
});

function badge(text, type) {
  const s = document.createElement('span');
  s.className = `adm-badge ${type}`;
  s.textContent = text;
  return s;
}

function check(yes) {
  const s = document.createElement('span');
  s.className = yes ? 'adm-check' : 'adm-cross';
  s.textContent = yes ? '✓ Oui' : '✗ Non';
  return s;
}

async function loadAdminConfig() {
  const statusEl = $('adm-wa-status');
  if (statusEl) { statusEl.className = 'adm-badge'; statusEl.textContent = '…'; }

  try {
    const res  = await fetch('/api/admin/config');
    const data = await res.json();

    // Email
    const gmailEl = $('adm-gmail-user');
    if (gmailEl) gmailEl.textContent = data.email.gmail_user || '(non configuré)';

    _recipients = (data.email.recipients || []).slice();
    renderRecipients(false);

    // WhatsApp
    const waUrlEl = $('adm-wa-url');
    if (waUrlEl) waUrlEl.textContent = data.whatsapp.bridge_url;

    if (statusEl) {
      const s = data.whatsapp.bridge_status;
      const [label, type] =
        s === 'open'       ? ['Connecté', 'ok']  :
        s === 'qr'         ? ['En attente QR', 'warn'] :
        s === 'connecting' ? ['Connexion…', 'warn'] :
        s === 'offline'    ? ['Hors ligne', 'err'] :
                             [s, 'err'];
      statusEl.textContent = label;
      statusEl.className = `adm-badge ${type}`;
    }

    const numEl = $('adm-wa-numbers');
    if (numEl) {
      numEl.innerHTML = '';
      if (data.whatsapp.allowed_numbers.length) {
        data.whatsapp.allowed_numbers.forEach(n => numEl.appendChild(pill(n)));
      } else {
        numEl.textContent = 'Tous autorisés (dev)';
      }
    }

    // Système
    const hostEl = $('adm-host');
    if (hostEl) hostEl.textContent = `${data.system.host}:${data.system.port}`;

    const sslEl = $('adm-ssl');
    if (sslEl) { sslEl.innerHTML = ''; sslEl.appendChild(check(data.system.ssl_verify)); }

    const tavEl = $('adm-tavily');
    if (tavEl) {
      tavEl.innerHTML = '';
      if (data.system.tavily_configured) {
        tavEl.appendChild(check(true));
        tavEl.append(' Tavily');
      } else {
        tavEl.appendChild(check(false));
        tavEl.append(' DuckDuckGo (fallback)');
      }
    }

    const ytEl = $('adm-youtube');
    if (ytEl) {
      ytEl.innerHTML = '';
      if (data.system.youtube_configured) {
        ytEl.appendChild(check(true));
        ytEl.append(' API configurée');
      } else {
        ytEl.appendChild(check(false));
        ytEl.append(' Scraping (fallback)');
      }
    }

    const providerEl = $('adm-llm-provider');
    if (providerEl) providerEl.textContent = data.system.llm_provider === 'openai' ? 'OpenAI' : 'Anthropic (Claude)';

    const keyEl = $('adm-llm-key');
    if (keyEl) { keyEl.innerHTML = ''; keyEl.appendChild(check(data.system.llm_configured)); }

    const modelsEl = $('adm-llm-models');
    if (modelsEl) modelsEl.textContent = `${data.system.llm_model} / ${data.system.llm_model_fast}`;

    // Cost
    if (data.cost) {
      const costEl = $('adm-cost-total');
      if (costEl) costEl.textContent = `$${data.cost.session_cost_usd.toFixed(4)}`;

      const inEl = $('adm-cost-input');
      if (inEl) inEl.textContent = data.cost.session_input_tokens.toLocaleString('fr-FR') + ' tok';

      const outEl = $('adm-cost-output');
      if (outEl) outEl.textContent = data.cost.session_output_tokens.toLocaleString('fr-FR') + ' tok';

      const ctxEl = $('adm-context-tokens');
      if (ctxEl) {
        const ctx = data.cost.last_context_tokens;
        ctxEl.textContent = ctx ? ctx.toLocaleString('fr-FR') + ' tok' : '—';
      }

      const turnsEl = $('adm-conv-turns');
      if (turnsEl) turnsEl.textContent = data.cost.conversation_turns || '0';
    }

  } catch (err) {
    if (statusEl) { statusEl.textContent = 'Erreur'; statusEl.className = 'adm-badge err'; }
    addSysMsg(`⚠ Impossible de charger la configuration admin : ${err.message}`);
  }
}

// ── WhatsApp conversation filter ──────────────────────────────
function waEntryMatchesSender(entry, number, name) {
  const entryDigits = entry.replace(/\D/g, '');
  const clean = (number || '').replace(/\D/g, '');
  if (entryDigits && entryDigits === clean) return true;
  return entry.trim().toLowerCase() === (name || '').trim().toLowerCase();
}

function makeWaSenderRow({ number, name, lastSeen, checked, manual }) {
  // Built via DOM APIs (not innerHTML) — number/name come from WhatsApp push
  // names / group subjects, which are attacker-controlled and must never be
  // parsed as HTML.
  const row = document.createElement('label');
  row.className = 'sender-row';

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.dataset.number = number;
  checkbox.checked = !!checked;
  row.appendChild(checkbox);

  const nameSpan = document.createElement('span');
  nameSpan.className = 'sender-name';
  nameSpan.textContent = name || number;
  row.appendChild(nameSpan);

  const numberSpan = document.createElement('span');
  numberSpan.className = 'sender-number';
  numberSpan.textContent = name !== number ? number : '';
  row.appendChild(numberSpan);

  const lastSpan = document.createElement('span');
  lastSpan.className = 'sender-last';
  lastSpan.textContent = manual ? '(ajouté manuellement)' : (lastSeen ? lastSeen.replace('T', ' ').slice(0, 16) : '');
  row.appendChild(lastSpan);

  if (manual) {
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'btn btn-ghost btn-wa-remove';
    removeBtn.style.fontSize = '11px';
    removeBtn.style.padding = '1px 7px';
    removeBtn.textContent = '✕';
    row.appendChild(removeBtn);
  }

  return row;
}

async function loadWaFilter() {
  const container = $('adm-wa-senders');
  if (!container) return;
  try {
    const res  = await fetch('/api/admin/whatsapp/filter');
    const data = await res.json();
    const filterEntries = data.filter_numbers;

    container.innerHTML = '';

    // checked reflects the server's actual authorization decision (filter list
    // if configured, else the WHATSAPP_ALLOWED_NUMBERS env fallback) — so a
    // brand-new group that just messaged in shows up unchecked and can be
    // switched on right here, without editing .env or restarting anything.
    for (const s of data.recent_senders) {
      container.appendChild(makeWaSenderRow({
        number: s.number, name: s.name, lastSeen: s.last_seen, checked: s.authorized, manual: false,
      }));
    }

    // Filter entries added manually that don't correspond to any tracked sender yet
    for (const entry of filterEntries) {
      const known = data.recent_senders.some(s => waEntryMatchesSender(entry, s.number, s.name));
      if (known) continue;
      container.appendChild(makeWaSenderRow({
        number: entry, name: entry, lastSeen: null, checked: true, manual: true,
      }));
    }

    if (!container.children.length) {
      container.innerHTML = '<em style="color:var(--text-muted);font-size:12px">Aucun message reçu pour l\'instant.</em>';
    }
  } catch (err) {
    if (container) container.innerHTML = `<em style="color:var(--error)">Erreur : ${err.message}</em>`;
  }
}

document.addEventListener('click', async e => {
  if (e.target.id === 'btn-wa-filter-none') {
    document.querySelectorAll('#adm-wa-senders input[type=checkbox]').forEach(cb => cb.checked = false);
  }
  if (e.target.classList.contains('btn-wa-remove')) {
    e.preventDefault();
    e.target.closest('.sender-row')?.remove();
  }
  if (e.target.id === 'btn-wa-manual-add') {
    const input = $('adm-wa-manual-input');
    const value = (input?.value || '').trim();
    if (!value) return;
    const container = $('adm-wa-senders');
    const exists = [...container.querySelectorAll('input[type=checkbox]')]
      .some(cb => waEntryMatchesSender(value, cb.dataset.number, cb.dataset.number));
    if (exists) { input.value = ''; return; }
    const placeholder = container.querySelector('em');
    if (placeholder) container.innerHTML = '';
    container.appendChild(makeWaSenderRow({ number: value, name: value, lastSeen: null, checked: true, manual: true }));
    input.value = '';
  }
  if (e.target.id === 'btn-wa-filter-save') {
    const checked = [...document.querySelectorAll('#adm-wa-senders input[type=checkbox]:checked')]
      .map(cb => cb.dataset.number);
    e.target.disabled = true;
    try {
      await fetch('/api/admin/whatsapp/filter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ numbers: checked }),
      });
      await loadWaFilter();
    } finally {
      e.target.disabled = false;
    }
  }
});

document.addEventListener('keydown', e => {
  if (e.target.id === 'adm-wa-manual-input' && e.key === 'Enter') {
    e.preventDefault();
    $('btn-wa-manual-add')?.click();
  }
});

// ── Cost reset button ─────────────────────────────────────────
document.addEventListener('click', async e => {
  if (e.target.id !== 'btn-cost-reset') return;
  e.target.disabled = true;
  try {
    await fetch('/api/admin/cost/reset', { method: 'POST' });
    await loadAdminConfig();
  } finally {
    e.target.disabled = false;
  }
});

// ── Re-crop from iframe image click ──────────────────────────
window.addEventListener('message', e => {
  if (!e.data || e.data.type !== 'recrop_image') return;
  if (e.origin !== window.location.origin) return;
  const artUrl = e.data.articleUrl;
  if (!artUrl || !ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({ type: 'recrop_article', url: artUrl }));
});

window.addEventListener('message', async e => {
  if (!e.data || e.data.type !== 'newsletter_alternative_drop') return;
  if (e.origin !== window.location.origin) return;
  const { targetUrl, suggestion } = e.data;
  if (!targetUrl || !suggestion?.url) return;
  try {
    const res = await fetch('/api/newsletter/alternatives/replace', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target_url: targetUrl, suggestion }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      addSysMsg(`✅ Article remplacé par : ${suggestion.title || 'nouvelle suggestion'}`);
      refreshPreview();
      await loadAlternativeSuggestions();
    } else {
      addSysMsg(`⚠ ${json.message || 'Remplacement impossible'}`);
    }
  } catch (err) {
    addSysMsg(`⚠ Erreur réseau : ${err.message}`);
  }
});

// ── Delete article from the preview iframe ──────────────────
window.addEventListener('message', async e => {
  if (!e.data || e.data.type !== 'delete_article') return;
  if (e.origin !== window.location.origin) return;
  const url = e.data.url;
  if (!url) return;
  try {
    const res = await fetch('/api/newsletter/article/remove', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      refreshPreview();
      loadAlternativeSuggestions();
    } else {
      addSysMsg(`⚠ ${json.message || 'Impossible de supprimer l\'article'}`);
    }
  } catch (err) {
    addSysMsg(`⚠ Erreur réseau : ${err.message}`);
  }
});

// ── Inline edits from the preview iframe ─────────────────────
window.addEventListener('message', async e => {
  if (!e.data || e.data.type !== 'newsletter_inline_edit') return;
  if (e.origin !== window.location.origin) return;

  const { section, index, field, value } = e.data;
  try {
    const res = await fetch('/api/newsletter/inline-edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ section, index, field, value }),
    });
    const json = await res.json();
    if (json.status === 'ok') {
      updatedAt.textContent = `Mis à jour ${new Date().toLocaleTimeString('fr-FR')}`;
    } else {
      addSysMsg(`Erreur d'édition inline : ${json.message}`);
    }
  } catch {
    addSysMsg('Erreur réseau lors de la sauvegarde.');
  }
});

// ── Web search pill ───────────────────────────────────────────
document.getElementById('pill-search')?.addEventListener('click', () => {
  const q = prompt('Décris l\'article à rechercher sur le web :');
  if (!q || !q.trim()) return;
  chatInput.value = `Recherche sur le web un article sur : ${q.trim()}`;
  chatInput.focus();
});

// ── URL pill — read clipboard and prefill ─────────────────────
document.getElementById('pill-url')?.addEventListener('click', async () => {
  let url = '';
  try {
    url = (await navigator.clipboard.readText()).trim();
  } catch {
    // Clipboard API denied — prompt instead
    url = prompt('Collez l\'URL de l\'article :') || '';
  }
  if (!url) return;
  const isUrl = /^https?:\/\//i.test(url);
  chatInput.value = isUrl
    ? `Ajoute cet article à la newsletter : ${url}`
    : url;
  chatInput.focus();
});
