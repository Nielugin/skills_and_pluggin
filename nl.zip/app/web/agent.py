"""
Claude agent with MCP-style newsletter skills.

Skills exposed as tools:
  get_newsletter_state    — read current article list
  fetch_and_add_article   — search RSS on topic + insert at position
  add_article_from_url    — scrape a user-provided URL and insert it
  remove_article          — delete by position or title keyword
  move_article            — reorder to new position
  refresh_all_articles    — full RSS refresh
  render_preview          — re-render HTML
"""
import asyncio
import json
import logging
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncGenerator, Optional

sys.path.insert(0, str(Path(__file__).parent.parent))

from web import llm_client
from web.state import newsletter_state

logger = logging.getLogger(__name__)

# Pricing per million tokens (input, output)
_MODEL_PRICING: dict[str, tuple[float, float]] = {
    "claude-sonnet-4-6":         (3.00, 15.00),
    "claude-haiku-4-5-20251001": (1.00,  5.00),
    "gpt-4.1":                   (2.00,  8.00),
    "gpt-4.1-mini":              (0.40,  1.60),
    "gpt-4o":                    (2.50, 10.00),
    "gpt-4o-mini":               (0.15,  0.60),
}


def _accumulate_cost(usage, model: str) -> None:
    """Add token usage from a Claude API response to the session totals."""
    in_tok  = getattr(usage, "input_tokens",  0) or 0
    out_tok = getattr(usage, "output_tokens", 0) or 0
    price_in, price_out = _MODEL_PRICING.get(model, (0.0, 0.0))
    cost = (in_tok * price_in + out_tok * price_out) / 1_000_000
    newsletter_state.session_input_tokens  += in_tok
    newsletter_state.session_output_tokens += out_tok
    newsletter_state.session_cost_usd      += cost


_conversation_history: list[dict] = []
_pending_articles: dict = {}  # url → {article, position} en attente de crop

# Image fixe pour la section Capgemini — ne pas modifier sans demande explicite
_CAPGEMINI_FIXED_IMAGE = "/assets/capgemini_square.png"


def _build_alternative_suggestions(existing_articles: list[dict], candidates: list[dict], limit: int = 8, excluded_urls: Optional[set[str]] = None) -> list[dict]:
    """Build alternative suggestion cards excluding current newsletter items and duplicates."""
    excluded = set(excluded_urls or set())
    existing_urls = {article.get("url") for article in existing_articles if article.get("url")}
    excluded.update(existing_urls)

    suggestions: list[dict] = []
    for candidate in candidates:
        url = candidate.get("url")
        if not url or url in excluded:
            continue
        if any(existing.get("url") == url for existing in suggestions):
            continue
        suggestions.append(candidate)
        excluded.add(url)
        if len(suggestions) >= limit:
            break
    return suggestions


def _get_alternative_suggestions(existing_articles: Optional[list[dict]] = None, limit: int = 8, excluded_urls: Optional[set[str]] = None) -> list[dict]:
    """Fetch alternative articles from RSS sources and remove items already present in the newsletter."""
    from fetchers.news import enrich_with_images, fetch_all_articles

    reference = _newsletter_reference_datetime()
    articles = fetch_all_articles(max_age_days=10, reference_date=reference)
    relevant = [article for article in articles if article.get("score", 0) > 0]
    relevant.sort(key=lambda article: (article.get("score", 0), article.get("published") or reference), reverse=True)
    candidates = relevant[:24]
    enrich_with_images(candidates, delay=0.05)
    return _build_alternative_suggestions(existing_articles or newsletter_state.market_articles, candidates, limit=limit, excluded_urls=excluded_urls)

SYSTEM_PROMPT = """\
Tu es l'assistant de la newsletter "Capgemini Innovation Watch & Upcoming Trends".
Tu aides l'utilisateur à configurer et personnaliser le contenu de la newsletter.

Capacités :
- Afficher l'état actuel (articles, positions, sources, thèmes)
- Rechercher et ajouter des articles sur un thème spécifique à une position donnée
- Ajouter un article directement depuis une URL fournie par l'utilisateur
- Supprimer des articles (par position ou mot-clé dans le titre)
- Déplacer des articles vers une autre position
- Rafraîchir tous les articles depuis les flux RSS
- Régénérer le rendu HTML de la newsletter
- Gérer la section Capgemini Technology : remplacer l'article via URL ou RSS, le supprimer
- Gérer la section Reuters/Keep a look outside : remplacer via URL (set_reuters_from_url) ou recharger depuis YouTube (refresh_reuters_video), la lire (get_reuters_video), la définir avec titre, lien, description et capture (set_reuters_video), modifier un champ (update_reuters_video) ou la supprimer (remove_reuters_video)
- Changer le numéro de newsletter (set_newsletter_number) ou sa date de référence (set_newsletter_date)

Thèmes disponibles : AI, EV, quantum, robotics, cloud, venture, energy, industry.
Réponds en français, sois concis et confirme chaque action effectuée avec le résultat.
- Générer un aperçu visuel (capture d'écran) de la newsletter pour envoi WhatsApp via screenshot_newsletter.

Contrainte image Capgemini : l'image de la section Capgemini Technology est fixe et ne doit
JAMAIS être modifiée sauf si l'utilisateur demande explicitement de changer l'image de l'article
Capgemini. Ne propose pas de recadrage ni de remplacement d'image pour cette section.

Numéros et dates de newsletter — set_newsletter_number(number) recharge une édition déjà
construite (même contenu exact que la dernière fois, aucune recherche d'articles) si ce
numéro est connu ; sinon il démarre une édition toute neuve (recherche RSS complète, edito
par défaut, date remise à aujourd'hui). set_newsletter_date(date) change uniquement la date
de référence affichée et utilisée pour juger si un article est trop ancien — utile après avoir
rouvert une édition passée dont la date doit être ajustée.

Cas particulier — add_article_from_url et set_capgemini_from_url :
Si le résultat contient needs_crop: true, informe l'utilisateur que l'article a été trouvé
et qu'une fenêtre de recadrage d'image s'est ouverte. Il doit y cliquer les deux points
supérieurs du carré de sélection (ou dicter les coordonnées vocalement), puis confirmer.
L'article sera inséré/défini automatiquement après la confirmation du crop.
"""

TOOLS = [
    {
        "name": "get_newsletter_state",
        "description": "Retourne l'état actuel de la newsletter : liste des articles avec position, titre, source et thèmes couverts.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "fetch_and_add_article",
        "description": (
            "Recherche un article frais sur un thème/mot-clé depuis les flux RSS "
            "et l'insère dans la newsletter à la position souhaitée."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "topic": {
                    "type": "string",
                    "description": "Thème ou mot-clé (ex: 'quantum', 'véhicules électriques', 'IA générative')",
                },
                "position": {
                    "type": "integer",
                    "description": "Position 1-based d'insertion. -1 pour ajouter en fin de liste.",
                },
            },
            "required": ["topic"],
        },
    },
    {
        "name": "remove_article",
        "description": "Supprime un article de la newsletter par sa position (1-based) ou un mot-clé de son titre.",
        "input_schema": {
            "type": "object",
            "properties": {
                "position": {"type": "integer", "description": "Position 1-based (optionnel si title_keyword fourni)"},
                "title_keyword": {"type": "string", "description": "Mot-clé dans le titre (optionnel si position fournie)"},
            },
        },
    },
    {
        "name": "move_article",
        "description": "Déplace un article vers une nouvelle position dans la newsletter.",
        "input_schema": {
            "type": "object",
            "properties": {
                "to_position": {"type": "integer", "description": "Nouvelle position 1-based cible"},
                "from_position": {"type": "integer", "description": "Position source 1-based (optionnel si title_keyword fourni)"},
                "title_keyword": {"type": "string", "description": "Mot-clé dans le titre de l'article à déplacer"},
            },
            "required": ["to_position"],
        },
    },
    {
        "name": "search_and_add_article",
        "description": (
            "Recherche un article sur le web à partir d'une description libre de l'utilisateur "
            "(ex : 'un article récent sur la fusion nucléaire', 'news drone militaire'), "
            "récupère le meilleur résultat et l'insère dans la newsletter. "
            "Utilise Brave Search si BRAVE_SEARCH_API_KEY est configuré, sinon DuckDuckGo."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Description ou mots-clés de l'article recherché",
                },
                "position": {
                    "type": "integer",
                    "description": "Position 1-based d'insertion. -1 pour ajouter en fin de liste.",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "add_article_from_url",
        "description": (
            "Récupère le contenu d'une URL fournie par l'utilisateur (titre, résumé, image) "
            "et insère cet article dans la newsletter à la position souhaitée."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL complète de l'article à ajouter (ex: https://techcrunch.com/...)",
                },
                "position": {
                    "type": "integer",
                    "description": "Position 1-based d'insertion. -1 pour ajouter en fin de liste.",
                },
            },
            "required": ["url"],
        },
    },
    {
        "name": "update_article_summary",
        "description": (
            "Modifie le résumé (abstract) d'un article. "
            "Pour un article Market : identifier par position ou mot-clé dans le titre. "
            "Pour l'article Capgemini : passer section='capgemini'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "summary": {
                    "type": "string",
                    "description": "Nouveau texte du résumé/abstract",
                },
                "position": {
                    "type": "integer",
                    "description": "Position 1-based de l'article Market (optionnel si title_keyword fourni)",
                },
                "title_keyword": {
                    "type": "string",
                    "description": "Mot-clé dans le titre pour identifier l'article Market",
                },
                "section": {
                    "type": "string",
                    "enum": ["market", "capgemini"],
                    "description": "Section cible : 'market' (défaut) ou 'capgemini'",
                },
            },
            "required": ["summary"],
        },
    },
    {
        "name": "set_capgemini_from_url",
        "description": (
            "Scrape une URL fournie par l'utilisateur et la définit comme article de la section "
            "Capgemini Technology (remplace l'article existant). Déclenche le recadrage d'image si une image est trouvée."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL de l'article Capgemini à afficher"},
            },
            "required": ["url"],
        },
    },
    {
        "name": "refresh_capgemini_article",
        "description": "Recharge l'article Capgemini Technology depuis le flux RSS / site officiel Capgemini.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "set_reuters_from_url",
        "description": (
            "Définit le contenu de la section 'Keep a look outside' (Reuters) à partir d'une URL "
            "(vidéo YouTube ou article web). Remplace la vidéo/article Reuters actuel."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL de la vidéo YouTube ou de l'article à afficher"},
            },
            "required": ["url"],
        },
    },
    {
        "name": "get_reuters_video",
        "description": "Lit la section Reuters actuelle : titre, lien, description et image.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "set_reuters_video",
        "description": (
            "Définit entièrement la section 'Keep a look outside' (Reuters) à partir d'une vidéo déjà "
            "choisie : titre, lien, description et capture. Utilisé par le skill nl:newsletter-reuters, "
            "qui parcourt reuters.com/video dans un vrai navigateur."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Titre de la vidéo"},
                "video_url": {"type": "string", "description": "Lien de la vidéo (https://...)"},
                "description": {"type": "string", "description": "Description courte (300 caractères max)"},
                "thumbnail_url": {"type": "string", "description": "URL http(s) de l'image/poster de la vidéo"},
                "thumbnail_data_url": {"type": "string", "description": "Capture de la vidéo en data URL (data:image/...;base64,...)"},
            },
            "required": ["title", "video_url"],
        },
    },
    {
        "name": "update_reuters_video",
        "description": (
            "Modifie un ou plusieurs champs de la section Reuters (titre, lien, description, image). "
            "Les champs omis restent inchangés."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Nouveau titre"},
                "video_url": {"type": "string", "description": "Nouveau lien de la vidéo"},
                "description": {"type": "string", "description": "Nouvelle description (300 caractères max)"},
                "thumbnail_url": {"type": "string", "description": "Nouvelle image (URL http(s))"},
                "thumbnail_data_url": {"type": "string", "description": "Nouvelle image (data URL base64)"},
            },
            "required": [],
        },
    },
    {
        "name": "remove_reuters_video",
        "description": "Supprime la vidéo de la section Reuters.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "refresh_reuters_video",
        "description": "Recharge la dernière vidéo Reuters depuis la chaîne YouTube Reuters.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "remove_capgemini_article",
        "description": "Supprime l'article de la section Capgemini Technology (la section apparaîtra vide).",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "set_edito",
        "description": (
            "Crée ou remplace le contenu de l'edito (article d'introduction). "
            "L'identité de l'auteur (nom, photo, titres) est verrouillée et ne peut pas être modifiée via cet outil. "
            "Le champ 'content' accepte du HTML simple (<ul><li>…</li></ul>, <b>, <em>)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "article_title": {"type": "string", "description": "Titre de l'article de l'edito"},
                "content":       {"type": "string", "description": "Corps de l'edito en HTML simple"},
            },
            "required": ["article_title", "content"],
        },
    },
    {
        "name": "update_edito",
        "description": (
            "Modifie un ou plusieurs champs du contenu de l'edito existant sans tout remplacer. "
            "L'identité de l'auteur (nom, photo, titres) est verrouillée et ne peut pas être modifiée."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "article_title": {"type": "string"},
                "content":       {"type": "string"},
            },
        },
    },
    {
        "name": "get_edito",
        "description": (
            "Retourne l'edito actuel (titre, corps, auteur) et indique si sa signature "
            "(« Sincerely yours » puis « Patrice ») est conforme avant l'envoi."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "remove_edito",
        "description": "Supprime l'edito de la newsletter.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "check_edito_from_email",
        "description": (
            "Vérifie la boîte Gmail pour un e-mail dont l'objet contient le titre et le numéro "
            "de la newsletter courante. Si trouvé, extrait le contenu de l'édito (même si l'e-mail "
            "est un transfert) et remplace l'édito actuel de la newsletter."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "send_newsletter",
        "description": (
            "Génère un PDF de la newsletter et l'envoie par e-mail aux destinataires configurés "
            "(EMAIL_RECIPIENTS dans .env). Confirme le succès ou rapporte l'erreur."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "refresh_all_articles",
        "description": "Rafraîchit tous les articles depuis les flux RSS (remplace les articles actuels par les plus récents).",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "render_preview",
        "description": "Régénère le rendu HTML de la newsletter après des modifications manuelles.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "screenshot_newsletter",
        "description": (
            "Génère une capture d'écran fidèle de la newsletter (image JPEG pleine page) "
            "et la renvoie pour envoi WhatsApp. À utiliser quand l'utilisateur demande un aperçu visuel, "
            "une preview image, un screenshot ou une photo de la newsletter."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "set_newsletter_number",
        "description": (
            "Change le numéro de la newsletter courante. "
            "Si ce numéro correspond à une édition déjà construite précédemment, elle est "
            "rechargée telle quelle (articles, edito, sections) sans aucune recherche RSS. "
            "Si le numéro n'a jamais été utilisé, une toute nouvelle édition est créée "
            "(recherche RSS complète, edito par défaut, date remise à aujourd'hui)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "number": {"type": "integer", "description": "Nouveau numéro de newsletter (≥ 1)"},
            },
            "required": ["number"],
        },
    },
    {
        "name": "get_newsletter_date",
        "description": (
            "Retourne la date de référence de la newsletter courante, ou d'une édition "
            "existante si `number` est fourni (sans la charger)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"number": {"type": "integer", "description": "Numéro d'édition (optionnel)"}},
            "required": [],
        },
    },
    {
        "name": "list_newsletters",
        "description": "Liste les éditions existantes (numéro, date, titre, titre d'édito, nb d'articles).",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "get_newsletter_title",
        "description": "Retourne le titre de la newsletter (affiché dans l'en-tête et le <title>).",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "set_newsletter_title",
        "description": "Modifie le titre de la newsletter (affiché dans l'en-tête, suivi de #numéro).",
        "input_schema": {
            "type": "object",
            "properties": {"title": {"type": "string", "description": "Nouveau titre"}},
            "required": ["title"],
        },
    },
    {
        "name": "set_newsletter_date",
        "description": (
            "Modifie la date de référence de la newsletter (format AAAA-MM-JJ). "
            "Cette date est affichée dans l'en-tête et sert de repère pour juger de la "
            "fraîcheur des articles : un article est considéré « trop ancien » par rapport "
            "à cette date, pas par rapport à la date du jour réelle. Utile en particulier "
            "quand on rouvre une édition passée."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "date": {"type": "string", "description": "Date au format AAAA-MM-JJ (ex: 2026-07-19)"},
            },
            "required": ["date"],
        },
    },
    {
        "name": "recrop_article",
        "description": (
            "Ouvre la fenêtre de recadrage pour l'image d'un article déjà inséré dans la newsletter. "
            "À utiliser quand l'utilisateur veut ajuster manuellement le cadrage d'une vignette."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "position":      {"type": "integer", "description": "Position 1-based de l'article"},
                "title_keyword": {"type": "string",  "description": "Mot-clé dans le titre"},
            },
        },
    },
]

MODIFYING_TOOLS = {
    "fetch_and_add_article", "add_article_from_url", "search_and_add_article",
    "remove_article", "move_article", "update_article_summary",
    "set_capgemini_from_url", "refresh_capgemini_article", "remove_capgemini_article",
    "set_reuters_from_url", "refresh_reuters_video", "set_reuters_video",
    "update_reuters_video", "remove_reuters_video",
    "set_edito", "update_edito", "remove_edito", "check_edito_from_email",
    "refresh_all_articles", "render_preview", "set_newsletter_number",
    "set_newsletter_date", "set_newsletter_title",
}


# ── Skill implementations ─────────────────────────────────────

from paths import COUNTER_FILE as _COUNTER_FILE


def _read_counter_number(default: int) -> int:
    try:
        return int(_COUNTER_FILE.read_text().strip())
    except Exception:
        return default


def _write_counter_number(number: int) -> None:
    _COUNTER_FILE.write_text(str(number))


def _today_str() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def _newsletter_reference_datetime() -> datetime:
    """'Now', for article-freshness checks — anchored to the newsletter's own
    date rather than the real today, so reopening a past edition still judges
    article age relative to when that edition was actually put together."""
    try:
        d = datetime.strptime(newsletter_state.newsletter_date, "%Y-%m-%d")
    except (ValueError, TypeError):
        return datetime.now(timezone.utc)
    return d.replace(hour=12, tzinfo=timezone.utc)


def _format_newsletter_date(iso_date: str) -> str:
    try:
        return datetime.strptime(iso_date, "%Y-%m-%d").strftime("%B %d, %Y")
    except (ValueError, TypeError):
        return datetime.now().strftime("%B %d, %Y")


def _render_state() -> None:
    import datetime as dt
    from generator.html_gen import render_newsletter
    from web.newsletter_store import save_snapshot

    newsletter_state.newsletter_number = _read_counter_number(newsletter_state.newsletter_number)

    _, html = render_newsletter(
        market_articles=newsletter_state.market_articles,
        capgemini_article=newsletter_state.capgemini_article,
        reuters_video=newsletter_state.reuters_video,
        newsletter_number=newsletter_state.newsletter_number,
        newsletter_title=newsletter_state.newsletter_title,
        edito=newsletter_state.edito,
        generation_date=_format_newsletter_date(newsletter_state.newsletter_date),
    )
    newsletter_state.preview_html = html
    newsletter_state.last_updated = dt.datetime.now()
    save_snapshot(newsletter_state)


def skill_get_newsletter_state() -> dict:
    return {
        "newsletter_number": newsletter_state.newsletter_number,
        "article_count": len(newsletter_state.market_articles),
        "articles": [
            {
                "position": i + 1,
                "title": a.get("title", ""),
                "source": a.get("source", ""),
                "topics": a.get("topics", []),
            }
            for i, a in enumerate(newsletter_state.market_articles)
        ],
        "has_capgemini": newsletter_state.capgemini_article is not None,
        "has_reuters_video": newsletter_state.reuters_video is not None,
    }


def skill_fetch_and_add_article(topic: str, position: int = -1) -> dict:
    from fetchers.news import fetch_all_articles, fetch_og_image

    logger.info("Fetching articles for topic: %s", topic)
    all_articles = fetch_all_articles(max_age_days=7, reference_date=_newsletter_reference_datetime())
    topic_lower = topic.lower()

    scored = []
    for a in all_articles:
        text = (a["title"] + " " + a.get("summary", "")).lower()
        direct = text.count(topic_lower) * 10
        base = a.get("score", 0)
        if direct > 0 or base > 0:
            scored.append((direct + base, a))
    scored.sort(key=lambda x: x[0], reverse=True)

    existing_urls = {a["url"] for a in newsletter_state.market_articles}
    candidates = [a for _, a in scored if a["url"] not in existing_urls]

    if not candidates:
        return {"success": False, "error": f"Aucun article trouvé pour le thème « {topic} »"}

    best = candidates[0]
    if not best.get("image_url"):
        best["image_url"] = fetch_og_image(best["url"])

    articles = newsletter_state.market_articles[:]
    if position == -1 or position > len(articles):
        articles.append(best)
        actual_pos = len(articles)
    else:
        articles.insert(max(0, position - 1), best)
        actual_pos = max(1, position)

    newsletter_state.market_articles = articles
    _render_state()
    return {
        "success": True,
        "title": best["title"],
        "source": best["source"],
        "position": actual_pos,
        "topics": best.get("topics", []),
    }


def skill_remove_article(position: Optional[int] = None, title_keyword: Optional[str] = None) -> dict:
    articles = newsletter_state.market_articles[:]
    if not articles:
        return {"success": False, "error": "Aucun article dans la newsletter"}

    idx = None
    if position is not None:
        idx = position - 1
        if not (0 <= idx < len(articles)):
            return {"success": False, "error": f"Position {position} invalide (1–{len(articles)})"}
    elif title_keyword:
        kw = title_keyword.lower()
        for i, a in enumerate(articles):
            if kw in a.get("title", "").lower():
                idx = i
                break
        if idx is None:
            return {"success": False, "error": f"Aucun article contenant « {title_keyword} »"}
    else:
        return {"success": False, "error": "Fournir position ou title_keyword"}

    removed = articles.pop(idx)
    newsletter_state.market_articles = articles
    _render_state()
    return {"success": True, "removed": removed.get("title", ""), "was_at_position": idx + 1}


def skill_move_article(to_position: int, from_position: Optional[int] = None, title_keyword: Optional[str] = None) -> dict:
    articles = newsletter_state.market_articles[:]
    if not articles:
        return {"success": False, "error": "Aucun article dans la newsletter"}

    src = None
    if from_position is not None:
        src = from_position - 1
        if not (0 <= src < len(articles)):
            return {"success": False, "error": f"Position source {from_position} invalide"}
    elif title_keyword:
        kw = title_keyword.lower()
        for i, a in enumerate(articles):
            if kw in a.get("title", "").lower():
                src = i
                break
        if src is None:
            return {"success": False, "error": f"Aucun article contenant « {title_keyword} »"}
    else:
        return {"success": False, "error": "Fournir from_position ou title_keyword"}

    dest = max(0, min(to_position - 1, len(articles) - 1))
    article = articles.pop(src)
    articles.insert(dest, article)
    newsletter_state.market_articles = articles
    _render_state()
    return {"success": True, "title": article.get("title", ""), "from": src + 1, "to": dest + 1}


def skill_search_and_add_article(query: str, position: int = -1) -> dict:
    """Search the web for an article matching *query*, then add it via URL."""
    from fetchers.web_search import search_news

    logger.info("Web search: %s", query)
    try:
        results = search_news(query, max_results=8)
    except Exception as exc:
        return {"success": False, "error": f"Erreur de recherche web : {exc}"}

    if not results:
        return {"success": False, "error": f"Aucun résultat trouvé pour : {query}"}

    # Skip articles already in the newsletter
    existing = {a["url"] for a in newsletter_state.market_articles}
    fresh = [r for r in results if r["url"] not in existing]
    if not fresh:
        return {"success": False, "error": "Tous les résultats sont déjà dans la newsletter."}

    best = fresh[0]
    logger.info("Best result: %s — %s", best["title"], best["url"])

    # Delegate to the URL-based importer (handles scraping + crop flow)
    result = skill_add_article_from_url(best["url"], position)
    # Enrich the response with search context
    result["search_query"] = query
    result["search_title"] = best["title"]
    result["search_snippet"] = best["snippet"]
    return result


def _auto_crop_url(image_url: str) -> Optional[str]:
    """Download *image_url*, center-square crop with top bias, resize to 152×152.
    Saves JPEG to output/crops/ and returns the local /crops/<name> path, or None."""
    import hashlib
    import io
    import requests as _req
    from PIL import Image
    from config import SSL_VERIFY

    try:
        headers = {"User-Agent": "Mozilla/5.0 (compatible; Newsletter/1.0)"}
        resp = _req.get(image_url, headers=headers, timeout=12, verify=SSL_VERIFY)
        resp.raise_for_status()
        img = Image.open(io.BytesIO(resp.content)).convert("RGB")
        W, H = img.width, img.height
        side = min(W, H)
        left = (W - side) // 2
        top  = max(0, (H - side) // 4)
        cropped = img.crop((left, top, left + side, top + side)).resize(
            (152, 152), Image.Resampling.LANCZOS
        )
        from paths import CROPS_DIR as crops_dir
        crops_dir.mkdir(parents=True, exist_ok=True)
        fname = hashlib.md5(f"{image_url}_auto".encode()).hexdigest()[:14] + ".jpg"
        cropped.save(crops_dir / fname, "JPEG", quality=85, optimize=True)
        return f"/crops/{fname}"
    except Exception as exc:
        logger.warning("Auto-crop failed for %s: %s", image_url[:80], exc)
        return None


def _extract_article_date(soup):
    """Try to extract the publication date from a BeautifulSoup page."""
    import json
    from datetime import datetime, timezone

    # 1. Standard article meta tags
    for prop in (
        "article:published_time",
        "og:article:published_time",
        "article:modified_time",
        "datePublished",
        "publish_date",
        "date",
    ):
        tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
        if tag:
            val = tag.get("content", "")
            if val:
                try:
                    return datetime.fromisoformat(str(val).replace("Z", "+00:00")).astimezone(timezone.utc)
                except ValueError:
                    pass

    # 2. JSON-LD structured data
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "")
            for obj in (data if isinstance(data, list) else [data]):
                for key in ("datePublished", "dateModified", "dateCreated"):
                    val = obj.get(key, "")
                    if val:
                        return datetime.fromisoformat(str(val).replace("Z", "+00:00")).astimezone(timezone.utc)
        except (ValueError, AttributeError):
            pass

    # 3. <time datetime="..."> element
    time_tag = soup.find("time", attrs={"datetime": True})
    if time_tag:
        try:
            return datetime.fromisoformat(str(time_tag["datetime"]).replace("Z", "+00:00")).astimezone(timezone.utc)
        except (ValueError, KeyError):
            pass

    return None


def skill_add_article_from_url(url: str, position: int = -1) -> dict:
    """Scrape a user-provided URL and insert it as a newsletter article."""
    import urllib.parse
    from fetchers.news import _get, score_article
    from bs4 import BeautifulSoup

    logger.info("Fetching article from URL: %s", url)

    # Basic URL validation
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return {"success": False, "error": f"URL invalide : {url}"}

    # Check for duplicate
    if any(a.get("url") == url for a in newsletter_state.market_articles):
        return {"success": False, "error": "Cet article est déjà dans la newsletter."}

    resp = _get(url, timeout=10)
    if not resp:
        return {"success": False, "error": f"Impossible d'accéder à l'URL : {url}"}

    try:
        soup = BeautifulSoup(resp.text, "html.parser")

        def _meta(prop: str) -> str:
            tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
            if not tag or not hasattr(tag, "get"):
                return ""
            val = tag.get("content")  # type: ignore[union-attr]
            return str(val).strip() if val else ""

        title_tag = soup.find("title")
        title = (
            _meta("og:title")
            or (title_tag.get_text().strip() if title_tag else "")  # type: ignore[union-attr]
            or url
        )
        summary = (
            _meta("og:description")
            or _meta("description")
            or _meta("twitter:description")
        )
        image_url = (
            _meta("og:image")
            or _meta("twitter:image")
            or None
        )
        # Derive a short source name from the domain (strip www.)
        source = parsed.netloc.removeprefix("www.").split(".")[0].capitalize()

        # Extract publication date and reject articles older than 14 days
        # relative to *this newsletter's* date, not necessarily today.
        now = _newsletter_reference_datetime()
        pub_date = _extract_article_date(soup)
        if pub_date is not None:
            age_days = (now - pub_date).days
            if age_days > 14:
                return {
                    "success": False,
                    "error": (
                        f"Article trop ancien ({age_days} jours par rapport à la date de "
                        f"cette newsletter, {newsletter_state.newsletter_date}) — "
                        f"publié le {pub_date.strftime('%d/%m/%Y')}. "
                        "Seuls les articles de moins de 14 jours sont acceptés."
                    ),
                }
        else:
            logger.warning("Could not determine publication date for %s — inserting anyway", url)

        # Score for topics
        score, topics = score_article(title, summary)

        article = {
            "title": title[:200],
            "url": url,
            "summary": summary[:400],
            "published": pub_date or now,
            "source": source,
            "score": score,
            "topics": topics,
            "image_url": image_url or None,
        }
    except Exception as exc:
        logger.exception("Failed to parse %s", url)
        return {"success": False, "error": f"Erreur lors de l'analyse de la page : {exc}"}

    if image_url:
        # Auto-crop immediately; keep original URL for future manual re-crop
        cropped = _auto_crop_url(image_url)
        article["original_image_url"] = image_url
        article["image_url"] = cropped or image_url

    articles = newsletter_state.market_articles[:]
    if position == -1 or position > len(articles):
        articles.append(article)
        actual_pos = len(articles)
    else:
        articles.insert(max(0, position - 1), article)
        actual_pos = max(1, position)

    newsletter_state.market_articles = articles
    _render_state()
    return {
        "success": True,
        "title": article["title"],
        "source": article["source"],
        "position": actual_pos,
        "topics": topics,
    }


def skill_update_article_summary(
    summary: str,
    position: Optional[int] = None,
    title_keyword: Optional[str] = None,
    section: str = "market",
) -> dict:
    summary = summary.strip()
    if not summary:
        return {"success": False, "error": "Le résumé ne peut pas être vide."}

    if section == "capgemini":
        if newsletter_state.capgemini_article is None:
            return {"success": False, "error": "Aucun article Capgemini dans la newsletter."}
        newsletter_state.capgemini_article["summary"] = summary
        _render_state()
        return {"success": True, "title": newsletter_state.capgemini_article.get("title", ""), "section": "capgemini"}

    # Market article
    articles = newsletter_state.market_articles
    if not articles:
        return {"success": False, "error": "Aucun article dans la newsletter."}

    idx = None
    if position is not None:
        idx = position - 1
        if not (0 <= idx < len(articles)):
            return {"success": False, "error": f"Position {position} invalide (1–{len(articles)})"}
    elif title_keyword:
        kw = title_keyword.lower()
        for i, a in enumerate(articles):
            if kw in a.get("title", "").lower():
                idx = i
                break
        if idx is None:
            return {"success": False, "error": f"Aucun article contenant « {title_keyword} »"}
    else:
        return {"success": False, "error": "Fournir position ou title_keyword (ou section='capgemini')."}

    articles[idx]["summary"] = summary
    _render_state()
    return {"success": True, "title": articles[idx].get("title", ""), "position": idx + 1}


def skill_set_capgemini_from_url(url: str) -> dict:
    """Scrape URL and set it as the Capgemini section article (with crop if image found)."""
    import urllib.parse
    from fetchers.news import _get
    from bs4 import BeautifulSoup

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return {"success": False, "error": f"URL invalide : {url}"}

    resp = _get(url, timeout=10)
    if not resp:
        return {"success": False, "error": f"Impossible d'accéder à l'URL : {url}"}

    try:
        soup = BeautifulSoup(resp.text, "html.parser")

        def _meta(prop: str) -> str:
            tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
            if not tag or not hasattr(tag, "get"):
                return ""
            val = tag.get("content")  # type: ignore[union-attr]
            return str(val).strip() if val else ""

        title_tag = soup.find("title")
        title   = _meta("og:title") or (title_tag.get_text().strip() if title_tag else "") or url  # type: ignore[union-attr]
        summary = _meta("og:description") or _meta("description") or _meta("twitter:description")
        image_url = _meta("og:image") or _meta("twitter:image") or None

        article = {
            "title":   title[:200],
            "url":     url,
            "summary": summary[:400],
            "image_url": image_url or None,
            "source":  "Capgemini",
        }
    except Exception as exc:
        logger.exception("Failed to parse %s", url)
        return {"success": False, "error": f"Erreur lors de l'analyse de la page : {exc}"}

    # Toujours utiliser l'image fixe Capgemini, quelle que soit celle trouvée sur la page
    article["image_url"] = _CAPGEMINI_FIXED_IMAGE
    newsletter_state.capgemini_article = article
    _render_state()
    return {"success": True, "title": article["title"]}


def skill_refresh_capgemini_article() -> dict:
    from fetchers.capgemini import get_capgemini_news
    article = get_capgemini_news()
    if not article:
        return {"success": False, "error": "Impossible de récupérer l'article Capgemini depuis le RSS/site."}
    article["image_url"] = _CAPGEMINI_FIXED_IMAGE
    newsletter_state.capgemini_article = article
    _render_state()
    return {"success": True, "title": article["title"]}


def skill_remove_capgemini_article() -> dict:
    if newsletter_state.capgemini_article is None:
        return {"success": False, "error": "Aucun article Capgemini à supprimer."}
    title = newsletter_state.capgemini_article.get("title", "")
    newsletter_state.capgemini_article = None
    _render_state()
    return {"success": True, "removed": title}


def skill_set_reuters_from_url(url: str) -> dict:
    """Fetch a URL (YouTube video or web article) and set it as the Reuters section."""
    import re
    import urllib.parse
    from fetchers.news import _get
    from bs4 import BeautifulSoup

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return {"success": False, "error": f"URL invalide : {url}"}

    yt_match = re.search(r"(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})", url)
    video_id = yt_match.group(1) if yt_match else None

    resp = _get(url, timeout=10)
    if not resp:
        return {"success": False, "error": f"Impossible d'accéder à l'URL : {url}"}

    try:
        soup = BeautifulSoup(resp.text, "html.parser")

        def _meta(prop: str) -> str:
            tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
            if not tag or not hasattr(tag, "get"):
                return ""
            val = tag.get("content")
            return str(val).strip() if val else ""

        title_tag = soup.find("title")
        title = _meta("og:title") or (title_tag.get_text().strip() if title_tag else "") or url
        desc  = _meta("og:description") or _meta("description") or ""
        thumb = _meta("og:image") or ""
        if video_id and not thumb:
            thumb = f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg"

        newsletter_state.reuters_video = {
            "title":         title[:200],
            "video_id":      video_id or "",
            "video_url":     (f"https://www.youtube.com/watch?v={video_id}" if video_id else url),
            "thumbnail_url": thumb,
            "description":   desc[:300],
            "published_at":  "",
            "channel":       "Reuters" if video_id else parsed.netloc.removeprefix("www.").split(".")[0].capitalize(),
        }
    except Exception as exc:
        logger.exception("Failed to parse %s", url)
        return {"success": False, "error": f"Erreur lors de l'analyse de la page : {exc}"}

    _render_state()
    return {"success": True, "title": newsletter_state.reuters_video["title"]}


def skill_refresh_reuters_video() -> dict:
    """Re-fetch the latest Reuters video from YouTube."""
    from fetchers.reuters import get_latest_reuters_video
    video = get_latest_reuters_video()
    if not video:
        return {"success": False, "error": "Impossible de récupérer la vidéo Reuters depuis YouTube."}
    newsletter_state.reuters_video = video
    _render_state()
    return {"success": True, "title": video["title"]}


def _reuters_thumbnail(thumbnail_url: str, thumbnail_data_url: str) -> tuple[str, Optional[str]]:
    """Resolve a Reuters capture to a URL usable by the template : (url, error).

    A data URL (screenshot) is downscaled to the template width and stored in crops/ ;
    an http(s) URL is kept as is. Both empty -> ("", None).
    """
    import base64
    import io
    import urllib.parse
    from datetime import datetime
    from PIL import Image
    from paths import CROPS_DIR

    if thumbnail_data_url:
        if not thumbnail_data_url.startswith("data:image/") or "," not in thumbnail_data_url:
            return "", "Capture invalide : data URL d'image attendue."
        try:
            raw = base64.b64decode(thumbnail_data_url.split(",", 1)[1])
            img = Image.open(io.BytesIO(raw)).convert("RGB")
            if img.width > 706:  # largeur utile du gabarit (750 - marges)
                img = img.resize((706, round(img.height * 706 / img.width)), Image.Resampling.LANCZOS)
            CROPS_DIR.mkdir(parents=True, exist_ok=True)
            fname = f"reuters_{datetime.now().strftime('%Y%m%d%H%M%S%f')}.jpg"
            img.save(CROPS_DIR / fname, "JPEG", quality=85, optimize=True)
            return f"/crops/{fname}", None
        except Exception as exc:  # noqa: BLE001 - image illisible
            return "", f"Capture illisible : {exc}"
    if thumbnail_url:
        t = urllib.parse.urlparse(thumbnail_url)
        if t.scheme not in ("http", "https") or not t.netloc:
            return "", f"URL d'image invalide : {thumbnail_url}"
        return thumbnail_url, None
    return "", None


def _valid_http_url(url: str) -> bool:
    import urllib.parse
    p = urllib.parse.urlparse(url or "")
    return p.scheme in ("http", "https") and bool(p.netloc)


def skill_get_reuters_video() -> dict:
    """Return the current Reuters section (title, link, description, image)."""
    v = newsletter_state.reuters_video
    if not v:
        return {"success": False, "error": "Aucune vidéo Reuters dans la newsletter."}
    return {
        "success": True,
        "title": v.get("title", ""),
        "video_url": v.get("video_url", ""),
        "description": v.get("description", ""),
        "thumbnail_url": v.get("thumbnail_url", ""),
        "channel": v.get("channel", "Reuters"),
    }


def skill_set_reuters_video(
    title: str,
    video_url: str,
    description: str = "",
    thumbnail_url: str = "",
    thumbnail_data_url: str = "",
) -> dict:
    """Set the Reuters section from an already-chosen video (title, link, description, capture)."""
    title = (title or "").strip()
    if not title:
        return {"success": False, "error": "Titre manquant."}
    if not _valid_http_url(video_url):
        return {"success": False, "error": f"URL de vidéo invalide : {video_url}"}
    thumb, err = _reuters_thumbnail(thumbnail_url, thumbnail_data_url)
    if err:
        return {"success": False, "error": err}

    newsletter_state.reuters_video = {
        "title":         title[:200],
        "video_id":      "",
        "video_url":     video_url,
        "thumbnail_url": thumb,
        "description":   (description or "").strip()[:300],
        "published_at":  "",
        "channel":       "Reuters",
    }
    _render_state()
    return {"success": True, "title": title[:200], "has_thumbnail": bool(thumb)}


def skill_update_reuters_video(
    title: Optional[str] = None,
    video_url: Optional[str] = None,
    description: Optional[str] = None,
    thumbnail_url: Optional[str] = None,
    thumbnail_data_url: Optional[str] = None,
) -> dict:
    """Edit fields of the current Reuters section; omitted fields are left untouched."""
    v = newsletter_state.reuters_video
    if not v:
        return {"success": False, "error": "Aucune vidéo Reuters à modifier (utiliser set_reuters_video)."}

    updated = dict(v)
    if title is not None:
        if not title.strip():
            return {"success": False, "error": "Titre vide."}
        updated["title"] = title.strip()[:200]
    if video_url is not None:
        if not _valid_http_url(video_url):
            return {"success": False, "error": f"URL de vidéo invalide : {video_url}"}
        updated["video_url"] = video_url
        updated["video_id"] = ""
    if description is not None:
        updated["description"] = description.strip()[:300]
    if thumbnail_data_url or thumbnail_url:
        thumb, err = _reuters_thumbnail(thumbnail_url or "", thumbnail_data_url or "")
        if err:
            return {"success": False, "error": err}
        updated["thumbnail_url"] = thumb
    if updated == v:
        return {"success": False, "error": "Aucun champ à modifier."}

    newsletter_state.reuters_video = updated
    _render_state()
    return {"success": True, "title": updated["title"]}


def skill_remove_reuters_video() -> dict:
    """Remove the Reuters section (the template then shows 'Reuters video not available')."""
    if not newsletter_state.reuters_video:
        return {"success": False, "error": "Aucune vidéo Reuters à supprimer."}
    title = newsletter_state.reuters_video.get("title", "")
    newsletter_state.reuters_video = None
    _render_state()
    return {"success": True, "removed": title}


def skill_set_edito(
    article_title: str,
    content: str,
) -> dict:
    existing = newsletter_state.edito or {}
    author_name = existing.get("author_name", "Patrice Duboé")
    newsletter_state.edito = {
        "author_name":      author_name,
        "author_title":     existing.get("author_title",     "Executive Vice President"),
        "author_roles":     existing.get("author_roles",     ["CTIO Global AeroSpace & Defense", "CTIO Southern & Central Europe"]),
        "author_photo_url": existing.get("author_photo_url", ""),
        "article_title":    article_title,
        "content":          content,
    }
    _render_state()
    return {"success": True}


def skill_update_edito(
    article_title: Optional[str] = None,
    content: Optional[str] = None,
) -> dict:
    if newsletter_state.edito is None:
        return {"success": False, "error": "Aucun edito défini. Utilisez set_edito d'abord."}
    e = newsletter_state.edito
    if article_title is not None: e["article_title"] = article_title
    if content       is not None: e["content"]       = content
    _render_state()
    return {"success": True}


def skill_get_edito() -> dict:
    edito = newsletter_state.edito
    if not edito:
        return {"success": False, "error": "Aucun edito défini."}
    closing_error = _validate_edito_closing(edito)
    return {
        "success":       True,
        "article_title": edito.get("article_title", ""),
        "content":       edito.get("content", ""),
        "author_name":   edito.get("author_name", ""),
        "author_title":  edito.get("author_title", ""),
        "author_roles":  edito.get("author_roles", []),
        "closing_valid": closing_error is None,
        "closing_error": closing_error,
    }


def skill_remove_edito() -> dict:
    if newsletter_state.edito is None:
        return {"success": False, "error": "Aucun edito à supprimer."}
    newsletter_state.edito = None
    _render_state()
    return {"success": True}


def _validate_edito_closing(edito: Optional[dict]) -> Optional[str]:
    """Ensure the visible edito ends with one correctly formatted sign-off."""
    if not edito:
        return "Envoi bloqué : l'édito est absent."

    from bs4 import BeautifulSoup

    soup = BeautifulSoup(edito.get("content", ""), "html.parser")
    for br in soup.find_all("br"):
        br.replace_with("\n")
    for block in soup.find_all(["div", "h1", "h2", "h3", "li", "p"]):
        block.insert_before("\n")
        block.insert_after("\n")

    text = soup.get_text()
    lines = [" ".join(line.split()) for line in text.splitlines()]
    lines = [line for line in lines if line]
    plain_text = " ".join(lines)
    occurrences = re.findall(
        r"(?<!\w)Sincerely\s+yours(?!\w)", plain_text, flags=re.IGNORECASE
    )
    if len(occurrences) != 1:
        return (
            "Envoi bloqué : l'édito doit contenir une seule fois "
            "« Sincerely yours »."
        )
    if len(lines) < 2 or [lines[-2].rstrip(","), lines[-1]] != ["Sincerely yours", "Patrice"]:
        return (
            "Envoi bloqué : l'édito doit se terminer sur deux lignes distinctes : "
            "« Sincerely yours » puis « Patrice »."
        )
    return None


def skill_send_newsletter() -> dict:
    """Generate PDF and send the newsletter to configured recipients."""
    from generator.emailer import send_newsletter as _send

    closing_error = _validate_edito_closing(newsletter_state.edito)
    if closing_error:
        return {"success": False, "error": closing_error}

    recipients = newsletter_state.recipients
    if not recipients:
        return {"success": False, "error": "Aucun destinataire configuré (ajoutez-en dans l'onglet Administration ou via EMAIL_RECIPIENTS dans .env)"}

    if not newsletter_state.preview_html:
        return {"success": False, "error": "Aucun aperçu HTML disponible — rafraîchissez d'abord."}

    subject = _build_email_subject()
    result = _send(newsletter_state.preview_html, subject, recipients)
    return result


def _build_email_subject() -> str:
    """« <titre> #<numéro> - <titre de l'édito> » (sans suffixe si l'édito n'a pas de titre)."""
    subject = f"{newsletter_state.newsletter_title} #{newsletter_state.newsletter_number}"
    edito_title = ((newsletter_state.edito or {}).get("article_title") or "").strip()
    return f"{subject} - {edito_title}" if edito_title else subject


def _parse_edito_from_email_body(body: str, subject: str) -> dict:
    """
    Try Claude Haiku to parse the edito fields.
    Retries up to 2 times on 529 overloaded errors.
    Falls back to direct heuristic extraction if the API is unavailable.
    """
    import time

    prompt = (
        "Tu reçois le corps d'un e-mail proposant l'édito d'une newsletter.\n"
        "Retourne UNIQUEMENT du JSON valide (sans markdown) :\n"
        '{"article_title":"...","content":"..."}\n\n'
        "• article_title : titre principal de l'édito\n"
        "• content       : corps en HTML simple (<ul><li><b><em>)\n\n"
        f"Corps :\n{body[:4000]}"
    )

    last_exc: Exception | None = None
    for attempt in range(3):
        try:
            resp = llm_client.create_message(
                model=llm_client.FAST_MODEL,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            _accumulate_cost(resp.usage, llm_client.FAST_MODEL)
            raw = resp.content[0]["text"].strip()
            raw = re.sub(r"^```[a-z]*\n?", "", raw, flags=re.M)
            raw = re.sub(r"\n?```$", "", raw, flags=re.M)
            return json.loads(raw)
        except Exception as exc:
            last_exc = exc
            is_529 = (
                hasattr(exc, "status_code") and exc.status_code == 529
                or "529" in str(exc)
                or "overloaded" in str(exc).lower()
            )
            if is_529 and attempt < 2:
                wait = 3 * (attempt + 1)      # 3 s, 6 s
                logger.warning("Anthropic 529 — retrying in %ds (attempt %d/3)", wait, attempt + 1)
                time.sleep(wait)
                continue
            break

    # ── Heuristic fallback (no Claude needed) ────────────────────
    logger.warning("Claude parse failed (%s) — using heuristic fallback", last_exc)

    # Clean subject → article_title
    article_title = re.sub(r"(?i)^(?:Fwd?|Re|Tr|FW)\s*:\s*", "", subject).strip()

    # Use HTML body as-is, or convert plain text to <p> paragraphs
    if body.lstrip().startswith("<"):
        content = body
    else:
        paras = [p.strip() for p in re.split(r"\n{2,}", body) if p.strip()]
        content = "".join(f"<p>{p}</p>" for p in paras[:30])

    return {"article_title": article_title, "content": content}


def skill_check_edito_from_email() -> dict:
    """
    Check Gmail INBOX for an e-mail whose subject contains the newsletter
    title + number.  Parse the body with Claude and replace the edito.
    """
    from fetchers.gmail_edito import fetch_edito_email

    try:
        result = fetch_edito_email(
            newsletter_state.newsletter_number,
            newsletter_state.newsletter_title,
        )
    except RuntimeError as exc:
        return {"success": False, "found": False, "error": str(exc)}

    if not result:
        return {"found": False, "message": "Aucun e-mail d'édito trouvé dans la boîte Gmail."}

    body = result.get("body_html") or result.get("body_plain") or ""
    if not body.strip():
        return {"found": False, "message": "E-mail trouvé mais corps vide."}

    # ── Parse edito fields with Claude Haiku (retry on 529) ───────
    parsed = _parse_edito_from_email_body(body, result["subject"])

    # ── Sanitize HTML content before storing ─────────────────────
    from web.server import sanitize_html
    safe_content = sanitize_html(parsed.get("content", ""))

    # ── Merge: keep author identity from existing edito ───────────
    existing = newsletter_state.edito or {}
    author_name = existing.get("author_name", "Patrice Duboé")
    newsletter_state.edito = {
        "author_name":      author_name,
        "author_title":     existing.get("author_title",     "Executive Vice President"),
        "author_roles":     existing.get("author_roles",     []),
        "author_photo_url": existing.get("author_photo_url", ""),
        "article_title":    parsed.get("article_title", result["subject"]),
        "content":          safe_content,
    }
    _render_state()
    return {
        "success":       True,
        "found":         True,
        "from":          result["from"],
        "subject":       result["subject"],
        "article_title": newsletter_state.edito["article_title"],
    }


def skill_refresh_all_articles() -> dict:
    from fetchers.news import get_market_news
    from fetchers.capgemini import get_capgemini_news

    newsletter_state.is_loading = True
    try:
        newsletter_state.market_articles = get_market_news(reference_date=_newsletter_reference_datetime())
        capgemini = get_capgemini_news()
        if capgemini:
            capgemini["image_url"] = _CAPGEMINI_FIXED_IMAGE
        newsletter_state.capgemini_article = capgemini
        _render_state()
        return {"success": True, "count": len(newsletter_state.market_articles)}
    finally:
        newsletter_state.is_loading = False


def skill_render_preview() -> dict:
    _render_state()
    return {"success": True}


def skill_screenshot_newsletter() -> dict:
    """Render the newsletter HTML via headless browser and return a JPEG base64 screenshot."""
    import os
    import requests as _req

    if not newsletter_state.preview_html:
        _render_state()

    wa_service   = os.getenv("WA_SERVICE_URL", "http://127.0.0.1:3001")
    base_url     = os.getenv("NEWSLETTER_BASE_URL", "http://127.0.0.1:8000")
    preview_url  = f"{base_url}/preview"

    try:
        resp = _req.post(
            f"{wa_service}/screenshot",
            json={"url": preview_url, "width": 750},
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        if not data.get("ok"):
            return {"success": False, "error": data.get("error", "Screenshot failed")}
        return {"success": True, "image_b64": data["image"]}
    except Exception as exc:
        logger.error("Screenshot skill failed: %s", exc)
        return {"success": False, "error": str(exc)}


def skill_auto_crop_and_insert(url: str, position: int = -1) -> dict:
    """Auto center-square crop — used by the WhatsApp flow (no UI interaction)."""
    pending = _pending_articles.pop(url, None)
    if not pending:
        return {"success": False, "error": "Article introuvable en file d'attente"}

    article  = pending["article"]
    position = position if position != -1 else pending.get("position", -1)
    section  = pending.get("section", "market")
    image_url = article.get("image_url") or ""

    if image_url and not image_url.startswith("/crops/"):
        cropped = _auto_crop_url(image_url)
        if cropped:
            article["original_image_url"] = image_url
            article["image_url"] = cropped

    if section == "capgemini":
        article["image_url"] = _CAPGEMINI_FIXED_IMAGE
        newsletter_state.capgemini_article = article
        _render_state()
        return {"success": True, "title": article["title"], "source": article["source"]}

    articles = newsletter_state.market_articles[:]
    if position == -1 or position > len(articles):
        articles.append(article)
        actual_pos = len(articles)
    else:
        articles.insert(max(0, position - 1), article)
        actual_pos = max(1, position)
    newsletter_state.market_articles = articles
    _render_state()
    return {"success": True, "title": article["title"], "source": article["source"], "position": actual_pos}


def skill_recrop_article(
    position: Optional[int] = None,
    title_keyword: Optional[str] = None,
) -> dict:
    """Queue an existing market article for manual re-crop via the UI crop modal."""
    articles = newsletter_state.market_articles
    if not articles:
        return {"success": False, "error": "Aucun article dans la newsletter."}

    idx: Optional[int] = None
    if position is not None:
        idx = position - 1
        if idx < 0 or idx >= len(articles):
            return {"success": False, "error": f"Position {position} invalide."}
    elif title_keyword:
        kw = title_keyword.lower()
        idx = next((i for i, a in enumerate(articles) if kw in a.get("title", "").lower()), None)
        if idx is None:
            return {"success": False, "error": f"Aucun article trouvé avec « {title_keyword} »."}
    else:
        return {"success": False, "error": "Précisez la position ou un mot-clé du titre."}

    article = articles[idx]
    original_url = article.get("original_image_url") or article.get("image_url", "")

    if not original_url or original_url.startswith("/crops/") or original_url.startswith("/assets/"):
        return {
            "success": False,
            "error": "Image originale non disponible — l'article ne peut pas être recadré manuellement.",
        }

    _pending_articles[article["url"]] = {
        "article": article,
        "position": idx + 1,
        "section": "market",
        "recrop": True,
    }
    return {
        "needs_crop": True,
        "url": article["url"],
        "image_url": original_url,
        "title": article["title"],
        "position": idx + 1,
    }


def load_or_create_newsletter(number: int) -> dict:
    """Switch to newsletter *number*.

    If it was already built before (a snapshot exists under output/newsletters/),
    restore it exactly as saved — no RSS fetch, no default edito, no gmail check.
    Otherwise *number* is a brand-new edition: reset the newsletter date to today
    and start empty (default edito + gmail edito check only) — market/Capgemini
    articles are left empty until the user explicitly clicks "Rafraîchir".
    """
    from web.newsletter_store import load_snapshot

    _write_counter_number(number)
    snapshot = load_snapshot(number)

    if snapshot is not None:
        newsletter_state.newsletter_number = number
        newsletter_state.newsletter_title = snapshot.get("newsletter_title", newsletter_state.newsletter_title)
        newsletter_state.newsletter_date = snapshot.get("newsletter_date") or _today_str()
        newsletter_state.market_articles = snapshot.get("market_articles") or []
        newsletter_state.capgemini_article = snapshot.get("capgemini_article")
        newsletter_state.reuters_video = snapshot.get("reuters_video", newsletter_state.reuters_video)
        newsletter_state.edito = snapshot.get("edito")
        _render_state()
        return {"success": True, "number": number, "loaded_existing": True}

    newsletter_state.newsletter_number = number
    newsletter_state.newsletter_date = _today_str()
    newsletter_state.edito = None
    _init_empty_newsletter()
    return {"success": True, "number": number, "loaded_existing": False}


def skill_set_newsletter_number(number: int) -> dict:
    if number < 1:
        return {"success": False, "error": "Le numéro doit être ≥ 1"}
    return load_or_create_newsletter(number)


def skill_set_newsletter_date(date: str) -> dict:
    from datetime import date as _date

    try:
        parsed = _date.fromisoformat(date.strip())
    except (ValueError, AttributeError):
        return {"success": False, "error": f"Date invalide : « {date} » (format attendu AAAA-MM-JJ)"}

    newsletter_state.newsletter_date = parsed.isoformat()
    _render_state()
    return {"success": True, "date": newsletter_state.newsletter_date}


def skill_get_newsletter_date(number: int | None = None) -> dict:
    """Date de référence de l'édition courante, ou d'une édition sauvegardée si `number` est donné."""
    from web.newsletter_store import load_snapshot

    if number is None or number == newsletter_state.newsletter_number:
        return {
            "success": True,
            "number": newsletter_state.newsletter_number,
            "date": newsletter_state.newsletter_date,
        }
    snapshot = load_snapshot(number)
    if snapshot is None:
        return {"success": False, "error": f"Aucune édition #{number} trouvée."}
    return {"success": True, "number": number, "date": snapshot.get("newsletter_date")}


def skill_list_newsletters() -> dict:
    """Liste les éditions existantes (snapshots + édition courante), de la plus récente à la plus ancienne."""
    from web.newsletter_store import list_snapshot_numbers, load_snapshot

    current = newsletter_state.newsletter_number
    editions = []
    for n in sorted(set(list_snapshot_numbers()) | {current}, reverse=True):
        if n == current:
            data = {
                "newsletter_date": newsletter_state.newsletter_date,
                "newsletter_title": newsletter_state.newsletter_title,
                "edito": newsletter_state.edito,
                "market_articles": newsletter_state.market_articles,
            }
        else:
            data = load_snapshot(n)
            if data is None:
                continue
        editions.append({
            "number": n,
            "date": data.get("newsletter_date"),
            "title": data.get("newsletter_title"),
            "edito_title": (data.get("edito") or {}).get("article_title", ""),
            "article_count": len(data.get("market_articles") or []),
            "current": n == current,
        })
    return {"success": True, "count": len(editions), "editions": editions}


def skill_get_newsletter_title() -> dict:
    return {"success": True, "title": newsletter_state.newsletter_title}


def skill_set_newsletter_title(title: str) -> dict:
    title = (title or "").strip()
    if not title:
        return {"success": False, "error": "Le titre ne peut pas être vide."}

    newsletter_state.newsletter_title = title
    _render_state()
    return {"success": True, "title": title}


# ── Tool dispatcher ───────────────────────────────────────────

SKILL_MAP = {
    "get_newsletter_date":      lambda i: skill_get_newsletter_date(**i),
    "list_newsletters":         lambda i: skill_list_newsletters(),
    "get_newsletter_title":     lambda i: skill_get_newsletter_title(),
    "set_newsletter_title":     lambda i: skill_set_newsletter_title(**i),
    "get_newsletter_state":     lambda i: skill_get_newsletter_state(),
    "fetch_and_add_article":    lambda i: skill_fetch_and_add_article(**i),
    "add_article_from_url":     lambda i: skill_add_article_from_url(**i),
    "remove_article":           lambda i: skill_remove_article(**i),
    "move_article":             lambda i: skill_move_article(**i),
    "update_article_summary":   lambda i: skill_update_article_summary(**i),
    "search_and_add_article":   lambda i: skill_search_and_add_article(**i),
    "set_capgemini_from_url":   lambda i: skill_set_capgemini_from_url(**i),
    "refresh_capgemini_article":lambda i: skill_refresh_capgemini_article(),
    "remove_capgemini_article": lambda i: skill_remove_capgemini_article(),
    "set_reuters_from_url":     lambda i: skill_set_reuters_from_url(**i),
    "refresh_reuters_video":    lambda i: skill_refresh_reuters_video(),
    "get_reuters_video":        lambda i: skill_get_reuters_video(),
    "set_reuters_video":        lambda i: skill_set_reuters_video(**i),
    "update_reuters_video":     lambda i: skill_update_reuters_video(**i),
    "remove_reuters_video":     lambda i: skill_remove_reuters_video(),
    "get_edito":                lambda i: skill_get_edito(),
    "set_edito":                lambda i: skill_set_edito(**i),
    "update_edito":             lambda i: skill_update_edito(**i),
    "remove_edito":             lambda i: skill_remove_edito(),
    "check_edito_from_email":   lambda i: skill_check_edito_from_email(),
    "send_newsletter":          lambda i: skill_send_newsletter(),
    "refresh_all_articles":     lambda i: skill_refresh_all_articles(),
    "render_preview":           lambda i: skill_render_preview(),
    "set_newsletter_number":    lambda i: skill_set_newsletter_number(**i),
    "set_newsletter_date":      lambda i: skill_set_newsletter_date(**i),
    "auto_crop_and_insert":     lambda i: skill_auto_crop_and_insert(**i),
    "screenshot_newsletter":    lambda i: skill_screenshot_newsletter(),
}


def execute_tool(name: str, inputs: dict) -> str:
    if name not in SKILL_MAP:
        return json.dumps({"error": f"Outil inconnu : {name}"})
    try:
        return json.dumps(SKILL_MAP[name](inputs), ensure_ascii=False, default=str)
    except Exception as exc:
        logger.exception("Tool %s failed", name)
        return json.dumps({"error": str(exc)})


# ── Agent loop ────────────────────────────────────────────────

async def process_message(user_message: str) -> AsyncGenerator[dict, None]:
    """
    Async generator yielding server→client event dicts:
      {"type": "text",               "content": str}
      {"type": "tool_start",         "tool": str}
      {"type": "tool_result",        "tool": str, "result": dict}
      {"type": "newsletter_updated"}
      {"type": "done"}
    """
    _conversation_history.append({"role": "user", "content": user_message})
    newsletter_state.conversation_turns += 1
    newsletter_updated = False

    while True:
        response = await asyncio.to_thread(
            llm_client.create_message,
            model=llm_client.MAIN_MODEL,
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=_conversation_history,
        )
        _accumulate_cost(response.usage, llm_client.MAIN_MODEL)
        newsletter_state.last_context_tokens = getattr(response.usage, "input_tokens", 0) or 0
        _conversation_history.append({"role": "assistant", "content": response.content})

        tool_calls = [b for b in response.content if b["type"] == "tool_use"]
        text_blocks = [b for b in response.content if b["type"] == "text"]

        for block in text_blocks:
            yield {"type": "text", "content": block["text"]}

        if response.stop_reason != "tool_use":
            break

        tool_results = []
        for tc in tool_calls:
            yield {"type": "tool_start", "tool": tc["name"]}
            result_str = await asyncio.to_thread(execute_tool, tc["name"], tc["input"])
            result_data = json.loads(result_str)

            if tc["name"] in MODIFYING_TOOLS and result_data.get("success"):
                newsletter_updated = True

            yield {"type": "tool_result", "tool": tc["name"], "result": result_data}
            tool_results.append({"type": "tool_result", "tool_use_id": tc["id"], "content": result_str})

        _conversation_history.append({"role": "user", "content": tool_results})

    if newsletter_updated:
        yield {"type": "newsletter_updated"}
    yield {"type": "done"}


_DEFAULT_EDITO_CONTENT = """\
<ul>
  <li>Google has confirmed the <b>first real-world zero-day</b> developed with AI assistance \
🧠💥 : a Python script able to <b>bypass 2FA</b> on an open-source admin tool.</li>
  <li>Telltale signs? Code that's <em>too clean</em>, pedagogical docstrings, even a \
<b>hallucinated CVSS score</b> 🤓 — classic LLM fingerprints.</li>
  <li>The flaw itself was a <b>logic vulnerability</b> (hard coded trust assumption), \
exactly the kind AI spots better than traditional scanners.</li>
  <li>The good news: the campaign was <b>stopped before any mass exploitation</b>, \
thanks to responsible disclosure 🚒.</li>
  <li>Bottom line (with a wink): AI is accelerating innovation… \
<b>for defenders and attackers alike</b>. Our challenge is to run faster 🏃‍♂️💡.</li>
</ul>"""


def _load_default_edito() -> None:
    if newsletter_state.edito is not None:
        return  # already set — don't overwrite user edits

    import base64
    from paths import PICTURES_DIR
    photo_path = PICTURES_DIR / "1609865078487.jpg"
    try:
        photo_b64 = "data:image/jpeg;base64," + base64.b64encode(photo_path.read_bytes()).decode()
    except OSError:
        photo_b64 = ""
        logger.warning("Edito author photo not found: %s", photo_path)

    newsletter_state.edito = {
        "author_name":      "Patrice Duboé",
        "author_title":     "Executive Vice President",
        "author_roles":     ["CTIO Global AeroSpace & Defense", "CTIO Southern & Central Europe"],
        "author_photo_url": photo_b64,
        "article_title":    "🤖🔒 When AI Moves from Bug Bounty to Bug Bandit",
        "content":          _DEFAULT_EDITO_CONTENT,
    }


def initialize_newsletter() -> None:
    skill_refresh_all_articles()
    _load_default_edito()
    # Override default edito with one from Gmail if a matching email exists
    skill_check_edito_from_email()
    _render_state()  # final re-render with all data


def _init_empty_newsletter() -> None:
    """
    Set up a brand-new edition WITHOUT hitting RSS — market/Capgemini articles are
    left empty and only fetched when the user clicks "Rafraîchir" (initialize_newsletter).
    """
    newsletter_state.market_articles = []
    newsletter_state.capgemini_article = None
    _load_default_edito()
    skill_check_edito_from_email()
    _render_state()


def clear_conversation() -> None:
    _conversation_history.clear()
    newsletter_state.last_context_tokens = 0
    newsletter_state.conversation_turns = 0
