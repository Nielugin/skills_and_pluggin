"""FastAPI server — newsletter web UI with WebSocket chat."""
import asyncio
import hashlib
import io
import logging
import os
import sys
from pathlib import Path
from typing import Optional

import requests
import uvicorn
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent.parent))
from paths import CROPS_DIR, PICTURES_DIR, load_env
load_env()

from web.agent import (
    _CAPGEMINI_FIXED_IMAGE,
    _get_alternative_suggestions,
    _pending_articles,
    _read_counter_number,
    _render_state,
    clear_conversation,
    initialize_newsletter,
    load_or_create_newsletter,
    process_message,
    skill_send_newsletter,
)
from web.state import newsletter_state, _ws_clients, broadcast_newsletter_updated

logger = logging.getLogger(__name__)

# Initialise les destinataires depuis .env (modifiable ensuite depuis l'UI)
newsletter_state.recipients = [
    r.strip() for r in os.getenv("EMAIL_RECIPIENTS", "").split(",") if r.strip()
]

# ── Static directories ────────────────────────────────────────
STATIC_DIR = Path(__file__).parent / "static"
CROPS_DIR.mkdir(parents=True, exist_ok=True)


app = FastAPI(title="Newsletter Generator", version="1.0")
app.mount("/static",  StaticFiles(directory=str(STATIC_DIR)),   name="static")
app.mount("/crops",   StaticFiles(directory=str(CROPS_DIR)),    name="crops")
app.mount("/assets",  StaticFiles(directory=str(PICTURES_DIR)), name="assets")

from web.whatsapp import router as whatsapp_router
app.include_router(whatsapp_router)

_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
}


# ── Pillow crop helper ────────────────────────────────────────

def crop_and_save(image_url: str, x1: int, y1: int, x2: int, y2: int) -> Optional[str]:
    """
    Download image_url, crop the square defined by the two top points
    (x1,y1) and (x2,y2), resize to 152×152 and save under CROPS_DIR.
    Returns the local /crops/<file> path or None on failure.
    """
    try:
        from config import SSL_VERIFY
        resp = requests.get(image_url, headers=_HEADERS, timeout=12, verify=SSL_VERIFY)
        resp.raise_for_status()
        img = Image.open(io.BytesIO(resp.content)).convert("RGB")

        side = abs(x2 - x1)
        if side < 10:
            logger.warning("Crop side too small (%d px), skipping", side)
            return None

        left = min(x1, x2)
        top  = min(y1, y2)
        box  = (
            max(0, left),
            max(0, top),
            min(img.width,  left + side),
            min(img.height, top  + side),
        )
        cropped = img.crop(box).resize((152, 152), Image.LANCZOS)

        fname    = hashlib.md5(f"{image_url}{x1}{y1}{x2}{y2}".encode()).hexdigest()[:14] + ".jpg"
        out_path = CROPS_DIR / fname
        cropped.save(out_path, "JPEG", quality=85, optimize=True)
        logger.info("Saved crop: %s", out_path)
        return f"/crops/{fname}"
    except Exception as exc:
        logger.warning("crop_and_save failed for %s: %s", image_url, exc)
        return None


# ── Crop-done handler (called from WebSocket loop) ────────────

async def handle_crop_done(websocket: WebSocket, data: dict) -> None:
    url      = data.get("url", "")
    x1, y1   = int(data.get("x1", 0)), int(data.get("y1", 0))
    x2, y2   = int(data.get("x2", 0)), int(data.get("y2", 0))
    position = int(data.get("position", -1))

    pending = _pending_articles.pop(url, None)
    if not pending:
        await websocket.send_json({
            "type": "text",
            "content": "Erreur : article introuvable dans la file d'attente (peut-être expiré).",
        })
        await websocket.send_json({"type": "done"})
        return

    article  = pending["article"]
    position = position if position != -1 else pending.get("position", -1)

    # Apply Pillow crop (unless user chose to keep the original image)
    if data.get("skip_crop", False):
        # Restore the image the article had before this modification was requested
        article["image_url"] = pending.get("prev_image_url")
    else:
        raw_image_url = article.get("image_url") or ""
        if raw_image_url:
            cropped_path = await asyncio.to_thread(crop_and_save, raw_image_url, x1, y1, x2, y2)
            if cropped_path:
                article["image_url"] = cropped_path
            else:
                logger.warning("Crop failed, keeping original image_url")

    is_recrop = pending.get("recrop", False)
    section = pending.get("section", "market")
    short_title = article["title"][:70] + ("…" if len(article["title"]) > 70 else "")

    if is_recrop:
        # Update the image of the existing article in-place
        for a in newsletter_state.market_articles:
            if a.get("url") == url:
                a["image_url"] = article["image_url"]
                break
        await asyncio.to_thread(_render_state)
        await websocket.send_json({
            "type": "text",
            "content": f"✓ Vignette recadrée pour « {short_title} ».",
        })
    elif section == "capgemini":
        article["image_url"] = _CAPGEMINI_FIXED_IMAGE
        newsletter_state.capgemini_article = article
        await asyncio.to_thread(_render_state)
        await websocket.send_json({
            "type": "text",
            "content": f"✓ Article Capgemini « {short_title} » défini avec le recadrage appliqué.",
        })
    else:
        articles = newsletter_state.market_articles[:]
        if position == -1 or position > len(articles):
            articles.append(article)
            actual_pos = len(articles)
        else:
            articles.insert(max(0, position - 1), article)
            actual_pos = max(1, position)
        newsletter_state.market_articles = articles
        await asyncio.to_thread(_render_state)
        await websocket.send_json({
            "type": "text",
            "content": f"✓ Article « {short_title} » ajouté en position {actual_pos} avec le recadrage appliqué.",
        })
    await websocket.send_json({"type": "newsletter_updated"})
    await websocket.send_json({"type": "done"})


# ── Inline-edit script (injected into the preview iframe) ────

_INLINE_EDIT_SCRIPT = r"""
(function () {
  'use strict';

  /* ── Styles ───────────────────────────────────────────── */
  var s = document.createElement('style');
  s.textContent = [
    '.nle { cursor: text; transition: background .15s, outline .15s; }',
    '.nle:hover { background: rgba(88,166,255,.10) !important;',
    '  outline: 1px dashed rgba(88,166,255,.5); outline-offset: 2px; border-radius: 3px; }',
    '.nle[contenteditable="true"] {',
    '  outline: 2px solid #58a6ff !important; border-radius: 3px;',
    '  background: rgba(255,255,255,.96) !important; cursor: text;',
    '  box-shadow: 0 2px 10px rgba(88,166,255,.25); }',
    '#_nle_bar { position:fixed; top:0; left:0; right:0; z-index:9000;',
    '  background:rgba(88,166,255,.13); border-bottom:1px solid rgba(88,166,255,.3);',
    '  padding:5px 14px; font:11px/1.4 sans-serif; color:#1a1a1a; text-align:center;',
    '  backdrop-filter:blur(4px); }',
    '#_nle_toast { position:fixed; bottom:14px; right:14px; z-index:9001;',
    '  background:#3fb950; color:#fff; padding:6px 14px; border-radius:6px;',
    '  font:12px sans-serif; opacity:0; transition:opacity .25s; pointer-events:none; }'
  ].join('');
  document.head.appendChild(s);

  /* ── Edit bar ─────────────────────────────────────────── */
  var bar = document.createElement('div');
  bar.id = '_nle_bar';
  bar.innerHTML = '&#9998;&nbsp; <b>Mode édition</b>&nbsp;&nbsp;·&nbsp;&nbsp;Cliquez sur un titre ou résumé pour modifier&nbsp;&nbsp;·&nbsp;&nbsp;<kbd>Entrée</kbd> ou clic hors zone pour sauvegarder&nbsp;&nbsp;·&nbsp;&nbsp;<kbd>Échap</kbd> pour annuler';
  document.body.insertBefore(bar, document.body.firstChild);

  /* ── Toast ────────────────────────────────────────────── */
  var toast = document.createElement('div');
  toast.id = '_nle_toast';
  document.body.appendChild(toast);
  function showToast(msg, color) {
    toast.textContent = msg;
    toast.style.background = color || '#3fb950';
    toast.style.opacity = '1';
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { toast.style.opacity = '0'; }, 2000);
  }

  /* ── Paste sanitizer (strip bg/highlight/font, keep b/i/u/lists/emojis) ── */
  function sanitizePaste(html) {
    var tmp = document.createElement('div');
    tmp.innerHTML = html;

    /* remove background-color / background / font-family / font-size from every inline style
       so pasted text (Word, Gmail, Outlook…) adopts the newsletter's own typography —
       bold/italic/underline and other decorations carried by tags are untouched */
    tmp.querySelectorAll('[style]').forEach(function (node) {
      var s = node.getAttribute('style')
        .replace(/background(?:-color)?\\s*:[^;]+;?\\s*/gi, '')
        .replace(/font-family\\s*:[^;]+;?\\s*/gi, '')
        .replace(/font-size\\s*:[^;]+;?\\s*/gi, '');
      if (s.trim()) node.setAttribute('style', s);
      else          node.removeAttribute('style');
    });

    /* strip legacy <font face=… size=…> attributes (old Word/Outlook HTML) */
    tmp.querySelectorAll('font').forEach(function (n) {
      n.removeAttribute('face');
      n.removeAttribute('size');
    });

    /* unwrap <mark> (HTML highlight) */
    tmp.querySelectorAll('mark').forEach(function (mark) {
      var p = mark.parentNode;
      if (!p) return;
      while (mark.firstChild) p.insertBefore(mark.firstChild, mark);
      p.removeChild(mark);
    });

    /* remove bgcolor attribute (Word / old HTML) */
    tmp.querySelectorAll('[bgcolor]').forEach(function (n) { n.removeAttribute('bgcolor'); });

    return tmp.innerHTML;
  }

  /* ── Make element editable ────────────────────────────── */
  /* useHtml=true  → read/write innerHTML (rich content like edito body)  */
  /* useHtml=false → read/write innerText (plain text, default)           */
  function wire(el, section, index, field, useHtml) {
    el.classList.add('nle');
    el.title = 'Cliquer pour modifier';
    var original = '';

    function getVal()      { return useHtml ? el.innerHTML         : el.innerText.trim(); }
    function setVal(v)     { if (useHtml) el.innerHTML = v; else el.innerText = v; }

    el.addEventListener('click', function (e) {
      if (el.contentEditable === 'true') return;
      e.preventDefault(); e.stopPropagation();
      original = getVal();
      el.contentEditable = 'true';
      el.focus();
      if (!useHtml) {
        var r = document.createRange();
        r.selectNodeContents(el);
        var sel = window.getSelection();
        sel.removeAllRanges(); sel.addRange(r);
      }
    });

    function commit() {
      if (el.contentEditable !== 'true') return;
      el.contentEditable = 'false';
      var val = getVal();
      if (!val) { setVal(original); showToast('Texte vide — annulé', '#d29922'); return; }
      if (val === original) return;
      window.parent.postMessage(
        { type: 'newsletter_inline_edit', section: section, index: index, field: field, value: val },
        window.location.origin
      );
      showToast('✓ Sauvegardé');
    }

    el.addEventListener('blur', commit);
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !useHtml) { e.preventDefault(); el.blur(); }
      if (e.key === 'Escape') { setVal(original); el.contentEditable = 'false'; }
    });

    /* intercept paste only for rich-content fields */
    if (useHtml) {
      el.addEventListener('paste', function (e) {
        e.preventDefault();
        var cd  = e.clipboardData || window.clipboardData;
        var htm = cd.getData('text/html');
        if (htm) {
          document.execCommand('insertHTML', false, sanitizePaste(htm));
        } else {
          /* plain-text fallback — preserve line breaks */
          var txt = cd.getData('text/plain').replace(/\n/g, '<br>');
          document.execCommand('insertHTML', false, txt);
        }
      });
    }
  }

  /* ── Wire market articles ─────────────────────────────── */
  var TRASH_ICON = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"'
    + ' stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
    + '<polyline points="3 6 5 6 21 6"/>'
    + '<path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>'
    + '<path d="M10 11v6"/><path d="M14 11v6"/>'
    + '<path d="M9 6V4h6v2"/>'
    + '</svg>';

  document.querySelectorAll('.article-row').forEach(function (row, i) {
    var t = row.querySelector('.article-title a');
    var a = row.querySelector('.article-abstract');
    if (t) wire(t, 'market', i, 'title');
    if (a) wire(a, 'market', i, 'summary');

    /* ── Delete button ─────────────────────────────────── */
    var artUrl = row.getAttribute('data-article-url') || '';
    if (!artUrl) return;
    var textCell = row.querySelector('td:last-child');
    if (!textCell) return;
    textCell.style.position = 'relative';
    var delBtn = document.createElement('button');
    delBtn.innerHTML = TRASH_ICON;
    delBtn.title = 'Supprimer cet article';
    delBtn.style.cssText = [
      'position:absolute;bottom:8px;right:8px;',
      'width:28px;height:28px;border-radius:5px;',
      'background:rgba(220,38,38,.80);border:none;cursor:pointer;',
      'display:flex;align-items:center;justify-content:center;',
      'color:#fff;opacity:0;transition:opacity .15s;z-index:20;padding:0;'
    ].join('');
    textCell.appendChild(delBtn);
    row.addEventListener('mouseenter', function () { delBtn.style.opacity = '1'; });
    row.addEventListener('mouseleave', function () { delBtn.style.opacity = '0'; });
    delBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      window.parent.postMessage({ type: 'delete_article', url: artUrl }, window.location.origin);
    });
  });

  /* ── Wire Capgemini section ───────────────────────────── */
  var ct = document.querySelector('.capgemini-title a');
  var ca = document.querySelector('.capgemini-abstract');
  if (ct) wire(ct, 'capgemini', 0, 'title');
  if (ca) wire(ca, 'capgemini', 0, 'summary');

  /* ── Wire Reuters / Keep a look outside section ────────── */
  var ra = document.querySelector('.reuters-abstract');
  if (ra) wire(ra, 'reuters', 0, 'description');

  /* Reuters titre : modal titre + lien */
  var rt = document.querySelector('.reuters-title a');
  if (rt) {
    rt.classList.add('nle');
    rt.title = 'Cliquer pour modifier le titre et le lien';
    var rtModal = document.createElement('div');
    rtModal.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(0,0,0,.52);z-index:9998;align-items:center;justify-content:center;';
    var rtBox = document.createElement('div');
    rtBox.style.cssText = 'background:#fff;border-radius:10px;padding:24px 28px;width:400px;font-family:sans-serif;box-shadow:0 8px 32px rgba(0,0,0,.35);';
    rtBox.innerHTML =
      '<div style="font-weight:700;font-size:13px;margin-bottom:16px;color:#1a1a1a">&#9998;&nbsp; Modifier le titre Reuters</div>'
      + '<label style="font-size:11px;color:#555;display:block;margin-bottom:4px;">Titre</label>'
      + '<input id="_rt_title" type="text" style="width:100%;box-sizing:border-box;padding:7px 10px;border:1px solid #ccc;border-radius:5px;font-size:12px;margin-bottom:12px;" />'
      + '<label style="font-size:11px;color:#555;display:block;margin-bottom:4px;">Lien URL</label>'
      + '<input id="_rt_url" type="url" style="width:100%;box-sizing:border-box;padding:7px 10px;border:1px solid #ccc;border-radius:5px;font-size:12px;margin-bottom:16px;" />'
      + '<div style="display:flex;justify-content:flex-end;gap:8px;">'
      + '<button id="_rt_cancel" style="padding:6px 16px;border-radius:4px;border:1px solid #ccc;background:#f5f5f5;cursor:pointer;font-size:12px;">Annuler</button>'
      + '<button id="_rt_save" style="padding:6px 16px;border-radius:4px;border:none;background:#0070AD;color:#fff;cursor:pointer;font-size:12px;font-weight:700;">Valider</button>'
      + '</div>';
    rtModal.appendChild(rtBox);
    document.body.appendChild(rtModal);

    rt.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      document.getElementById('_rt_title').value = rt.textContent.trim();
      document.getElementById('_rt_url').value = rt.getAttribute('href') || '';
      rtModal.style.display = 'flex';
      setTimeout(function () { document.getElementById('_rt_title').focus(); }, 50);
    });

    function rtSave() {
      var newTitle = document.getElementById('_rt_title').value.trim();
      var newUrl   = document.getElementById('_rt_url').value.trim();
      if (!newTitle) { showToast('\u26a0 Titre vide', '#d29922'); return; }
      rtModal.style.display = 'none';
      /* mise à jour DOM immédiate */
      rt.textContent = newTitle;
      if (newUrl) {
        rt.href = newUrl;
        var rImgLink = document.querySelector('.reuters-thumbnail') && document.querySelector('.reuters-thumbnail').closest('a');
        if (rImgLink) rImgLink.href = newUrl;
      }
      window.parent.postMessage(
        { type: 'newsletter_inline_edit', section: 'reuters', index: 0, field: 'title', value: newTitle },
        window.location.origin
      );
      if (newUrl) window.parent.postMessage(
        { type: 'newsletter_inline_edit', section: 'reuters', index: 0, field: 'video_url', value: newUrl },
        window.location.origin
      );
      showToast('\u2713 Sauvegard\u00e9');
    }

    document.getElementById('_rt_save').addEventListener('click', rtSave);
    document.getElementById('_rt_cancel').addEventListener('click', function () { rtModal.style.display = 'none'; });
    rtModal.addEventListener('click', function (e) { if (e.target === rtModal) rtModal.style.display = 'none'; });
    rtBox.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') rtSave();
      if (e.key === 'Escape') { rtModal.style.display = 'none'; }
    });
  }

  /* ── Reuters thumbnail — modal fichier / presse-papiers ── */
  var rImg = document.querySelector('.reuters-thumbnail');
  if (rImg) {
    /* wrap */
    var rWrap = document.createElement('div');
    rWrap.style.cssText = 'position:relative;display:inline-block;line-height:0;';
    rImg.parentNode.insertBefore(rWrap, rImg);
    rWrap.appendChild(rImg);

    /* bouton survol */
    var rBtn = document.createElement('button');
    rBtn.innerHTML = '&#9998;&nbsp;Image';
    rBtn.title = 'Charger ou coller une image';
    rBtn.style.cssText = 'position:absolute;bottom:8px;right:8px;padding:5px 12px;border-radius:4px;background:rgba(0,0,0,.68);border:none;cursor:pointer;color:#fff;font:11px/1 sans-serif;opacity:0;transition:opacity .15s;z-index:10;';
    rWrap.appendChild(rBtn);
    rWrap.addEventListener('mouseenter', function () { rBtn.style.opacity = '1'; });
    rWrap.addEventListener('mouseleave', function () { rBtn.style.opacity = '0'; });

    /* modal */
    var rModal = document.createElement('div');
    rModal.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(0,0,0,.52);z-index:9998;align-items:center;justify-content:center;';
    var rBox = document.createElement('div');
    rBox.style.cssText = 'background:#fff;border-radius:10px;padding:24px 28px;width:320px;font-family:sans-serif;box-shadow:0 8px 32px rgba(0,0,0,.35);';
    rBox.innerHTML =
      '<div style="font-weight:700;font-size:13px;margin-bottom:16px;color:#1a1a1a">&#128444;&nbsp; Remplacer l\'image Reuters</div>'
      + '<div id="_r_drop" style="border:2px dashed #b0b8c8;border-radius:7px;padding:22px 12px;text-align:center;cursor:pointer;color:#555;font-size:12px;line-height:1.6;margin-bottom:14px;">'
      + '&#128203;&nbsp;<b>Ctrl+V</b> pour coller depuis le presse-papiers<br><span style="color:#999;font-size:11px;">ou cliquez pour choisir un fichier</span></div>'
      + '<div style="text-align:right;"><button id="_r_cancel" style="padding:5px 16px;border-radius:4px;border:1px solid #ccc;background:#f5f5f5;cursor:pointer;font-size:12px;">Annuler</button></div>';
    rModal.appendChild(rBox);
    document.body.appendChild(rModal);

    /* input fichier caché */
    var rFile = document.createElement('input');
    rFile.type = 'file'; rFile.accept = 'image/*'; rFile.style.display = 'none';
    document.body.appendChild(rFile);

    function rUpload(dataUrl) {
      rModal.style.display = 'none';
      fetch('/api/newsletter/reuters/upload-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data_url: dataUrl })
      }).then(function (r) { return r.json(); }).then(function (j) {
        if (j.status === 'ok') {
          rImg.src = j.url + '?t=' + Date.now();
          showToast('\u2713 Image mise \u00e0 jour');
          window.parent.postMessage({ type: 'newsletter_updated' }, '*');
        } else { showToast('\u26a0 ' + (j.message || 'Erreur'), '#d29922'); }
      }).catch(function () { showToast('\u26a0 Erreur r\u00e9seau', '#d29922'); });
    }

    /* coller */
    document.addEventListener('paste', function (e) {
      if (rModal.style.display !== 'flex') return;
      var items = (e.clipboardData || {}).items || [];
      for (var i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          var fr = new FileReader();
          fr.onload = function (ev) { rUpload(ev.target.result); };
          fr.readAsDataURL(items[i].getAsFile());
          return;
        }
      }
      showToast('\u26a0 Aucune image dans le presse-papiers', '#d29922');
    });

    /* choisir un fichier */
    rFile.addEventListener('change', function () {
      var f = rFile.files[0]; if (!f) return;
      var fr = new FileReader();
      fr.onload = function (ev) { rUpload(ev.target.result); };
      fr.readAsDataURL(f);
    });

    document.getElementById('_r_drop').addEventListener('click', function () { rFile.click(); });
    document.getElementById('_r_cancel').addEventListener('click', function () { rModal.style.display = 'none'; });
    rModal.addEventListener('click', function (e) { if (e.target === rModal) rModal.style.display = 'none'; });
    rBtn.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      rModal.style.display = 'flex';
    });
  }

  /* ── Wire Edito section ─────────────────────────────────── */
  var eat = document.querySelector('.edito-article-title');
  var eb  = document.querySelector('.edito-body');
  var ean = document.querySelector('.edito-author-name');
  var eat2 = document.querySelector('.edito-author-title');
  if (eat)  wire(eat,  'edito', 0, 'article_title');
  if (eb)   wire(eb,   'edito', 0, 'content', true);   /* useHtml */
  if (ean)  wire(ean,  'edito', 0, 'author_name');
  if (eat2) wire(eat2, 'edito', 0, 'author_title');

  /* ── Article thumbnails — crop button overlay ───────────── */
  var CROP_ICON = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"'
    + ' stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">'
    + '<polyline points="6 2 6 18 22 18"/>'
    + '<polyline points="2 6 18 6 18 22"/>'
    + '</svg>';

  document.querySelectorAll('img[data-article-url]').forEach(function (img) {
    var link = img.parentElement;  /* <a> wrapping the image */

    /* Relative container so the button can be absolutely positioned */
    var wrap = document.createElement('div');
    wrap.style.cssText = 'position:relative;display:inline-block;width:152px;height:152px;line-height:0;';
    link.parentNode.insertBefore(wrap, link);
    wrap.appendChild(link);

    /* Crop button */
    var btn = document.createElement('button');
    btn.innerHTML = CROP_ICON;
    btn.title = 'Recadrer la vignette';
    btn.style.cssText = [
      'position:absolute;bottom:5px;right:5px;',
      'width:26px;height:26px;border-radius:5px;',
      'background:rgba(0,0,0,.60);border:none;cursor:pointer;',
      'display:flex;align-items:center;justify-content:center;',
      'opacity:0;transition:opacity .15s;z-index:10;padding:0;',
    ].join('');
    wrap.appendChild(btn);

    /* Show/hide on hover */
    wrap.addEventListener('mouseenter', function () { btn.style.opacity = '1'; });
    wrap.addEventListener('mouseleave', function () { btn.style.opacity = '0'; });

    /* Trigger re-crop */
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      parent.postMessage({ type: 'recrop_image', articleUrl: img.dataset.articleUrl }, '*');
    });
  });

  /* ── Drag & drop alternative suggestions ─────────────── */
  document.querySelectorAll('.article-row').forEach(function (row) {
    row.addEventListener('dragover', function (e) {
      if (!e.dataTransfer) return;
      if (!e.dataTransfer.types.includes('application/json') && !e.dataTransfer.types.includes('text/plain')) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      row.style.outline = '2px dashed rgba(88,166,255,.7)';
      row.style.background = 'rgba(88,166,255,.08)';
    });

    row.addEventListener('dragleave', function () {
      row.style.outline = '';
      row.style.background = '';
    });

    row.addEventListener('drop', function (e) {
      e.preventDefault();
      row.style.outline = '';
      row.style.background = '';
      var raw = '';
      try { raw = e.dataTransfer.getData('application/json'); } catch (err) { raw = ''; }
      if (!raw) {
        try { raw = e.dataTransfer.getData('text/plain'); } catch (err) { raw = ''; }
      }
      if (!raw) return;
      var suggestion = null;
      try { suggestion = JSON.parse(raw); } catch (err) { suggestion = { url: raw }; }
      if (!suggestion || !suggestion.url) return;
      parent.postMessage({
        type: 'newsletter_alternative_drop',
        targetUrl: row.dataset.articleUrl || '',
        suggestion: suggestion,
      }, '*');
    });
  });
})();
"""


# ── HTML sanitiser (whitelist-based, used for edito content) ─
_ALLOWED_TAGS = {
    "p", "br", "b", "strong", "i", "em", "u", "s",
    "ul", "ol", "li", "a", "span", "h1", "h2", "h3",
}
_ALLOWED_ATTRS: dict[str, list[str]] = {
    "a":    ["href"],
    "span": ["style"],      # keep only colour/font-weight, stripped below
}
def sanitize_html(raw: str) -> str:
    """
    Strip any tag not in _ALLOWED_TAGS and any attribute not in _ALLOWED_ATTRS.
    Also removes background-color / background / font-family / font-size from inline
    styles, so pasted text (Word, Gmail, Outlook…) adopts the newsletter's own
    typography instead of whatever font/size it was copied with.
    Safe to call with None or empty strings.
    """
    if not raw:
        return ""
    from bs4 import BeautifulSoup
    import re as _re
    soup = BeautifulSoup(raw, "html.parser")
    for tag in soup.find_all(True):
        if tag.name not in _ALLOWED_TAGS:
            tag.unwrap()
            continue
        allowed_attrs = _ALLOWED_ATTRS.get(tag.name, [])
        tag.attrs = {k: v for k, v in tag.attrs.items() if k in allowed_attrs}
        # Strip background/font-family/font-size from any remaining style attribute
        if "style" in tag.attrs:
            style = tag.attrs["style"]
            for prop in ("background(?:-color)?", "font-family", "font-size"):
                style = _re.sub(rf"{prop}\s*:[^;]+;?\s*", "", style, flags=_re.I)
            if style.strip():
                tag.attrs["style"] = style
            else:
                del tag.attrs["style"]
    return str(soup)


# ── Inline-edit payload model ─────────────────────────────────

class InlineEdit(BaseModel):
    section: str   # "market" | "capgemini"
    index: int     # 0-based row index
    field: str     # "title" | "summary"
    value: str


# ── HTTP routes ───────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def root():
    return (STATIC_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/api/newsletter/preview", response_class=HTMLResponse)
async def get_preview():
    if not newsletter_state.preview_html:
        number = _read_counter_number(newsletter_state.newsletter_number)
        await asyncio.to_thread(load_or_create_newsletter, number)
    html = newsletter_state.preview_html
    injection = f"<script>{_INLINE_EDIT_SCRIPT}</script>"
    return html.replace("</body>", f"{injection}</body>")


@app.get("/api/newsletter/alternatives")
async def get_alternative_articles():
    items = await asyncio.to_thread(_get_alternative_suggestions, newsletter_state.market_articles, 8)
    return {"status": "ok", "items": items}


@app.post("/api/newsletter/alternatives/append")
async def append_alternative_article(request: Request):
    try:
        body = await request.json()
    except Exception:
        return {"status": "error", "message": "Payload invalide"}

    article = body.get("article") or {}
    url = article.get("url", "").strip()
    if not url:
        return {"status": "error", "message": "Article invalide"}

    if any(existing.get("url") == url for existing in newsletter_state.market_articles):
        return {"status": "error", "message": "Cet article est déjà présent dans la newsletter"}

    newsletter_state.market_articles.append(article)
    await asyncio.to_thread(_render_state)
    await broadcast_newsletter_updated()
    return {"status": "ok"}


@app.post("/api/newsletter/alternatives/replace")
async def replace_alternative_article(request: Request):
    try:
        body = await request.json()
    except Exception:
        return {"status": "error", "message": "Payload invalide"}

    target_url = (body.get("target_url") or "").strip()
    suggestion = body.get("suggestion") or {}
    if not target_url or not suggestion.get("url"):
        return {"status": "error", "message": "Cible ou suggestion invalide"}

    for index, article in enumerate(newsletter_state.market_articles):
        if article.get("url") == target_url:
            newsletter_state.market_articles[index] = suggestion
            break
    else:
        return {"status": "error", "message": "Article cible introuvable"}

    await asyncio.to_thread(_render_state)
    await broadcast_newsletter_updated()
    return {"status": "ok"}


@app.post("/api/newsletter/alternatives/dismiss")
async def dismiss_alternative_article(request: Request):
    try:
        body = await request.json()
    except Exception:
        return {"status": "error", "message": "Payload invalide"}

    excluded_urls = {str(url) for url in body.get("excluded_urls", []) if str(url).strip()}
    item = await asyncio.to_thread(_get_alternative_suggestions, newsletter_state.market_articles, 1, excluded_urls)
    if not item:
        return {"status": "ok", "item": None}
    return {"status": "ok", "item": item[0]}


@app.post("/api/newsletter/article/remove")
async def remove_article_by_url(request: Request):
    try:
        body = await request.json()
    except Exception:
        return {"status": "error", "message": "Payload invalide"}
    url = (body.get("url") or "").strip()
    if not url:
        return {"status": "error", "message": "URL manquante"}
    original_count = len(newsletter_state.market_articles)
    newsletter_state.market_articles = [
        a for a in newsletter_state.market_articles if a.get("url") != url
    ]
    if len(newsletter_state.market_articles) == original_count:
        return {"status": "error", "message": "Article introuvable"}
    await asyncio.to_thread(_render_state)
    logger.info("Article removed via UI: %s", url)
    return {"status": "ok"}


@app.post("/api/newsletter/inline-edit")
async def inline_edit(edit: InlineEdit):
    _VALID_FIELDS = {"title", "summary", "description", "article_title", "content", "author_name", "author_title", "video_url"}
    field = edit.field if edit.field in _VALID_FIELDS else None
    if not field:
        return {"status": "error", "message": "Champ invalide"}
    value = edit.value.strip()
    if not value:
        return {"status": "error", "message": "Valeur vide"}
    # Sanitize HTML fields to prevent script injection
    if field == "content":
        value = sanitize_html(value)

    if edit.section == "capgemini":
        if newsletter_state.capgemini_article is None:
            return {"status": "error", "message": "Aucun article Capgemini"}
        newsletter_state.capgemini_article[field] = value
    elif edit.section == "market":
        articles = newsletter_state.market_articles
        if not (0 <= edit.index < len(articles)):
            return {"status": "error", "message": f"Index {edit.index} invalide"}
        articles[edit.index][field] = value
    elif edit.section == "reuters":
        if newsletter_state.reuters_video is None:
            return {"status": "error", "message": "Aucune vidéo Reuters"}
        newsletter_state.reuters_video[field] = value
    elif edit.section == "edito":
        if newsletter_state.edito is None:
            return {"status": "error", "message": "Aucun edito défini"}
        newsletter_state.edito[field] = value
    else:
        return {"status": "error", "message": "Section invalide"}

    await asyncio.to_thread(_render_state)
    logger.info("Inline edit: %s[%d].%s = %.60s", edit.section, edit.index, field, value)
    return {"status": "ok"}


@app.post("/api/newsletter/reuters/upload-image")
async def upload_reuters_image(request: Request):
    """Receive a base64 data-URL image, save it to crops/ and update reuters thumbnail."""
    try:
        body = await request.json()
    except Exception:
        return {"status": "error", "message": "Payload invalide"}
    data_url: str = body.get("data_url", "")
    if not data_url.startswith("data:image/"):
        return {"status": "error", "message": "Données image invalides"}
    try:
        import base64 as _b64
        header, b64_data = data_url.split(",", 1)
        img_bytes = _b64.b64decode(b64_data)
        fmt = "png" if "png" in header else ("webp" if "webp" in header else "jpg")
        from datetime import datetime as _dt
        filename = f"reuters_thumb_{_dt.now().strftime('%Y%m%d%H%M%S')}.{fmt}"
        (CROPS_DIR / filename).write_bytes(img_bytes)
        url = f"/crops/{filename}"
        if newsletter_state.reuters_video is None:
            newsletter_state.reuters_video = {"title": "", "video_url": "", "thumbnail_url": url,
                                              "description": "", "video_id": "", "published_at": "", "channel": "Reuters"}
        else:
            newsletter_state.reuters_video["thumbnail_url"] = url
        await asyncio.to_thread(_render_state)
        logger.info("Reuters image uploaded: %s", url)
        return {"status": "ok", "url": url}
    except Exception as exc:
        logger.exception("Reuters image upload failed")
        return {"status": "error", "message": str(exc)}


@app.post("/api/newsletter/refresh")
async def refresh():
    newsletter_state.is_loading = True
    try:
        await asyncio.to_thread(initialize_newsletter)
        await broadcast_newsletter_updated()
        return {"status": "ok", "count": len(newsletter_state.market_articles)}
    except Exception as exc:
        logger.error("Refresh failed: %s", exc)
        return {"status": "error", "message": str(exc)}
    finally:
        newsletter_state.is_loading = False


@app.post("/api/newsletter/send")
async def send_newsletter_route():
    result = await asyncio.to_thread(skill_send_newsletter)

    if result.get("success"):
        logger.info("Newsletter sent via HTTP endpoint to: %s", newsletter_state.recipients)
        return {"status": "ok", "recipients": newsletter_state.recipients}
    return {"status": "error", "message": result.get("error", "Erreur inconnue")}


@app.get("/api/newsletter/number")
async def get_newsletter_number():
    return {"number": newsletter_state.newsletter_number}


@app.post("/api/newsletter/number")
async def set_newsletter_number(request: Request):
    try:
        body = await request.json()
        number = int(body.get("number", 0))
    except Exception:
        return {"status": "error", "message": "Valeur invalide"}
    if number < 1:
        return {"status": "error", "message": "Le numéro doit être ≥ 1"}

    from web.agent import skill_set_newsletter_number
    result = await asyncio.to_thread(skill_set_newsletter_number, number)
    if result.get("success"):
        await broadcast_newsletter_updated()
        return {"status": "ok", "number": number, "loaded_existing": result.get("loaded_existing", False)}
    return {"status": "error", "message": result.get("error", "Erreur inconnue")}


@app.get("/api/newsletter/date")
async def get_newsletter_date():
    return {"date": newsletter_state.newsletter_date}


@app.post("/api/newsletter/date")
async def set_newsletter_date(request: Request):
    try:
        body = await request.json()
        date = str(body.get("date", "")).strip()
    except Exception:
        return {"status": "error", "message": "Payload invalide"}
    if not date:
        return {"status": "error", "message": "Date manquante"}

    from web.agent import skill_set_newsletter_date
    result = await asyncio.to_thread(skill_set_newsletter_date, date)
    if result.get("success"):
        await broadcast_newsletter_updated()
        return {"status": "ok", "date": result["date"]}
    return {"status": "error", "message": result.get("error", "Erreur inconnue")}


@app.get("/api/admin/config")
async def admin_config():
    gmail_user = os.getenv("GMAIL_USER", "")
    recipients = newsletter_state.recipients
    wa_url = os.getenv("WA_SERVICE_URL", "http://127.0.0.1:3001")
    wa_numbers_raw = os.getenv("WHATSAPP_ALLOWED_NUMBERS", "")
    wa_numbers = [n.strip() for n in wa_numbers_raw.split(",") if n.strip()]
    ssl_verify = os.getenv("SSL_VERIFY", "true").lower() not in ("false", "0", "no")
    tavily_configured = bool(os.getenv("TAVILY_API_KEY", "").strip())
    youtube_configured = bool(os.getenv("YOUTUBE_API_KEY", "").strip())

    from web import llm_client
    llm_provider = llm_client.PROVIDER
    llm_configured = llm_client.is_configured()
    llm_model = llm_client.MAIN_MODEL
    llm_model_fast = llm_client.FAST_MODEL

    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))

    wa_status = "offline"
    try:
        resp = await asyncio.to_thread(requests.get, f"{wa_url}/status", timeout=2)
        wa_status = resp.json().get("status", "unknown")
    except Exception:
        pass

    return {
        "email": {
            "gmail_user": gmail_user or None,
            "recipients": recipients,
            "configured": bool(gmail_user and recipients),
        },
        "whatsapp": {
            "bridge_url": wa_url,
            "allowed_numbers": wa_numbers,
            "bridge_status": wa_status,
        },
        "system": {
            "host": host,
            "port": port,
            "ssl_verify": ssl_verify,
            "tavily_configured": tavily_configured,
            "youtube_configured": youtube_configured,
            "llm_provider": llm_provider,
            "llm_configured": llm_configured,
            "llm_model": llm_model,
            "llm_model_fast": llm_model_fast,
        },
        "cost": {
            "session_cost_usd": newsletter_state.session_cost_usd,
            "session_input_tokens": newsletter_state.session_input_tokens,
            "session_output_tokens": newsletter_state.session_output_tokens,
            "last_context_tokens": newsletter_state.last_context_tokens,
            "conversation_turns": newsletter_state.conversation_turns,
        },
    }


@app.post("/api/admin/cost/reset")
async def admin_cost_reset():
    newsletter_state.session_cost_usd = 0.0
    newsletter_state.session_input_tokens = 0
    newsletter_state.session_output_tokens = 0
    return {"ok": True}


@app.get("/api/admin/whatsapp/filter")
async def get_wa_filter():
    from web.whatsapp import _is_authorized

    senders = [
        {**s, "authorized": _is_authorized(s["number"], s.get("name", ""))}
        for s in newsletter_state.whatsapp_recent_senders
    ]
    return {
        "filter_numbers": newsletter_state.whatsapp_filter_numbers,
        "recent_senders": senders,
    }


@app.post("/api/admin/whatsapp/filter")
async def set_wa_filter(request: Request):
    from web.whatsapp import _save_filter_numbers

    body = await request.json()
    newsletter_state.whatsapp_filter_numbers = [
        str(n).strip() for n in body.get("numbers", []) if str(n).strip()
    ]
    _save_filter_numbers(newsletter_state.whatsapp_filter_numbers)
    return {"ok": True}


@app.post("/api/admin/recipients")
async def set_recipients(request: Request):
    import re as _re
    try:
        body = await request.json()
    except Exception:
        return {"status": "error", "message": "Payload invalide"}
    raw = body.get("recipients", [])
    if not isinstance(raw, list):
        return {"status": "error", "message": "Format invalide"}
    _email_re = _re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    cleaned = [str(r).strip() for r in raw if str(r).strip()]
    invalid = [r for r in cleaned if not _email_re.match(r)]
    if invalid:
        return {"status": "error", "message": f"Adresse(s) invalide(s) : {', '.join(invalid)}"}
    newsletter_state.recipients = cleaned
    logger.info("Recipients updated: %s", cleaned)
    return {"status": "ok", "recipients": cleaned}


@app.get("/preview", response_class=HTMLResponse)
async def newsletter_preview_page():
    """Serve the rendered newsletter HTML for headless-browser screenshot."""
    if not newsletter_state.preview_html:
        return HTMLResponse("<p>Newsletter not rendered yet.</p>", status_code=503)
    return HTMLResponse(newsletter_state.preview_html)


@app.post("/api/conversation/clear")
async def clear_conv():
    clear_conversation()
    return {"status": "ok"}


@app.post("/api/skill")
async def run_skill(req: Request):
    """Dispatch any newsletter skill by name. Used by the MCP server.

    Body: {"name": "skill_name", "args": {...}}
    """
    from web.agent import SKILL_MAP

    try:
        body = await req.json()
    except Exception:
        return {"success": False, "error": "Corps JSON invalide"}

    name = body.get("name", "")
    args = body.get("args", {})

    if name not in SKILL_MAP:
        return {"success": False, "error": f"Skill inconnu : '{name}'. Disponibles : {sorted(SKILL_MAP)}"}

    from web.agent import MODIFYING_TOOLS
    fn = SKILL_MAP[name]

    # Premier appel après démarrage (MCP avant toute ouverture de l'UI) : charger
    # l'édition du compteur, sinon les skills agiraient sur l'édition par défaut.
    if not newsletter_state.preview_html and name != "set_newsletter_number":
        number = _read_counter_number(newsletter_state.newsletter_number)
        await asyncio.to_thread(load_or_create_newsletter, number)

    try:
        if asyncio.iscoroutinefunction(fn):
            result = await fn(args)
        else:
            result = await asyncio.to_thread(fn, args)
        if name in MODIFYING_TOOLS and result.get("success"):
            await broadcast_newsletter_updated()
        return result
    except TypeError as exc:
        return {"success": False, "error": f"Paramètres invalides pour '{name}' : {exc}"}
    except Exception as exc:
        logger.exception("Error running skill '%s'", name)
        return {"success": False, "error": str(exc)}


# ── WebSocket ─────────────────────────────────────────────────

@app.websocket("/ws/chat")
async def ws_chat(websocket: WebSocket):
    await websocket.accept()
    _ws_clients.add(websocket)
    logger.info("WebSocket connected: %s", websocket.client)

    if not newsletter_state.preview_html:
        await websocket.send_json({"type": "status", "message": "Ouverture de la newsletter…"})
        number = _read_counter_number(newsletter_state.newsletter_number)
        result = await asyncio.to_thread(load_or_create_newsletter, number)
        await broadcast_newsletter_updated()
        if result.get("loaded_existing"):
            await websocket.send_json({
                "type": "status",
                "message": f"Newsletter #{number} rechargée telle que sauvegardée. Comment puis-je vous aider ?",
            })
        else:
            await websocket.send_json(
                {"type": "status", "message": "Newsletter prête ! Comment puis-je vous aider ?"}
            )

    try:
        while True:
            data = await websocket.receive_json()

            # ── Crop confirmation from UI ────────────────────
            if data.get("type") == "crop_done":
                await handle_crop_done(websocket, data)
                continue

            # ── Re-crop request from iframe image click ───────
            if data.get("type") == "recrop_article":
                art_url = data.get("url", "")
                article = next(
                    (a for a in newsletter_state.market_articles if a.get("url") == art_url), None
                )
                if not article:
                    await websocket.send_json({"type": "text", "content": "Article introuvable."})
                    await websocket.send_json({"type": "done"})
                    continue
                orig = article.get("original_image_url") or ""
                if not orig or orig.startswith("/crops/") or orig.startswith("/assets/"):
                    await websocket.send_json({
                        "type": "text",
                        "content": "Image originale non disponible pour ce recadrage.",
                    })
                    await websocket.send_json({"type": "done"})
                    continue
                pos = next(
                    (i + 1 for i, a in enumerate(newsletter_state.market_articles)
                     if a.get("url") == art_url), -1
                )
                _pending_articles[art_url] = {
                    "article": article, "position": pos, "section": "market", "recrop": True,
                }
                await websocket.send_json({
                    "type":      "crop_request",
                    "url":       art_url,
                    "image_url": orig,
                    "title":     article.get("title", ""),
                    "position":  pos,
                })
                continue

            # ── Regular chat message ─────────────────────────
            user_msg = data.get("message", "").strip()
            if not user_msg:
                continue

            async for chunk in process_message(user_msg):
                # Intercept recrop_article results that need the crop modal
                if (
                    chunk.get("type") == "tool_result"
                    and chunk.get("tool") == "recrop_article"
                    and chunk.get("result", {}).get("needs_crop")
                ):
                    r = chunk["result"]
                    await websocket.send_json({
                        "type":      "crop_request",
                        "url":       r["url"],
                        "image_url": r["image_url"],
                        "title":     r["title"],
                        "position":  r.get("position", -1),
                    })
                # newsletter_updated → broadcast to all tabs instead of just this client
                if chunk.get("type") == "newsletter_updated":
                    await broadcast_newsletter_updated()
                else:
                    await websocket.send_json(chunk)

    except WebSocketDisconnect:
        logger.info("WebSocket disconnected")
    finally:
        _ws_clients.discard(websocket)


if __name__ == "__main__":
    _host = os.getenv("HOST", "127.0.0.1")
    _port = int(os.getenv("PORT", "8000"))
    uvicorn.run("web.server:app", host=_host, port=_port, reload=False)
