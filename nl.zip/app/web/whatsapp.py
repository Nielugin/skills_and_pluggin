"""
WhatsApp integration via Baileys (WhatsApp Web multi-device protocol).
No Meta Business account required — authentication is done by scanning a QR code
with the WhatsApp app, exactly like WhatsApp Web.

Architecture:
  whatsapp-service/index.js  (Node.js / Baileys, port 3001)
      ↕  HTTP
  web/whatsapp.py            (FastAPI routes, port 8000)
      ↕
  web/agent.py               (Claude newsletter agent)

Setup: open http://localhost:8000/setup/whatsapp and scan the QR code.
Start the Node.js bridge first:
  cd whatsapp-service && npm install && npm start
"""
import asyncio
import datetime
import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Optional

import requests as _requests
from fastapi import APIRouter, BackgroundTasks, Request
from fastapi.responses import HTMLResponse, JSONResponse

from web.state import newsletter_state

logger = logging.getLogger(__name__)
router = APIRouter()

_WA_SERVICE = os.getenv("WA_SERVICE_URL", "http://127.0.0.1:3001")

# ── Conversation filter persistence ────────────────────────────────────────
# whatsapp_filter_numbers lived only in memory — every backend restart wiped
# it back to "empty = every authorized conversation is forwarded", silently
# undoing whatever the user had configured in the Admin tab. Persist it.
from paths import WHATSAPP_FILTER_FILE as _FILTER_FILE


def _load_filter_numbers() -> list[str]:
    try:
        return json.loads(_FILTER_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []


def _save_filter_numbers(numbers: list[str]) -> None:
    try:
        _FILTER_FILE.write_text(json.dumps(numbers, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        logger.warning("Could not persist WhatsApp filter: %s", exc)


newsletter_state.whatsapp_filter_numbers = _load_filter_numbers()


# ── Outbound ──────────────────────────────────────────────────────────────────

def _wa_send(to: str, body: str) -> None:
    """Send a WhatsApp text message via the local Baileys service (blocking)."""
    print(f"[WhatsApp] → {to}: {body[:100]}", flush=True)
    try:
        r = _requests.post(
            f"{_WA_SERVICE}/send",
            json={"to": to, "text": body[:4096]},
            timeout=10,
        )
        r.raise_for_status()
    except Exception as exc:
        logger.error("WhatsApp send to %s failed: %s", to, exc)
        print(f"[WhatsApp] ✗ envoi échoué vers {to}: {exc}", flush=True)


async def _send(to: str, body: str) -> None:
    await asyncio.to_thread(_wa_send, to, body)


def _wa_send_image(to: str, image_b64: str, caption: str = "") -> None:
    """Send a WhatsApp image message via the local Baileys service (blocking)."""
    try:
        r = _requests.post(
            f"{_WA_SERVICE}/send-image",
            json={"to": to, "image": image_b64, "caption": caption},
            timeout=30,
        )
        r.raise_for_status()
    except Exception as exc:
        logger.error("WhatsApp send-image to %s failed: %s", to, exc)


async def _send_image(to: str, image_b64: str, caption: str = "") -> None:
    await asyncio.to_thread(_wa_send_image, to, image_b64, caption)


# ── Recent senders tracker ───────────────────────────────────────────────────

def _update_recent_sender(number: str, name: str) -> None:
    senders = [s for s in newsletter_state.whatsapp_recent_senders if s["number"] != number]
    senders.insert(0, {
        "number": number,
        "name": name,
        "last_seen": datetime.datetime.now().isoformat(timespec="seconds"),
    })
    newsletter_state.whatsapp_recent_senders = senders[:20]


# ── Auth ──────────────────────────────────────────────────────────────────────

def _entry_matches(entry: str, number: str, name: str) -> bool:
    """True if a filter entry (phone number OR conversation/group name) matches
    this sender — same matching rule used by the Admin UI (web/static/app.js)."""
    entry_digits = re.sub(r"\D", "", entry)
    clean = re.sub(r"\D", "", number)
    if entry_digits and entry_digits == clean:
        return True
    return entry.strip().lower() == name.strip().lower()


def _is_authorized(number: str, conv_name: str = "") -> bool:
    """
    A conversation (1-to-1 or group — for a group, *number* is the group's own
    id, so allowing it authorizes every participant in it) may talk to the
    agent if it matches the persisted, Admin-managed filter list — by phone
    number or by conversation/group name. This is the primary mechanism: it's
    editable live from the web UI, no .env edit or restart required, and it's
    how you let a whole WhatsApp group pilot the newsletter together.

    If that list is empty (nothing configured from the UI yet), fall back to
    the static WHATSAPP_ALLOWED_NUMBERS env allowlist. If neither is set,
    allow everyone (dev mode — always restrict one of the two in production).
    """
    if newsletter_state.whatsapp_filter_numbers:
        return any(
            _entry_matches(entry, number, conv_name)
            for entry in newsletter_state.whatsapp_filter_numbers
        )

    raw = os.getenv("WHATSAPP_ALLOWED_NUMBERS", "")
    if not raw.strip():
        return True
    clean   = re.sub(r"\D", "", number)          # digits only
    allowed = {re.sub(r"\D", "", n) for n in raw.split(",") if n.strip()}
    return clean in allowed


# ── Message handlers ──────────────────────────────────────────────────────────

_SCREENSHOT_KEYWORDS = (
    "screenshot", "capture", "aperçu", "apercu",
    "preview", "visuel", "photo de la newsletter", "image de la newsletter",
)


def _is_screenshot_request(text: str) -> bool:
    lower = text.lower().strip()
    return any(kw in lower for kw in _SCREENSHOT_KEYWORDS)


async def _handle(sender: str, text: str) -> None:
    url_match = re.search(r"https?://\S+", text)
    if url_match:
        await _handle_url(sender, url_match.group(0), text)
    elif _is_screenshot_request(text):
        await _handle_screenshot(sender)
    else:
        await _handle_text(sender, text)


async def _handle_screenshot(sender: str) -> None:
    """Generate a full-page screenshot of the newsletter and send it via WhatsApp."""
    from web.agent import skill_screenshot_newsletter
    from web.state import newsletter_state

    await _send(sender, "📸 Génération de l'aperçu en cours…")

    result = await asyncio.to_thread(skill_screenshot_newsletter)

    if result.get("success") and result.get("image_b64"):
        caption = f"📰 Newsletter #{newsletter_state.newsletter_number} — {newsletter_state.newsletter_title}"
        await _send_image(sender, result["image_b64"], caption)
    else:
        err = result.get("error", "Erreur inconnue")
        await _send(sender, f"❌ Impossible de générer l'aperçu : {err}")


async def _handle_url(sender: str, url: str, original: str) -> None:
    pos_match = re.search(r"(?:position|pos|en)\s+(\d+)", original, re.I)
    position  = int(pos_match.group(1)) if pos_match else -1

    await _send(sender, f"🔍 Récupération de l'article…\n{url}")

    from web.agent import skill_add_article_from_url, skill_auto_crop_and_insert
    from web.state import broadcast_newsletter_updated
    result = await asyncio.to_thread(skill_add_article_from_url, url, position)

    if result.get("needs_crop"):
        # Auto center-square crop — no UI interaction needed from WhatsApp
        result = await asyncio.to_thread(skill_auto_crop_and_insert, url, position)
        if result.get("success"):
            reply = (
                f"✅ Article ajouté en position {result.get('position', '?')} :\n"
                f"*{result['title']}*\n"
                f"Source : {result['source']}"
            )
            await broadcast_newsletter_updated()
        else:
            reply = f"❌ {result.get('error', 'Erreur inconnue')}"
    elif result.get("success"):
        reply = (
            f"✅ Article ajouté en position {result.get('position', '?')} :\n"
            f"*{result['title']}*\n"
            f"Source : {result['source']}"
        )
        await broadcast_newsletter_updated()
    else:
        reply = f"❌ {result.get('error', 'Erreur inconnue')}"

    await _send(sender, reply)


async def _handle_text(sender: str, text: str) -> None:
    from web.agent import process_message
    from web.state import broadcast_newsletter_updated, newsletter_state

    parts: list[str] = []
    newsletter_updated = False
    screenshot_b64: Optional[str] = None

    async for chunk in process_message(text):
        if chunk.get("type") == "text":
            parts.append(chunk["content"])
        elif chunk.get("type") == "newsletter_updated":
            newsletter_updated = True
        elif chunk.get("type") == "tool_result" and chunk.get("tool") == "screenshot_newsletter":
            result = chunk.get("result", {})
            if result.get("success") and result.get("image_b64"):
                screenshot_b64 = result["image_b64"]

    if newsletter_updated:
        await broadcast_newsletter_updated()

    reply = " ".join(parts).strip() or "✅ Action effectuée."
    if newsletter_updated:
        reply += "\n\n📰 _Newsletter mise à jour._"

    await _send(sender, reply[:4096])

    if screenshot_b64:
        caption = f"📰 Newsletter #{newsletter_state.newsletter_number} — {newsletter_state.newsletter_title}"
        await _send_image(sender, screenshot_b64, caption)


# ── Internal webhook (called by Node.js service) ──────────────────────────────

@router.post("/webhook/whatsapp-internal")
async def whatsapp_internal(
    background_tasks: BackgroundTasks,
    request: Request,
):
    """Receive forwarded messages from the local Baileys Node.js bridge."""
    try:
        data: dict[str, Any] = await request.json()
    except Exception:
        return JSONResponse({"status": "error"}, status_code=400)

    sender    = str(data.get("from", "")).strip()
    text      = str(data.get("text", "")).strip()
    conv_name = str(data.get("conv_name", sender)).strip()

    if not sender or not text:
        return JSONResponse({"status": "ignored"})

    # Track every conversation that messages the bot — including ones not yet
    # authorized — so a brand-new group shows up in Admin → WhatsApp and can be
    # allowed with a checkbox instead of hunting down its id for .env.
    _update_recent_sender(sender, conv_name)

    if not _is_authorized(sender, conv_name):
        logger.info("WhatsApp sender %s (%s) not authorized — tracked but ignored", sender, conv_name)
        return JSONResponse({"status": "ignored"})

    logger.info("WhatsApp ← %s (%s): %s", sender, conv_name, text[:100])
    print(f"[WhatsApp] ← {sender} ({conv_name}): {text[:100]}", flush=True)
    background_tasks.add_task(_handle, sender, text)
    return JSONResponse({"status": "ok"})


# ── Setup page ────────────────────────────────────────────────────────────────

@router.get("/setup/whatsapp", response_class=HTMLResponse)
async def setup_page():
    """QR code setup wizard — scanne le QR avec WhatsApp pour lier le compte."""
    return HTMLResponse(_SETUP_HTML)


@router.get("/api/whatsapp/status")
async def wa_status():
    """Proxy the Baileys service status to the browser."""
    try:
        r = _requests.get(f"{_WA_SERVICE}/qr", timeout=4)
        return JSONResponse(r.json())
    except Exception as exc:
        return JSONResponse({"status": "unavailable", "error": str(exc)})


@router.post("/api/whatsapp/logout")
async def wa_logout():
    """Delete the session and force a new QR code."""
    try:
        r = _requests.post(f"{_WA_SERVICE}/logout", timeout=6)
        return JSONResponse(r.json())
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


# ── Setup HTML ────────────────────────────────────────────────────────────────

_SETUP_HTML = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Connexion WhatsApp</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: system-ui,sans-serif; background:#f0f2f5; margin:0; padding:24px; color:#1a1a1a; }
  .card { background:#fff; max-width:480px; margin:0 auto; border-radius:16px;
          box-shadow:0 2px 16px rgba(0,0,0,.1); padding:36px; text-align:center; }
  h1 { font-size:22px; margin:0 0 6px; }
  .sub { color:#666; font-size:14px; margin-bottom:28px; }
  #qr-wrap { width:264px; height:264px; margin:0 auto 20px; border:2px solid #e0e0e0;
             border-radius:12px; display:flex; align-items:center; justify-content:center;
             background:#fafafa; overflow:hidden; }
  #qr-wrap img { width:248px; height:248px; }
  .spinner { width:40px; height:40px; border:4px solid #e0e0e0;
             border-top-color:#25d366; border-radius:50%; animation:spin .8s linear infinite; }
  @keyframes spin { to { transform:rotate(360deg); } }
  .status { font-size:14px; color:#666; min-height:20px; margin-bottom:16px; }
  .status.ok  { color:#25d366; font-weight:600; }
  .status.err { color:#e53935; }
  .steps { text-align:left; background:#f9f9f9; border-radius:8px; padding:16px 20px;
           font-size:13px; color:#444; margin-bottom:20px; }
  .steps li { margin-bottom:8px; }
  .btn { border:none; border-radius:8px; padding:10px 20px; font-size:14px;
         font-weight:600; cursor:pointer; }
  .btn-logout { background:#f44336; color:#fff; display:none; }
  .btn-back { background:#e0e0e0; color:#333; margin-right:8px; }
  a.back { text-decoration:none; }
</style>
</head>
<body>
<div class="card">
  <h1>📱 Connexion WhatsApp</h1>
  <p class="sub">Scanne le QR code avec ton téléphone pour lier ton numéro WhatsApp à l'agent newsletter.</p>

  <div id="qr-wrap"><div class="spinner"></div></div>
  <p class="status" id="status">Connexion au service WhatsApp…</p>

  <ol class="steps">
    <li>Ouvre <strong>WhatsApp</strong> sur ton téléphone</li>
    <li>Appuie sur <strong>⋮ → Appareils liés → Lier un appareil</strong></li>
    <li>Scanne le QR ci-dessus</li>
  </ol>

  <button class="btn btn-logout" id="btn-logout" onclick="logout()">🔓 Délier ce numéro</button>
  <a class="back" href="/"><button class="btn btn-back">← Retour à l'interface</button></a>
</div>

<script>
  let _polling = null;

  function poll() {
    fetch('/api/whatsapp/status')
      .then(r => r.json())
      .then(data => {
        const wrap   = document.getElementById('qr-wrap');
        const status = document.getElementById('status');
        const btnOut = document.getElementById('btn-logout');

        if (data.status === 'open') {
          wrap.innerHTML = '<div style="font-size:64px">✅</div>';
          status.textContent = 'WhatsApp connecté !';
          status.className = 'status ok';
          btnOut.style.display = 'inline-block';
          clearInterval(_polling);

        } else if (data.status === 'qr' && data.qr) {
          wrap.innerHTML = '<img src="' + data.qr + '" alt="QR code">';
          status.textContent = 'En attente du scan…';
          status.className = 'status';
          btnOut.style.display = 'none';

        } else if (data.status === 'connecting') {
          wrap.innerHTML = '<div class="spinner"></div>';
          status.textContent = 'Connexion en cours…';
          status.className = 'status';

        } else if (data.status === 'unavailable') {
          wrap.innerHTML = '<div style="font-size:40px">⚠️</div>';
          status.innerHTML = 'Service WhatsApp non démarré.<br>' +
            '<small>Lance : <code>cd whatsapp-service && npm start</code></small>';
          status.className = 'status err';
          clearInterval(_polling);

        } else {
          status.textContent = 'En attente…';
        }
      })
      .catch(() => {
        document.getElementById('status').textContent = 'Service injoignable.';
        document.getElementById('status').className = 'status err';
      });
  }

  async function logout() {
    if (!confirm('Délier ce numéro WhatsApp ?')) return;
    await fetch('/api/whatsapp/logout', { method: 'POST' });
    document.getElementById('btn-logout').style.display = 'none';
    document.getElementById('status').textContent = 'Session supprimée — nouveau QR dans 2 s…';
    document.getElementById('qr-wrap').innerHTML = '<div class="spinner"></div>';
    setTimeout(() => { _polling = setInterval(poll, 2000); }, 2500);
  }

  poll();
  _polling = setInterval(poll, 2000);
</script>
</body>
</html>"""
