"""Newsletter state singleton shared across the web layer."""
import datetime
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class NewsletterState:
    market_articles: list = field(default_factory=list)
    capgemini_article: Optional[dict] = None
    reuters_video: Optional[dict] = field(default_factory=lambda: {
        "title":         "Double storms trigger mudslides, prompt evacuation orders in Japan",
        "video_id":      "",
        "video_url":     "https://www.reuters.com/video/watch/idRW302227062026RP1/?chan=home",
        "thumbnail_url": "/assets/place_holder.png",
        "description":   "",
        "published_at":  "",
        "channel":       "Reuters",
    })
    edito: Optional[dict] = None
    newsletter_number: int = 541
    newsletter_title: str = "Capgemini Innovation Watch & Upcoming Trends"
    # Reference date of this edition (YYYY-MM-DD) — displayed in the header and
    # used as the "now" anchor for article-freshness checks, so reopening a past
    # edition still judges articles as too old/fresh relative to *its* date.
    newsletter_date: str = field(default_factory=lambda: datetime.date.today().isoformat())
    last_updated: Optional[datetime.datetime] = None
    preview_html: str = ""
    is_loading: bool = False
    session_cost_usd: float = 0.0
    session_input_tokens: int = 0
    session_output_tokens: int = 0
    last_context_tokens: int = 0
    conversation_turns: int = 0
    whatsapp_filter_numbers: list[str] = field(default_factory=list)
    whatsapp_recent_senders: list = field(default_factory=list)
    recipients: list = field(default_factory=list)


newsletter_state = NewsletterState()

# ── WebSocket broadcast registry ──────────────────────────────
# server.py registers/unregisters clients here; whatsapp.py and
# other modules call broadcast_newsletter_updated() to push
# {"type": "newsletter_updated"} to every open browser tab.

_ws_clients: set = set()


async def broadcast_newsletter_updated() -> None:
    dead = set()
    for ws in _ws_clients:
        try:
            await ws.send_json({"type": "newsletter_updated"})
        except Exception:
            dead.add(ws)
    _ws_clients.difference_update(dead)
