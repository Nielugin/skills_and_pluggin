"""
MCP server — Newsletter Generator.

Thin HTTP client over the web server (http://localhost:8000/api/skill).
The web server is the single source of truth for newsletter state —
both the web UI and MCP share the same state automatically.

Le backend est démarré automatiquement au premier appel s'il ne répond pas
(via ../scripts/nl.py, sans rien installer). Dans le plugin Claude Code, ce
serveur est déclaré dans .mcp.json et lancé avec le Python du venv du plugin.
"""
import base64
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from paths import load_env
load_env()

import requests
from mcp.server.fastmcp import FastMCP

_HOST = os.getenv("HOST", "127.0.0.1")
_PORT = int(os.getenv("PORT", "8000"))
_BASE = f"http://{_HOST}:{_PORT}"

mcp = FastMCP(
    "Newsletter Generator",
    instructions=(
        "Agent de génération de newsletter Capgemini Innovation Watch. "
        "Toutes les modifications sont synchronisées en temps réel avec "
        "l'interface web (http://localhost:8000). "
        "Commence par get_newsletter_state pour connaître l'état actuel."
    ),
)


_LAUNCHER = ROOT.parent / "scripts" / "nl.py"


def _start_backend() -> str:
    """Lance le backend via le lanceur du plugin (sans rien installer). Renvoie sa sortie.

    La sortie est capturée : stdout est réservé au protocole MCP."""
    if not _LAUNCHER.exists():
        return f"lanceur introuvable : {_LAUNCHER}"
    try:
        proc = subprocess.run(
            [sys.executable, str(_LAUNCHER), "start", "--install", "none"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            stdin=subprocess.DEVNULL, timeout=300,
        )
        return (proc.stdout + proc.stderr).strip()
    except (subprocess.SubprocessError, OSError) as exc:
        return str(exc)


def _post(name: str, args: dict) -> dict:
    r = requests.post(f"{_BASE}/api/skill", json={"name": name, "args": args}, timeout=120)
    r.raise_for_status()
    return r.json()


def _skill(name: str, **args: Any) -> dict:
    """Call a skill on the running web server (started on demand)."""
    payload = {k: v for k, v in args.items() if v is not None}
    try:
        return _post(name, payload)
    except requests.ConnectionError:
        output = _start_backend()
        try:
            return _post(name, payload)
        except requests.ConnectionError:
            return {
                "success": False,
                "error": f"Web server injoignable ({_BASE}) et démarrage automatique en échec. "
                         f"Utiliser le skill nl:newsletter-server. Sortie du lanceur :\n{output[-1500:]}",
            }
        except Exception as exc:
            return {"success": False, "error": str(exc)}
    except Exception as exc:
        return {"success": False, "error": str(exc)}


# ── Tools ─────────────────────────────────────────────────────────────────────

@mcp.tool()
def get_newsletter_state() -> dict:
    """Retourne l'état actuel de la newsletter : numéro, liste des articles
    avec position/titre/source, présence de l'article Capgemini et de la vidéo Reuters."""
    return _skill("get_newsletter_state")


@mcp.tool()
def fetch_and_add_article(topic: str, position: int = -1) -> dict:
    """Recherche un article frais sur un thème/mot-clé depuis les flux RSS
    et l'insère dans la newsletter.

    Args:
        topic: Thème ou mot-clé (ex: 'quantum', 'véhicules électriques', 'IA générative').
        position: Position 1-based d'insertion. -1 pour ajouter en fin de liste.
    """
    return _skill("fetch_and_add_article", topic=topic, position=position)


@mcp.tool()
def search_and_add_article(query: str, position: int = -1) -> dict:
    """Recherche un article sur le web (Tavily / DuckDuckGo) et l'insère dans la newsletter.

    Args:
        query: Description ou mots-clés de l'article recherché.
        position: Position 1-based d'insertion. -1 pour ajouter en fin de liste.
    """
    return _skill("search_and_add_article", query=query, position=position)


@mcp.tool()
def add_article_from_url(url: str, position: int = -1) -> dict:
    """Récupère le contenu d'une URL (titre, résumé, image) et insère l'article
    dans la newsletter.

    Args:
        url: URL complète de l'article (ex: https://techcrunch.com/...).
        position: Position 1-based d'insertion. -1 pour ajouter en fin de liste.
    """
    return _skill("add_article_from_url", url=url, position=position)


@mcp.tool()
def remove_article(
    position: Optional[int] = None,
    title_keyword: Optional[str] = None,
) -> dict:
    """Supprime un article de la newsletter par sa position ou un mot-clé de son titre.

    Args:
        position: Position 1-based de l'article.
        title_keyword: Mot-clé dans le titre de l'article.
    """
    return _skill("remove_article", position=position, title_keyword=title_keyword)


@mcp.tool()
def move_article(
    to_position: int,
    from_position: Optional[int] = None,
    title_keyword: Optional[str] = None,
) -> dict:
    """Déplace un article vers une nouvelle position dans la newsletter.

    Args:
        to_position: Nouvelle position 1-based cible.
        from_position: Position source 1-based.
        title_keyword: Mot-clé dans le titre de l'article à déplacer.
    """
    return _skill("move_article", to_position=to_position, from_position=from_position, title_keyword=title_keyword)


@mcp.tool()
def update_article_summary(
    summary: str,
    position: Optional[int] = None,
    title_keyword: Optional[str] = None,
    section: str = "market",
) -> dict:
    """Modifie le résumé (abstract) d'un article market ou Capgemini.

    Args:
        summary: Nouveau texte du résumé.
        position: Position 1-based de l'article market.
        title_keyword: Mot-clé dans le titre pour identifier l'article market.
        section: 'market' (défaut) ou 'capgemini'.
    """
    return _skill("update_article_summary", summary=summary, position=position,
                  title_keyword=title_keyword, section=section)


@mcp.tool()
def set_capgemini_from_url(url: str) -> dict:
    """Scrape une URL et la définit comme article de la section Capgemini Technology.

    Args:
        url: URL de l'article Capgemini à afficher.
    """
    return _skill("set_capgemini_from_url", url=url)


@mcp.tool()
def refresh_capgemini_article() -> dict:
    """Recharge l'article Capgemini Technology depuis le flux RSS / site officiel."""
    return _skill("refresh_capgemini_article")


@mcp.tool()
def remove_capgemini_article() -> dict:
    """Supprime l'article de la section Capgemini Technology."""
    return _skill("remove_capgemini_article")


def _capture_data_url(thumbnail_path: str) -> tuple[Optional[str], Optional[dict]]:
    """Lit une capture locale et la renvoie en data URL : (data_url, erreur)."""
    if not thumbnail_path:
        return None, None
    path = Path(thumbnail_path).expanduser()
    if not path.is_file():
        return None, {"success": False, "error": f"Capture introuvable : {thumbnail_path}"}
    if path.stat().st_size > 10_000_000:
        return None, {"success": False, "error": "Capture trop volumineuse (> 10 Mo)."}
    mime = {".png": "image/png", ".webp": "image/webp"}.get(path.suffix.lower(), "image/jpeg")
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode(), None


@mcp.tool()
def get_reuters_video() -> dict:
    """Lit la section Reuters (Keep a look outside) : titre, lien, description et URL de l'image."""
    return _skill("get_reuters_video")


@mcp.tool()
def set_reuters_video(
    title: str,
    video_url: str,
    description: str = "",
    thumbnail_path: str = "",
    thumbnail_url: str = "",
) -> dict:
    """Remplit la section Reuters (Keep a look outside) avec une vidéo choisie : titre, lien,
    description et capture. Utilisé par le skill nl:newsletter-reuters.

    Args:
        title: Titre de la vidéo.
        video_url: Lien de la vidéo (https://...).
        description: Description courte (300 caractères max).
        thumbnail_path: Chemin local d'une capture d'écran de la vidéo (PNG/JPEG), prioritaire.
        thumbnail_url: URL de l'image/poster de la vidéo, utilisée si aucune capture locale.
    """
    data_url, error = _capture_data_url(thumbnail_path)
    if error:
        return error
    return _skill(
        "set_reuters_video", title=title, video_url=video_url, description=description,
        thumbnail_data_url=data_url, thumbnail_url=thumbnail_url or None,
    )


@mcp.tool()
def update_reuters_video(
    title: Optional[str] = None,
    video_url: Optional[str] = None,
    description: Optional[str] = None,
    thumbnail_path: str = "",
    thumbnail_url: Optional[str] = None,
) -> dict:
    """Modifie la section Reuters : seuls les champs fournis changent.

    Args:
        title: Nouveau titre.
        video_url: Nouveau lien de la vidéo.
        description: Nouvelle description (300 caractères max).
        thumbnail_path: Chemin local d'une nouvelle capture (PNG/JPEG), prioritaire.
        thumbnail_url: Nouvelle image par URL, utilisée si aucune capture locale.
    """
    data_url, error = _capture_data_url(thumbnail_path)
    if error:
        return error
    return _skill(
        "update_reuters_video", title=title, video_url=video_url, description=description,
        thumbnail_data_url=data_url, thumbnail_url=thumbnail_url,
    )


@mcp.tool()
def remove_reuters_video() -> dict:
    """Supprime la vidéo de la section Reuters."""
    return _skill("remove_reuters_video")


@mcp.tool()
def set_edito(
    article_title: str,
    content: str,
) -> dict:
    """Crée ou remplace le contenu de l'édito. L'identité de l'auteur est verrouillée.

    Args:
        article_title: Titre de l'article de l'édito.
        content: Corps de l'édito en HTML simple (<ul><li><b><em>).
    """
    return _skill("set_edito", article_title=article_title, content=content)


@mcp.tool()
def update_edito(
    article_title: Optional[str] = None,
    content: Optional[str] = None,
) -> dict:
    """Modifie un ou plusieurs champs du contenu de l'édito. L'identité de l'auteur est verrouillée.

    Args:
        article_title: Nouveau titre de l'article.
        content: Nouveau corps HTML.
    """
    return _skill("update_edito", article_title=article_title, content=content)


@mcp.tool()
def get_edito() -> dict:
    """Retourne l'édito actuel (titre, corps HTML, auteur) et indique si sa signature
    « Sincerely yours » / « Patrice » est conforme avant l'envoi."""
    return _skill("get_edito")


@mcp.tool()
def remove_edito() -> dict:
    """Supprime l'édito de la newsletter."""
    return _skill("remove_edito")


@mcp.tool()
def check_edito_from_email() -> dict:
    """Vérifie la boîte Gmail pour un e-mail d'édito correspondant à la newsletter courante.
    Si trouvé, remplace l'édito actuel."""
    return _skill("check_edito_from_email")


@mcp.tool()
def send_newsletter() -> dict:
    """Génère un PDF de la newsletter et l'envoie par e-mail aux destinataires configurés."""
    return _skill("send_newsletter")


@mcp.tool()
def refresh_all_articles() -> dict:
    """Rafraîchit tous les articles depuis les flux RSS (marché, Capgemini, Reuters)."""
    return _skill("refresh_all_articles")


@mcp.tool()
def render_preview() -> dict:
    """Régénère le rendu HTML de la newsletter après des modifications manuelles."""
    return _skill("render_preview")


@mcp.tool()
def screenshot_newsletter() -> dict:
    """Génère une capture d'écran JPEG pleine page de la newsletter.
    À utiliser quand l'utilisateur demande un aperçu visuel, une preview image
    ou un screenshot de la newsletter."""
    return _skill("screenshot_newsletter")


@mcp.tool()
def set_newsletter_number(number: int) -> dict:
    """Change le numéro de la newsletter courante et sauvegarde dans .newsletter_counter.

    Si ce numéro correspond à une édition déjà construite précédemment, elle est
    rechargée telle quelle (articles, edito, sections) sans aucune recherche RSS.
    Si le numéro n'a jamais été utilisé, une toute nouvelle édition est créée
    (recherche RSS complète, edito par défaut, date remise à aujourd'hui).

    Args:
        number: Nouveau numéro (entier ≥ 1).
    """
    return _skill("set_newsletter_number", number=number)


@mcp.tool()
def get_newsletter_date(number: int | None = None) -> dict:
    """Retourne la date de référence de la newsletter courante, ou d'une édition existante
    si `number` est fourni (sans la charger).

    Args:
        number: Numéro d'édition (optionnel).
    """
    kwargs = {} if number is None else {"number": number}
    return _skill("get_newsletter_date", **kwargs)


@mcp.tool()
def list_newsletters() -> dict:
    """Liste les éditions existantes (numéro, date, titre, titre d'édito, nombre d'articles)."""
    return _skill("list_newsletters")


@mcp.tool()
def get_newsletter_title() -> dict:
    """Retourne le titre de la newsletter (affiché dans l'en-tête)."""
    return _skill("get_newsletter_title")


@mcp.tool()
def set_newsletter_title(title: str) -> dict:
    """Modifie le titre de la newsletter (affiché dans l'en-tête, suivi de #numéro).

    Args:
        title: Nouveau titre.
    """
    return _skill("set_newsletter_title", title=title)


@mcp.tool()
def set_newsletter_date(date: str) -> dict:
    """Modifie la date de référence de la newsletter (format AAAA-MM-JJ).

    Cette date est affichée dans l'en-tête et sert de repère pour juger de la
    fraîcheur des articles : un article est considéré « trop ancien » par
    rapport à cette date, pas par rapport à la date du jour réelle. Utile en
    particulier après avoir rouvert une édition passée via set_newsletter_number.

    Args:
        date: Date au format AAAA-MM-JJ (ex: 2026-07-19).
    """
    return _skill("set_newsletter_date", date=date)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    mcp.run(transport="stdio")
