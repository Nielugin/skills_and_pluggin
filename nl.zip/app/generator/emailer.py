"""
Sends the newsletter via Gmail SMTP with a PDF attachment.
Images are embedded via MIME CID references (compatible with Outlook, Gmail, Apple Mail).
Quality is auto-adjusted to keep the total email under 1 MB.
"""

import base64
import io
import logging
import os
import re
import smtplib
from email.mime.application import MIMEApplication
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import requests
from PIL import Image
from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import sync_playwright

from generator.drive_uploader import upload_pdf_to_drive

logger = logging.getLogger(__name__)

GMAIL_SMTP_HOST = "smtp.gmail.com"
GMAIL_SMTP_PORT = 587

from paths import CROPS_DIR as _CROPS_DIR, PICTURES_DIR as _ASSETS_DIR

_HTTP_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
}

# Browser channels to try, in order (uses the system-installed browser, no bundled download needed)
_BROWSER_CHANNELS = ["chrome", "msedge", None]  # None = Chromium installé par `playwright install chromium`

# Target total email size (bytes). 1 MB = 1 048 576 bytes; we keep margin for headers.
_MAX_EMAIL_BYTES = 950_000
# MIME base64 encoding adds ~37% overhead
_B64_OVERHEAD = 1.37
# Max display width — matches the newsletter's actual column width (750px)
# so full-width banners (header/market/capgemini) aren't downscaled below
# their display size and stretched back up (blurry). Article thumbnails
# (80/152px) are well under this cap and are unaffected.
_MAX_IMG_WIDTH = 750
# JPEG quality used for every compressible image — fixed at the top step,
# never lowered to fit a byte budget (see _build_inline_images).
_IMG_QUALITY = 78


def _inline_local_images(html: str) -> str:
    """Replace /crops/ and /assets/ src references with base64 data URIs.

    generate_pdf() loads the HTML via a file:// URI, which cannot resolve
    paths meant to be served by the FastAPI app (/crops/, /assets/). Inlining
    them as data URIs lets the headless browser render them without a server.
    """
    srcs = list(dict.fromkeys(re.findall(r'src="([^"]+)"', html)))
    replacements: dict[str, str] = {}
    for src in srcs:
        if src.startswith("data:image") or src.startswith(("http://", "https://")):
            continue
        raw = _download_raw(src)
        if raw is None:
            continue
        ext = Path(src).suffix.lstrip(".").lower() or "png"
        mime = "jpeg" if ext == "jpg" else ext
        replacements[src] = f"data:image/{mime};base64,{base64.b64encode(raw).decode()}"

    def _replace(m: re.Match[str]) -> str:
        src = m.group(1)
        return f'src="{replacements[src]}"' if src in replacements else m.group(0)

    return re.sub(r'src="([^"]+)"', _replace, html)


_BACK_TO_TOP_BLOCK = re.compile(
    r'<!-- back to top -->.*?</table>', re.DOTALL
)


def _strip_back_to_top_links(html: str) -> str:
    """Remove the in-page '#top' navigation blocks — meaningless in a static PDF."""
    return _BACK_TO_TOP_BLOCK.sub('', html)


def generate_pdf(html: str) -> bytes:
    """Convert newsletter HTML to PDF using Chrome/Edge via Playwright.

    Playwright's page.pdf() has no header/footer by default (unlike Chrome's
    CLI --print-to-pdf, whose --print-to-pdf-no-header flag stopped working
    on recent Chrome versions) and lets us force background graphics on.
    """
    html = _strip_back_to_top_links(html)
    html = _inline_local_images(html)

    last_error: Exception | None = None
    with sync_playwright() as p:
        for channel in _BROWSER_CHANNELS:
            try:
                browser = p.chromium.launch(channel=channel, headless=True)
            except Exception as exc:  # noqa: BLE001 - browser channel unavailable, try next
                last_error = exc
                continue
            try:
                page = browser.new_page()
                page.set_content(html, wait_until="networkidle")
                return page.pdf(print_background=True, prefer_css_page_size=False)
            finally:
                browser.close()

    raise RuntimeError(
        f"Aucun navigateur Chromium disponible (chrome/msedge/chromium) : {last_error}"
    )


def _download_raw(src: str) -> bytes | None:
    """Fetch raw image bytes from a src attribute value; returns None on failure."""
    try:
        if src.startswith("data:image"):
            m = re.match(r'data:image/[^;]+;base64,([A-Za-z0-9+/=]+)', src)
            if m:
                return base64.b64decode(m.group(1))
        elif src.startswith("/crops/"):
            fpath = _CROPS_DIR / src[len("/crops/"):]
            if fpath.exists():
                return fpath.read_bytes()
        elif src.startswith("/assets/"):
            fpath = _ASSETS_DIR / src[len("/assets/"):]
            if fpath.exists():
                return fpath.read_bytes()
        elif src.startswith(("http://", "https://")):
            resp = requests.get(src, headers=_HTTP_HEADERS, timeout=8)
            resp.raise_for_status()
            return resp.content
    except (ValueError, OSError, requests.RequestException) as exc:
        logger.debug("Image download failed for %s: %s", src[:80], exc)
    return None


def _compress_to_jpeg(raw: bytes, max_width: int, quality: int) -> bytes:
    """Resize (down only) to max_width then encode as JPEG with 4:2:0 chroma (maximum compression)."""
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    if img.width > max_width:
        h = round(img.height * max_width / img.width)
        img = img.resize((max_width, h), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=quality, optimize=True, subsampling=2)
    return buf.getvalue()


def _image_subtype(src: str, raw: bytes) -> str:
    """MIME subtype for an untouched asset image, from its actual format."""
    try:
        fmt = Image.open(io.BytesIO(raw)).format
        if fmt:
            return "jpeg" if fmt.upper() == "JPEG" else fmt.lower()
    except OSError:
        pass
    ext = Path(src).suffix.lstrip(".").lower()
    return "jpeg" if ext == "jpg" else (ext or "png")


def _build_inline_images(
    html: str,
    pdf_size: int,
) -> tuple[str, dict[str, tuple[bytes, str]]]:
    """
    Download every image referenced in html and replace src attributes with
    MIME CID references (cid:imgNNN@nl).

    Fixed template assets (/assets/, i.e. templates/pictures/) are embedded
    as-is, untouched — they're small, static, and not subject to compression.
    Everything else (RSS/scraped article images) is resized to _MAX_IMG_WIDTH
    and re-encoded as JPEG at a fixed quality (_IMG_QUALITY) — quality is no
    longer lowered to fit _MAX_EMAIL_BYTES; the budget is only used for
    logging/estimation so oversized emails are visible, not silently degraded.

    Returns (html_with_cid_refs, {cid_name: (bytes, mime_subtype)}).
    """
    srcs = list(dict.fromkeys(re.findall(r'src="([^"]+)"', html)))

    raw_map: dict[str, bytes] = {}
    for src in srcs:
        raw = _download_raw(src)
        if raw is not None:
            raw_map[src] = raw

    if not raw_map:
        return html, {}

    asset_map = {src: raw for src, raw in raw_map.items() if src.startswith("/assets/")}
    compressible_map = {src: raw for src, raw in raw_map.items() if src not in asset_map}
    asset_total = sum(len(v) for v in asset_map.values())

    html_overhead = 35_000

    if pdf_size * _B64_OVERHEAD > _MAX_EMAIL_BYTES * 0.9:
        logger.warning(
            "PDF alone is %.0f KB — total email will likely exceed 1 MB", pdf_size / 1024
        )

    # Resize + JPEG-encode every compressible image at a fixed quality —
    # no longer lowered to squeeze under _MAX_EMAIL_BYTES.
    compressed_map: dict[str, bytes] = {
        src: _compress_to_jpeg(raw, _MAX_IMG_WIDTH, _IMG_QUALITY)
        for src, raw in compressible_map.items()
    }

    total_kb = (sum(len(v) for v in compressed_map.values()) + asset_total) / 1024
    estimated_email_kb = (
        (sum(len(v) for v in compressed_map.values()) + asset_total) * _B64_OVERHEAD
        + pdf_size * _B64_OVERHEAD
        + html_overhead
    ) / 1024
    if estimated_email_kb * 1024 > _MAX_EMAIL_BYTES:
        logger.warning(
            "Estimated email size ~%.0f KB exceeds the %.0f KB budget (quality is no longer "
            "reduced to compensate)", estimated_email_kb, _MAX_EMAIL_BYTES / 1024,
        )
    logger.info(
        "Images: %d compressed at quality=%d + %d untouched assets — %.1f KB raw, ~%.0f KB total email estimate",
        len(compressed_map), _IMG_QUALITY, len(asset_map), total_kb, estimated_email_kb,
    )

    # Assign stable CID names
    cid_map: dict[str, str] = {}
    cid_images: dict[str, tuple[bytes, str]] = {}
    for i, (src, jpeg) in enumerate(compressed_map.items()):
        cid = f"img{i:03d}@nl"
        cid_map[src] = cid
        cid_images[cid] = (jpeg, "jpeg")
    for i, (src, raw) in enumerate(asset_map.items(), start=len(compressed_map)):
        cid = f"img{i:03d}@nl"
        cid_map[src] = cid
        cid_images[cid] = (raw, _image_subtype(src, raw))

    def _replace(m: re.Match[str]) -> str:
        src = m.group(1)
        return f'src="cid:{cid_map[src]}"' if src in cid_map else m.group(0)

    return re.sub(r'src="([^"]+)"', _replace, html), cid_images


_TOP_ANCHOR = '<a name="top" id="top" style="display:block;height:0;overflow:hidden;"></a>'

_VIEW_ONLINE_BANNER = """
<table role="presentation" width="750" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" style="padding:8px 22px;font-family:'Ubuntu',Calibri,Arial,sans-serif;font-size:11px;color:#555555;background:#f2f4f6;">
      If you are having difficulty reading this email or seeing the images, please <a href="{drive_link}" target="_blank" rel="noopener" style="color:#0070AD;text-decoration:underline;">view it online</a> using Google Chrome.
    </td>
  </tr>
</table>
"""


def _add_view_online_banner(html: str, drive_link: str) -> str:
    """Insert a "view it online" banner right below the top anchor, linking to
    the PDF copy just uploaded to Google Drive. Email-only (not the live
    preview, not the PDF itself), so it's injected here rather than in the
    Jinja2 template.
    """
    banner = _VIEW_ONLINE_BANNER.format(drive_link=drive_link)
    if _TOP_ANCHOR not in html:
        return html
    return html.replace(_TOP_ANCHOR, _TOP_ANCHOR + banner, 1)


def send_newsletter(
    html_content: str,
    subject: str,
    recipients: list[str],
) -> dict:
    """
    Generate a PDF from the newsletter HTML, then send it via Gmail.
    Returns {"success": True} or {"success": False, "error": "..."}.

    MIME structure:
        multipart/mixed
        ├── multipart/alternative
        │   ├── text/plain
        │   └── multipart/related   ← HTML body + CID-embedded images
        │       ├── text/html
        │       └── image/jpeg × N
        └── application/pdf  (attachment)
    """
    gmail_user = os.getenv("GMAIL_USER")
    gmail_pass = os.getenv("GMAIL_APP_PASSWORD")

    if not gmail_user or not gmail_pass:
        return {"success": False, "error": "GMAIL_USER ou GMAIL_APP_PASSWORD non configuré"}
    if not recipients:
        return {"success": False, "error": "Aucun destinataire configuré"}

    # ── Generate PDF ────────────────────────────────────────────────
    try:
        pdf_bytes = generate_pdf(html_content)
        logger.info("PDF generated (%d bytes)", len(pdf_bytes))
    except (OSError, RuntimeError, PlaywrightError) as exc:
        logger.error("PDF generation failed: %s", exc)
        return {"success": False, "error": f"Erreur génération PDF : {exc}"}

    # ── Upload PDF to Google Drive (best-effort, does not block sending) ──
    safe_subject = "".join(c if c.isalnum() or c in " _-&#" else "_" for c in subject)
    drive_result = upload_pdf_to_drive(pdf_bytes, f"{safe_subject}.pdf")
    if drive_result["success"]:
        html_content = _add_view_online_banner(html_content, drive_result["link"])
    else:
        logger.warning("Google Drive upload skipped/failed: %s", drive_result["error"])

    # ── Inline images via CID, auto-quality ───────────────────────
    html_with_cids, cid_images = _build_inline_images(html_content, len(pdf_bytes))

    # ── Build MIME message ─────────────────────────────────────────
    related = MIMEMultipart("related", type="text/html")
    related.attach(MIMEText(html_with_cids, "html", "utf-8"))
    for cid_name, (img_bytes, subtype) in cid_images.items():
        img_part = MIMEImage(img_bytes, subtype)
        img_part.add_header("Content-ID", f"<{cid_name}>")
        img_part.add_header("Content-Disposition", "inline", filename=f"{cid_name}.{subtype}")
        related.attach(img_part)

    alt = MIMEMultipart("alternative")
    alt.attach(MIMEText(
        f"{subject}\n\nVeuillez visualiser cette newsletter dans un client mail HTML.",
        "plain", "utf-8",
    ))
    alt.attach(related)

    msg = MIMEMultipart("mixed")
    msg["Subject"] = subject
    msg["From"]    = gmail_user
    msg["To"]      = ", ".join(recipients)
    msg.attach(alt)

    pdf_part = MIMEApplication(pdf_bytes, _subtype="pdf")
    pdf_part.add_header(
        "Content-Disposition", "attachment",
        filename=f"{safe_subject}.pdf",
    )
    msg.attach(pdf_part)

    # ── Send ──────────────────────────────────────────────────────
    try:
        with smtplib.SMTP(GMAIL_SMTP_HOST, GMAIL_SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(gmail_user, gmail_pass)
            server.sendmail(gmail_user, recipients, msg.as_string())
        logger.info("Newsletter sent to: %s", ", ".join(recipients))
        return {"success": True, "recipients": recipients, "drive_upload": drive_result}
    except smtplib.SMTPAuthenticationError:
        msg_err = (
            "Authentification Gmail échouée. "
            "Utilisez un mot de passe d'application (myaccount.google.com/apppasswords)."
        )
        logger.error(msg_err)
        return {"success": False, "error": msg_err}
    except (smtplib.SMTPException, OSError) as exc:
        logger.error("Failed to send email: %s", exc)
        return {"success": False, "error": str(exc)}
