"""
Renders the newsletter HTML from fetched data.
"""

import base64
from datetime import datetime
from pathlib import Path
from typing import Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from paths import TEMPLATES_DIR, OUTPUT_DIR
_PICTURES_DIR = TEMPLATES_DIR / "pictures"


def _img_b64(filename: str) -> str:
    try:
        return "data:image/jpeg;base64," + base64.b64encode(
            (_PICTURES_DIR / filename).read_bytes()
        ).decode()
    except (OSError, ValueError):
        return ""


def render_newsletter(
    market_articles: list,
    capgemini_article: Optional[dict],
    reuters_video: Optional[dict],
    newsletter_number: int,
    newsletter_title: str = "Capgemini Innovation Watch & Upcoming Trends",
    edito: Optional[dict] = None,
    generation_date: Optional[str] = None,
) -> tuple:
    """Render the newsletter HTML, save to output/, return (path, html).

    generation_date: pre-formatted display date (e.g. "July 19, 2026").
    Defaults to today when not provided (CLI usage)."""
    OUTPUT_DIR.mkdir(exist_ok=True)

    env = Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        autoescape=select_autoescape(["html"]),
    )
    template = env.get_template("newsletter.html")

    html = template.render(
        newsletter_title=newsletter_title,
        newsletter_number=newsletter_number,
        generation_date=generation_date or datetime.now().strftime("%B %d, %Y"),
        market_articles=market_articles,
        capgemini_article=capgemini_article,
        reuters_video=reuters_video,
        edito=edito,
        header_image=_img_b64("header.jpg"),
        market_image=_img_b64("market.png"),
        capgemini_image=_img_b64("capgemini.png"),
        keep_a_look_image="/assets/keep_a_look.png",
    )

    filename = f"newsletter_{newsletter_number}_{datetime.now().strftime('%Y%m%d')}.html"
    output_path = OUTPUT_DIR / filename
    output_path.write_text(html, encoding="utf-8")
    return str(output_path), html
