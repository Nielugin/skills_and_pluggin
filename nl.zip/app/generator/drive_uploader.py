"""
Uploads the generated newsletter PDF to a Google Drive folder, authenticated
as the user's own Google account (OAuth), so uploaded files count against
the user's personal Drive quota — a service account has none of its own and
cannot create files in a regular "My Drive" folder.

Configuration (environment variables):

    GOOGLE_DRIVE_FOLDER_URL        — share URL of the target Drive folder
    GOOGLE_DRIVE_OAUTH_CLIENT_FILE — path to the OAuth "Desktop app" client
                                      secret JSON downloaded from Google
                                      Cloud Console (APIs & Services >
                                      Credentials > Create OAuth client ID)

On first use, a browser window opens for a one-time consent screen; the
resulting token (including refresh token) is cached to
credentials/google_drive_token.json so subsequent sends run unattended.
"""

import io
import logging
import os
import re
from pathlib import Path

from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload

logger = logging.getLogger(__name__)

_SCOPES = ["https://www.googleapis.com/auth/drive.file"]
_FOLDER_ID_RE = re.compile(r"/folders/([a-zA-Z0-9_-]+)|[?&]id=([a-zA-Z0-9_-]+)")
from paths import CREDENTIALS_DIR, resolve_data_path

_TOKEN_FILE = CREDENTIALS_DIR / "google_drive_token.json"


def _extract_folder_id(folder_url: str) -> str:
    m = _FOLDER_ID_RE.search(folder_url)
    if not m:
        raise ValueError(f"Impossible d'extraire l'ID de dossier depuis l'URL : {folder_url}")
    return m.group(1) or m.group(2)


def _get_credentials(client_secrets_path: str) -> Credentials:
    creds = None
    if _TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(_TOKEN_FILE), _SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except RefreshError as exc:
                # Refresh token itself is dead (revoked, or expired after 7 days
                # for an OAuth app still in "Testing" mode in Google Cloud Console)
                # — fall through to a fresh interactive consent instead of failing
                # every subsequent send the same way forever.
                logger.warning("Google Drive token refresh failed (%s) — re-running consent flow", exc)
                creds = None

        if not creds or not creds.valid:
            # One-time interactive consent — opens a browser window.
            flow = InstalledAppFlow.from_client_secrets_file(client_secrets_path, _SCOPES)
            creds = flow.run_local_server(port=0)

        _TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
        _TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")

    return creds


def upload_pdf_to_drive(pdf_bytes: bytes, filename: str) -> dict:
    """Upload pdf_bytes as filename into the configured Drive folder.

    Returns {"success": True, "file_id": ..., "link": ...} or
    {"success": False, "error": "..."}. Never raises.
    """
    folder_url = os.getenv("GOOGLE_DRIVE_FOLDER_URL", "")
    client_secrets_path = os.getenv("GOOGLE_DRIVE_OAUTH_CLIENT_FILE", "")
    if client_secrets_path:
        client_secrets_path = str(resolve_data_path(client_secrets_path))

    if not folder_url or not client_secrets_path:
        return {
            "success": False,
            "error": (
                "GOOGLE_DRIVE_FOLDER_URL ou GOOGLE_DRIVE_OAUTH_CLIENT_FILE "
                "non configuré (configuration du plugin ou .env)"
            ),
        }
    if not os.path.isfile(client_secrets_path):
        return {"success": False, "error": f"Fichier OAuth introuvable : {client_secrets_path}"}

    try:
        folder_id = _extract_folder_id(folder_url)
        creds = _get_credentials(client_secrets_path)
        service = build("drive", "v3", credentials=creds, cache_discovery=False)
        media = MediaIoBaseUpload(
            io.BytesIO(pdf_bytes), mimetype="application/pdf", resumable=False
        )
        file_metadata = {"name": filename, "parents": [folder_id]}
        uploaded = (
            service.files()
            .create(body=file_metadata, media_body=media, fields="id, webViewLink")
            .execute()
        )
        logger.info("PDF uploaded to Google Drive: %s (%s)", filename, uploaded.get("webViewLink"))
        return {"success": True, "file_id": uploaded["id"], "link": uploaded.get("webViewLink")}
    except Exception as exc:  # noqa: BLE001 - surface any Drive/auth error to the caller
        logger.error("Google Drive upload failed: %s", exc)
        return {"success": False, "error": str(exc)}
