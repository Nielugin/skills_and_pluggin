import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

import mcp_server
from web import agent, newsletter_store
from web.agent import MODIFYING_TOOLS, SKILL_MAP, TOOLS
from web.state import newsletter_state


@pytest.fixture
def editions(tmp_path, monkeypatch):
    monkeypatch.setattr(newsletter_store, "SNAPSHOTS_DIR", tmp_path)
    monkeypatch.setattr(newsletter_state, "newsletter_number", 10)
    monkeypatch.setattr(newsletter_state, "newsletter_date", "2026-10-04")
    monkeypatch.setattr(newsletter_state, "newsletter_title", "NL")
    monkeypatch.setattr(newsletter_state, "edito", {"article_title": "Courant"})
    monkeypatch.setattr(newsletter_state, "market_articles", [{"title": "a"}])
    for n, d in ((8, "2026-09-20"), (9, "2026-09-27")):
        (tmp_path / f"{n}.json").write_text(
            f'{{"newsletter_number": {n}, "newsletter_date": "{d}", "newsletter_title": "NL",'
            f' "edito": {{"article_title": "E{n}"}}, "market_articles": []}}',
            encoding="utf-8",
        )
    (tmp_path / "notes.json").write_text("{}", encoding="utf-8")
    return tmp_path


def test_get_date_current_and_known_and_unknown(editions):
    assert agent.skill_get_newsletter_date() == {"success": True, "number": 10, "date": "2026-10-04"}
    assert agent.skill_get_newsletter_date(10)["date"] == "2026-10-04"
    assert agent.skill_get_newsletter_date(9) == {"success": True, "number": 9, "date": "2026-09-27"}
    assert agent.skill_get_newsletter_date(99)["success"] is False


def test_get_date_does_not_change_current_edition(editions):
    agent.skill_get_newsletter_date(8)

    assert newsletter_state.newsletter_number == 10


def test_list_newsletters(editions):
    result = agent.skill_list_newsletters()

    assert result["count"] == 3
    assert [e["number"] for e in result["editions"]] == [10, 9, 8]
    current = result["editions"][0]
    assert current["current"] is True
    assert current["edito_title"] == "Courant"
    assert current["article_count"] == 1
    assert result["editions"][2]["date"] == "2026-09-20"


def test_list_newsletters_without_snapshots(tmp_path, monkeypatch):
    monkeypatch.setattr(newsletter_store, "SNAPSHOTS_DIR", tmp_path / "missing")
    monkeypatch.setattr(newsletter_state, "newsletter_number", 3)

    assert [e["number"] for e in agent.skill_list_newsletters()["editions"]] == [3]


def test_registration_and_mcp(monkeypatch):
    names = {t["name"] for t in TOOLS}
    assert {"get_newsletter_date", "list_newsletters"} <= names
    assert not {"get_newsletter_date", "list_newsletters"} & MODIFYING_TOOLS
    assert {"get_newsletter_date", "list_newsletters"} <= set(SKILL_MAP)

    calls = []
    monkeypatch.setattr(mcp_server, "_skill", lambda name, **kw: calls.append((name, kw)) or {})
    mcp_server.get_newsletter_date()
    mcp_server.get_newsletter_date(5)
    mcp_server.list_newsletters()
    assert calls == [
        ("get_newsletter_date", {}),
        ("get_newsletter_date", {"number": 5}),
        ("list_newsletters", {}),
    ]
