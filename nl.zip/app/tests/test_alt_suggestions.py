import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from web.agent import _build_alternative_suggestions


def test_alternative_suggestions_exclude_existing_and_duplicates():
    existing = [
        {"url": "https://a.com", "title": "Alpha"},
        {"url": "https://b.com", "title": "Beta"},
    ]
    candidates = [
        {"url": "https://a.com", "title": "Alpha"},
        {"url": "https://b.com", "title": "Beta"},
        {"url": "https://c.com", "title": "Gamma"},
        {"url": "https://d.com", "title": "Delta"},
        {"url": "https://e.com", "title": "Epsilon"},
    ]

    suggestions = _build_alternative_suggestions(existing, candidates, limit=3)

    assert [item["url"] for item in suggestions] == ["https://c.com", "https://d.com", "https://e.com"]
    assert len(suggestions) == 3
