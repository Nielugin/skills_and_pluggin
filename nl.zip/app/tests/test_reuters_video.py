import base64
import io
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest
from PIL import Image

import mcp_server
from web import agent
from web.agent import TOOLS, MODIFYING_TOOLS, SKILL_MAP
from web.state import newsletter_state

REUTERS_TOOLS = {
    "get_reuters_video", "set_reuters_video", "update_reuters_video", "remove_reuters_video",
}


@pytest.fixture(autouse=True)
def isolated(monkeypatch, tmp_path):
    """Sauvegarde la section Reuters, neutralise le rendu et redirige crops/ vers tmp."""
    original = newsletter_state.reuters_video
    monkeypatch.setattr(agent, "_render_state", lambda: None)
    import paths
    monkeypatch.setattr(paths, "CROPS_DIR", tmp_path / "crops")
    yield
    newsletter_state.reuters_video = original


def _video() -> dict:
    assert newsletter_state.reuters_video is not None
    return newsletter_state.reuters_video


def _png_data_url(width=1280, height=720) -> str:
    buf = io.BytesIO()
    Image.new("RGB", (width, height), (10, 80, 160)).save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def test_tools_are_registered_everywhere():
    names = {t["name"] for t in TOOLS}
    assert REUTERS_TOOLS <= names
    assert REUTERS_TOOLS <= set(SKILL_MAP)
    assert {"set_reuters_video", "update_reuters_video", "remove_reuters_video"} <= MODIFYING_TOOLS
    assert "get_reuters_video" not in MODIFYING_TOOLS


def test_set_reuters_video_with_screenshot_is_downscaled(tmp_path):
    result = agent.skill_set_reuters_video(
        title="  Quantum leap  ",
        video_url="https://www.reuters.com/video/watch/abc/",
        description="d" * 400,
        thumbnail_data_url=_png_data_url(),
    )

    assert result["success"] is True and result["has_thumbnail"] is True
    video = _video()
    assert video["title"] == "Quantum leap"
    assert len(video["description"]) == 300
    assert video["video_url"] == "https://www.reuters.com/video/watch/abc/"
    assert video["thumbnail_url"].startswith("/crops/reuters_")
    saved = tmp_path / "crops" / Path(video["thumbnail_url"]).name
    assert Image.open(saved).size == (706, 397)


def test_set_reuters_video_with_thumbnail_url_only():
    result = agent.skill_set_reuters_video(
        title="T", video_url="https://example.com/v", thumbnail_url="https://img.example.com/p.jpg"
    )
    assert result["success"] is True
    assert _video()["thumbnail_url"] == "https://img.example.com/p.jpg"


@pytest.mark.parametrize("kwargs", [
    {"title": "", "video_url": "https://example.com/v"},
    {"title": "T", "video_url": "javascript:alert(1)"},
    {"title": "T", "video_url": "https://example.com/v", "thumbnail_url": "ftp://x/y.jpg"},
    {"title": "T", "video_url": "https://example.com/v", "thumbnail_data_url": "data:text/html;base64,AAAA"},
    {"title": "T", "video_url": "https://example.com/v", "thumbnail_data_url": "data:image/png;base64,AAAA"},
])
def test_set_reuters_video_rejects_invalid_input(kwargs):
    newsletter_state.reuters_video = None
    result = agent.skill_set_reuters_video(**kwargs)
    assert result["success"] is False and result["error"]
    assert newsletter_state.reuters_video is None


def test_get_reuters_video():
    newsletter_state.reuters_video = None
    assert agent.skill_get_reuters_video()["success"] is False

    agent.skill_set_reuters_video(title="T", video_url="https://example.com/v", description="D")
    result = agent.skill_get_reuters_video()
    assert result["success"] is True
    assert (result["title"], result["video_url"], result["description"]) == ("T", "https://example.com/v", "D")


def test_update_reuters_video_changes_only_given_fields():
    agent.skill_set_reuters_video(
        title="Old", video_url="https://example.com/v", description="Keep me",
        thumbnail_url="https://img.example.com/p.jpg",
    )

    result = agent.skill_update_reuters_video(title="New")

    assert result["success"] is True
    video = _video()
    assert video["title"] == "New"
    assert video["description"] == "Keep me"
    assert video["video_url"] == "https://example.com/v"
    assert video["thumbnail_url"] == "https://img.example.com/p.jpg"


def test_update_reuters_video_replaces_image_with_screenshot():
    agent.skill_set_reuters_video(title="T", video_url="https://example.com/v")

    result = agent.skill_update_reuters_video(thumbnail_data_url=_png_data_url(800, 450))

    assert result["success"] is True
    assert _video()["thumbnail_url"].startswith("/crops/reuters_")


def test_update_reuters_video_errors():
    newsletter_state.reuters_video = None
    assert agent.skill_update_reuters_video(title="x")["success"] is False

    agent.skill_set_reuters_video(title="T", video_url="https://example.com/v")
    assert agent.skill_update_reuters_video()["success"] is False  # rien à modifier
    assert agent.skill_update_reuters_video(title="  ")["success"] is False
    assert agent.skill_update_reuters_video(video_url="not a url")["success"] is False
    assert _video()["title"] == "T"


def test_remove_reuters_video():
    agent.skill_set_reuters_video(title="T", video_url="https://example.com/v")

    assert agent.skill_remove_reuters_video() == {"success": True, "removed": "T"}
    assert newsletter_state.reuters_video is None
    assert agent.skill_remove_reuters_video()["success"] is False


def test_mcp_set_reuters_video_sends_local_screenshot_as_data_url(monkeypatch, tmp_path):
    shot = tmp_path / "shot.png"
    shot.write_bytes(base64.b64decode(_png_data_url(40, 30).split(",", 1)[1]))
    calls = []
    monkeypatch.setattr(mcp_server, "_skill", lambda name, **a: calls.append((name, a)) or {"success": True})

    result = mcp_server.set_reuters_video(
        title="T", video_url="https://example.com/v", thumbnail_path=str(shot)
    )

    assert result == {"success": True}
    name, args = calls[0]
    assert name == "set_reuters_video"
    assert args["thumbnail_data_url"].startswith("data:image/png;base64,")
    assert args["thumbnail_url"] is None


def test_mcp_rejects_missing_screenshot(monkeypatch, tmp_path):
    monkeypatch.setattr(mcp_server, "_skill", lambda *a, **k: pytest.fail("ne doit pas appeler le backend"))

    result = mcp_server.update_reuters_video(thumbnail_path=str(tmp_path / "absent.png"))

    assert result["success"] is False and "introuvable" in result["error"]
