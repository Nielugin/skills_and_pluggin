import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

import mcp_server
from web import agent
from web.agent import TOOLS, MODIFYING_TOOLS, skill_get_edito
from web.state import newsletter_state


@pytest.fixture(autouse=True)
def restore_edito():
    original = newsletter_state.edito
    yield
    newsletter_state.edito = original


def _edito(content):
    return {
        "article_title": "Titre",
        "content": content,
        "author_name": "Patrice",
        "author_title": "CEO",
        "author_roles": ["A", "B"],
        "author_photo_url": "data:image/png;base64,AAAA",
    }


def test_get_edito_without_edito():
    newsletter_state.edito = None
    result = skill_get_edito()

    assert result["success"] is False
    assert "error" in result


def test_get_edito_valid_signature():
    newsletter_state.edito = _edito("<p>Hi</p><p>Sincerely yours<br>Patrice</p>")
    result = skill_get_edito()

    assert result["success"] is True
    assert result["article_title"] == "Titre"
    assert result["author_name"] == "Patrice"
    assert result["author_roles"] == ["A", "B"]
    assert result["closing_valid"] is True
    assert result["closing_error"] is None


def test_get_edito_invalid_signature():
    newsletter_state.edito = _edito("<p>Hi</p>")
    result = skill_get_edito()

    assert result["success"] is True
    assert result["closing_valid"] is False
    assert result["closing_error"]


def test_get_edito_does_not_leak_photo():
    newsletter_state.edito = _edito("<p>Sincerely yours<br>Patrice</p>")

    assert "author_photo_url" not in skill_get_edito()


def test_get_edito_registered_as_read_only_tool():
    assert any(t["name"] == "get_edito" for t in TOOLS)
    assert "get_edito" not in MODIFYING_TOOLS


def test_get_edito_mcp_tool_calls_skill(monkeypatch):
    calls = []
    monkeypatch.setattr(mcp_server, "_skill", lambda name, **kw: calls.append((name, kw)) or {"ok": True})

    assert mcp_server.get_edito() == {"ok": True}
    assert calls == [("get_edito", {})]
