import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

import mcp_server
from web import agent
from web.agent import MODIFYING_TOOLS, SKILL_MAP, TOOLS
from web.state import newsletter_state


@pytest.fixture(autouse=True)
def restore_title(monkeypatch):
    original = newsletter_state.newsletter_title
    monkeypatch.setattr(agent, "_render_state", lambda *a, **k: None)
    yield
    newsletter_state.newsletter_title = original


def test_get_title():
    newsletter_state.newsletter_title = "Mon titre"

    assert agent.skill_get_newsletter_title() == {"success": True, "title": "Mon titre"}


def test_set_title_strips_and_updates_state():
    result = agent.skill_set_newsletter_title("  Nouveau titre  ")

    assert result == {"success": True, "title": "Nouveau titre"}
    assert newsletter_state.newsletter_title == "Nouveau titre"


@pytest.mark.parametrize("value", ["", "   ", None])
def test_set_title_rejects_empty(value):
    newsletter_state.newsletter_title = "Inchangé"
    result = agent.skill_set_newsletter_title(value)

    assert result["success"] is False
    assert newsletter_state.newsletter_title == "Inchangé"


def test_title_skills_registered():
    names = {t["name"] for t in TOOLS}
    assert {"get_newsletter_title", "set_newsletter_title"} <= names
    assert "set_newsletter_title" in MODIFYING_TOOLS
    assert "get_newsletter_title" not in MODIFYING_TOOLS
    assert SKILL_MAP["set_newsletter_title"]({"title": "X"})["title"] == "X"


def test_title_mcp_tools(monkeypatch):
    calls = []
    monkeypatch.setattr(mcp_server, "_skill", lambda name, **kw: calls.append((name, kw)) or {"ok": True})

    mcp_server.get_newsletter_title()
    mcp_server.set_newsletter_title("T")

    assert calls == [("get_newsletter_title", {}), ("set_newsletter_title", {"title": "T"})]
