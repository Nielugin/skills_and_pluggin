import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from web.agent import (
    _validate_edito_closing,
    skill_send_newsletter,
)
from web.state import newsletter_state


def test_edito_closing_requires_one_final_two_line_signature():
    assert _validate_edito_closing(
        {
            "content": (
                "<p>Introduction.</p>"
                "<p><b>Sincerely yours</b><br><b>Patrice</b></p>"
            )
        }
    ) is None


def test_edito_closing_rejects_missing_signature():
    error = _validate_edito_closing({"content": "<p>Introduction only.</p>"})

    assert error is not None
    assert "une seule fois" in error


def test_edito_closing_rejects_duplicate_signature():
    error = _validate_edito_closing(
        {
            "content": (
                "<p>Sincerely yours<br>Patrice</p>"
                "<p>Sincerely yours<br>Patrice</p>"
            )
        }
    )

    assert error is not None
    assert "une seule fois" in error


def test_edito_closing_rejects_signature_not_on_separate_lines():
    error = _validate_edito_closing(
        {"content": "<p>Introduction. Sincerely yours Patrice</p>"}
    )

    assert error is not None
    assert "deux lignes distinctes" in error


def test_edito_closing_rejects_wrong_name_or_trailing_content():
    wrong_name = _validate_edito_closing(
        {"content": "<p>Introduction.</p><p>Sincerely yours<br>Jean</p>"}
    )
    trailing_text = _validate_edito_closing(
        {
            "content": (
                "<p>Introduction.</p>"
                "<p>Sincerely yours<br>Patrice<br>Postscript</p>"
            )
        }
    )

    assert wrong_name is not None
    assert "deux lignes distinctes" in wrong_name
    assert trailing_text is not None
    assert "deux lignes distinctes" in trailing_text


def test_edito_must_be_present_before_sending():
    assert _validate_edito_closing(None) == "Envoi bloqué : l'édito est absent."


def test_send_is_blocked_when_signature_is_invalid(monkeypatch):
    monkeypatch.setattr(
        newsletter_state, "edito", {"content": "<p>Missing signature.</p>"}
    )

    result = skill_send_newsletter()

    assert result["success"] is False
    assert "Sincerely yours" in result["error"]


def test_email_subject_includes_edito_title(monkeypatch):
    import generator.emailer as emailer
    from web import agent

    sent = {}
    monkeypatch.setattr(
        emailer, "send_newsletter",
        lambda html, subject, recipients: sent.update(subject=subject) or {"success": True},
    )
    monkeypatch.setattr(newsletter_state, "recipients", ["a@b.c"])
    monkeypatch.setattr(newsletter_state, "preview_html", "<html></html>")
    monkeypatch.setattr(newsletter_state, "newsletter_title", "NL")
    monkeypatch.setattr(newsletter_state, "newsletter_number", 7)
    monkeypatch.setattr(
        newsletter_state, "edito",
        {"article_title": "Mon titre", "content": "<p>x</p><p>Sincerely yours<br>Patrice</p>"},
    )

    assert agent.skill_send_newsletter()["success"] is True
    assert sent["subject"] == "NL #7 - Mon titre"

    newsletter_state.edito["article_title"] = ""
    assert agent._build_email_subject() == "NL #7"


def test_signature_line_break_is_preserved_in_preview_and_email_html(
    tmp_path, monkeypatch
):
    from generator import html_gen
    from generator.emailer import _add_view_online_banner, _strip_back_to_top_links

    monkeypatch.setattr(html_gen, "OUTPUT_DIR", tmp_path)
    _, preview = html_gen.render_newsletter(
        [],
        None,
        None,
        1,
        edito={
            "author_name": "Patrice",
            "author_title": "",
            "author_roles": [],
            "author_photo_url": "",
            "article_title": "Test",
            "content": "<p>Body.</p><p>Sincerely yours<br>Patrice</p>",
        },
    )
    signature = "Sincerely yours<br>Patrice"

    assert signature in preview
    assert signature in _add_view_online_banner(
        preview, "https://example.test/newsletter.pdf"
    )
    assert signature in _strip_back_to_top_links(preview)
