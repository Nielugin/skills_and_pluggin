/**
 * WhatsApp bridge — Baileys (WhatsApp Web multi-device protocol).
 * Exposes a local HTTP API used by the Python newsletter server.
 *
 * Endpoints:
 *   GET  /status          → { status: "qr" | "connecting" | "open" | "closed" }
 *   GET  /qr              → { qr: "<data-url-png>" }  (only when status === "qr")
 *   POST /send            → { to: "33612345678", text: "..." }
 *   POST /logout          → disconnect and delete session
 */

const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
} = require('@whiskeysockets/baileys');
const QRCode    = require('qrcode');
const express   = require('express');
const axios     = require('axios');
const pino      = require('pino');
const path      = require('path');
const fs        = require('fs');
const puppeteer = require('puppeteer-core');

// Known Edge / Chrome install paths (Windows, macOS, Linux); BROWSER_PATH overrides
const BROWSER_PATHS = [
  process.env.BROWSER_PATH,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/usr/bin/microsoft-edge',
].filter(Boolean);

function findBrowser() {
  return BROWSER_PATHS.find(p => fs.existsSync(p)) || null;
}

// ── Config ────────────────────────────────────────────────────────────────────
const PORT         = parseInt(process.env.WA_SERVICE_PORT  || '3001', 10);
const PYTHON_URL   = process.env.PYTHON_INTERNAL_URL       || 'http://127.0.0.1:8000';
// Session WhatsApp hors du code (dossier de données du plugin), cf. scripts/nl.py
const AUTH_DIR     = process.env.WA_AUTH_DIR || path.join(__dirname, 'auth_info');
const logger = pino({
  level: 'fatal',  // only show fatal errors — transient timeouts are handled by reconnect logic
});

// ── State ─────────────────────────────────────────────────────────────────────
let sock        = null;
let qrDataUrl   = null;
let connStatus  = 'closed';   // qr | connecting | open | closed
const msgCache  = new Map();  // jid → Map(id → message) — for pkmsg decryption
const _fwdSeen  = new Set();  // message IDs already forwarded — deduplication

// ── Conversation name resolver ────────────────────────────────────────────────
async function resolveConversationName(jid) {
  if (!jid) return 'inconnu';
  if (jid.endsWith('@g.us')) {
    try {
      const meta = await sock.groupMetadata(jid);
      return meta.subject || jid.split('@')[0];
    } catch {
      return jid.split('@')[0];
    }
  }
  if (jid.endsWith('@lid')) return 'self (lid)';
  // Contact — Baileys populates sock.contacts after initial sync
  const contact = sock?.contacts?.[jid];
  return contact?.name || contact?.notify || jid.replace('@s.whatsapp.net', '');
}

// ── Baileys connection ────────────────────────────────────────────────────────
async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const { version }          = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, logger),
    },
    logger,
    browser:                Browsers.windows('Newsletter Agent'),
    printQRInTerminal:      false,
    markOnlineOnConnect:    false,
    connectTimeoutMs:       60_000,
    defaultQueryTimeoutMs:  60_000,
    keepAliveIntervalMs:    25_000,
    getMessage: async (key) => {
      return msgCache.get(key.remoteJid)?.get(key.id) || { conversation: '' };
    },
  });

  // Credentials updated
  sock.ev.on('creds.update', saveCreds);

  // Connection state
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      qrDataUrl  = await QRCode.toDataURL(qr);
      connStatus = 'qr';
      console.log('[WA] QR code ready — scan with WhatsApp');
    }

    if (connection === 'connecting') {
      connStatus = 'connecting';
    }

    if (connection === 'open') {
      qrDataUrl  = null;
      connStatus = 'open';
      console.log('[WA] Connected');
    }

    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      connStatus = 'closed';
      if (code === DisconnectReason.loggedOut) {
        console.log('[WA] Logged out — clearing session, new QR in 3 s…');
        if (fs.existsSync(AUTH_DIR)) fs.rmSync(AUTH_DIR, { recursive: true, force: true });
        setTimeout(connect, 3000);
      } else if (code === DisconnectReason.restartRequired) {
        // Normal WhatsApp-initiated rotation — reconnect immediately, no log noise
        setTimeout(connect, 500);
      } else if (code === DisconnectReason.connectionLost || code === 408) {
        // Init-query timeout or connection lost — retry quickly, it's transient
        setTimeout(connect, 2000);
      } else {
        console.log(`[WA] Disconnected (${code}) — reconnecting in 5 s…`);
        setTimeout(connect, 5000);
      }
    }
  });

  // Incoming messages
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    // Feed cache for pkmsg decryption (keep last 50 messages per jid)
    for (const msg of messages) {
      const jid = msg.key.remoteJid;
      if (jid && msg.message) {
        if (!msgCache.has(jid)) msgCache.set(jid, new Map());
        const jidCache = msgCache.get(jid);
        jidCache.set(msg.key.id, msg.message);
        if (jidCache.size > 50) jidCache.delete(jidCache.keys().next().value);
      }
    }

    if (type !== 'notify') return;

    for (const msg of messages) {
      const jid       = msg.key.remoteJid || '';
      const ownNumber = (sock.user?.id || '').split(':')[0].split('@')[0];
      const isGroup   = jid.endsWith('@g.us');
      const senderJid = isGroup ? (msg.key.participant || '') : jid;
      const senderNum = senderJid.replace('@s.whatsapp.net', '').replace('@lid', '');
      const pushName  = msg.pushName || '';
      const msgType   = Object.keys(msg.message || {}).filter(k => k !== 'messageContextInfo')[0] || 'unknown';
      const text      =
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        '';
      const ts        = new Date((msg.messageTimestamp || 0) * 1000).toISOString();
      const from      = jid.endsWith('@lid')
        ? ownNumber
        : jid.replace('@s.whatsapp.net', '').replace('@g.us', '');

      // Determine filter reason for logging (does not alter routing logic below)
      let filterReason = null;
      if (jid.endsWith('@lid') && !msg.key.fromMe)                   filterReason = '@lid sync (not fromMe)';
      else if (jid.endsWith('@broadcast'))                            filterReason = 'broadcast';
      else if (msg.key.fromMe && jid.split('@')[0] !== ownNumber)    filterReason = 'outgoing to others';
      else if (!text.trim())                                          filterReason = `no text (${msgType})`;
      else if (msg.key.id && _fwdSeen.has(msg.key.id))               filterReason = 'duplicate';

      const convName = filterReason ? jid : await resolveConversationName(jid);

      console.log([
        '[WA] ──────────────────────────────────',
        `  filtré       : ${filterReason ? `OUI — ${filterReason}` : 'NON (transmis à l\'agent)'}`,
        `  jid          : ${jid}`,
        `  conv_type    : ${isGroup ? 'groupe' : jid.endsWith('@lid') ? 'lid/self' : '1-to-1'}`,
        `  conv_name    : ${convName}`,
        `  from         : ${from}`,
        `  fromMe       : ${msg.key.fromMe}`,
        `  sender_jid   : ${senderJid}`,
        `  sender_num   : ${senderNum}`,
        `  push_name    : ${pushName}`,
        `  msg_type     : ${msgType}`,
        `  msg_id       : ${msg.key.id}`,
        `  timestamp    : ${ts}`,
        `  text         : ${text.slice(0, 120) || '(vide)'}`,
        '[WA] ──────────────────────────────────',
      ].join('\n'));

      // ── Original routing logic (unchanged) ───────────────────
      if (jid.endsWith('@lid')) {
        if (!msg.key.fromMe) continue;
      } else if (jid.endsWith('@broadcast')) {
        continue;
      } else if (msg.key.fromMe) {
        const jidNumber = jid.split('@')[0];
        if (jidNumber !== ownNumber) continue;
      }

      if (!text.trim()) continue;

      // Deduplicate — Baileys can fire the same message twice on multi-device
      const msgId = msg.key.id || '';
      if (msgId && _fwdSeen.has(msgId)) continue;
      if (msgId) {
        _fwdSeen.add(msgId);
        setTimeout(() => _fwdSeen.delete(msgId), 60_000);
      }

      // Forward to Python newsletter server
      try {
        await axios.post(`${PYTHON_URL}/webhook/whatsapp-internal`, { from, text, conv_name: convName }, { timeout: 5000 });
      } catch (err) {
        console.error('[WA] Forward to Python failed:', err.message);
      }
    }
  });
}

// ── HTTP API ──────────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '20mb' }));

app.get('/status', (_req, res) => {
  res.json({ status: connStatus });
});

app.get('/qr', (_req, res) => {
  res.json({ qr: qrDataUrl, status: connStatus });
});

app.post('/send', async (req, res) => {
  const { to, text } = req.body;
  if (!sock || connStatus !== 'open') {
    return res.status(503).json({ ok: false, error: 'Not connected' });
  }
  if (!to || !text) {
    return res.status(400).json({ ok: false, error: 'Missing to or text' });
  }
  try {
    const jid = to.includes('@') ? to : `${to}@s.whatsapp.net`;
    await Promise.race([
      sock.sendMessage(jid, { text: text.slice(0, 4096) }),
      new Promise((_, reject) => setTimeout(() => reject(new Error('sendMessage timed out')), 15_000)),
    ]);
    res.json({ ok: true });
  } catch (err) {
    // If send timed out, the connection is probably stale — force reconnect
    if (err.message === 'sendMessage timed out') {
      console.log('[WA] sendMessage timed out — forcing reconnect…');
      connStatus = 'closed';
      try { sock.end(new Error('stale connection')); } catch {}
    }
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /screenshot  { url: "http://127.0.0.1:8000/preview", width?: 750 }
 * Renders the given URL with a headless browser and returns a JPEG screenshot
 * of the full page as { ok: true, image: "<base64>" }.
 */
app.post('/screenshot', async (req, res) => {
  const { url, width = 750 } = req.body;
  if (!url) return res.status(400).json({ ok: false, error: 'Missing url' });

  const execPath = findBrowser();
  if (!execPath) {
    return res.status(500).json({ ok: false, error: 'No Edge/Chrome installation found' });
  }

  let browser = null;
  try {
    browser = await puppeteer.launch({
      executablePath: execPath,
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--hide-scrollbars',
      ],
    });
    const page = await browser.newPage();
    await page.setViewport({ width: Number(width), height: 900, deviceScaleFactor: 1 });
    // networkidle2 = no more than 2 network connections for 500ms (tolerates CDN fonts)
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30_000 });
    const buf = await page.screenshot({ fullPage: true, type: 'jpeg', quality: 85 });
    await browser.close();
    browser = null;

    console.log(`[Screenshot] ${url} → ${Math.round(buf.length / 1024)} KB JPEG`);
    res.json({ ok: true, image: buf.toString('base64') });
  } catch (err) {
    console.error('[Screenshot] Error:', err.message);
    if (browser) await browser.close().catch(() => {});
    res.status(500).json({ ok: false, error: err.message });
  }
});


/**
 * POST /send-image  { to: "336...", image: "<base64-jpeg>", caption?: "..." }
 * Sends a WhatsApp image message via the active Baileys session.
 */
app.post('/send-image', async (req, res) => {
  const { to, image, caption = '' } = req.body;
  if (!sock || connStatus !== 'open') {
    return res.status(503).json({ ok: false, error: 'Not connected' });
  }
  if (!to || !image) {
    return res.status(400).json({ ok: false, error: 'Missing to or image' });
  }
  try {
    const jid    = to.includes('@') ? to : `${to}@s.whatsapp.net`;
    const imgBuf = Buffer.from(image, 'base64');
    await Promise.race([
      sock.sendMessage(jid, { image: imgBuf, caption: caption.slice(0, 1024) }),
      new Promise((_, reject) => setTimeout(() => reject(new Error('sendImage timed out')), 30_000)),
    ]);
    res.json({ ok: true });
  } catch (err) {
    console.error('[WA] send-image error:', err.message);
    res.status(500).json({ ok: false, error: err.message });
  }
});


app.post('/logout', async (_req, res) => {
  try {
    if (sock) {
      await sock.logout();  // triggers loggedOut → connection.update handles reconnect + QR
    } else {
      // No active socket — clear manually and reconnect
      if (fs.existsSync(AUTH_DIR)) fs.rmSync(AUTH_DIR, { recursive: true, force: true });
      setTimeout(connect, 1000);
    }
    connStatus = 'closed';
    res.json({ ok: true });
  } catch (err) {
    // logout() failed — force clear and reconnect
    if (fs.existsSync(AUTH_DIR)) fs.rmSync(AUTH_DIR, { recursive: true, force: true });
    connStatus = 'closed';
    setTimeout(connect, 1000);
    res.json({ ok: true });  // still OK — session is gone
  }
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`[WA] Service listening on http://127.0.0.1:${PORT}`);
  connect();
});
