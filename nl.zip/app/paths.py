"""
Emplacements du code et des données de la NL.

Le code (ce dossier) est en lecture seule : dans un plugin Claude Code il est
remplacé à chaque mise à jour. Tout ce qui est écrit à l'exécution (.env,
sorties, jetons, compteur, session WhatsApp) va dans DATA_DIR :

  1. NEWSLETTER_DATA_DIR si défini,
  2. sinon CLAUDE_PLUGIN_DATA (fourni par Claude Code au plugin),
  3. sinon ce dossier (usage hors plugin, en développement).

La configuration est lue dans DATA_DIR/plugin-config.env (généré depuis la
configuration du plugin, valeurs non vides uniquement) puis DATA_DIR/.env
(réglages complémentaires saisis à la main). Les variables d'environnement
réelles priment toujours, puis plugin-config.env, puis .env.
"""
import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(
    os.getenv("NEWSLETTER_DATA_DIR") or os.getenv("CLAUDE_PLUGIN_DATA") or APP_DIR
).expanduser().resolve()

TEMPLATES_DIR = APP_DIR / "templates"
PICTURES_DIR = TEMPLATES_DIR / "pictures"

OUTPUT_DIR = DATA_DIR / "output"
CROPS_DIR = OUTPUT_DIR / "crops"
SNAPSHOTS_DIR = OUTPUT_DIR / "newsletters"
LOG_DIR = OUTPUT_DIR / "logs"
CREDENTIALS_DIR = DATA_DIR / "credentials"
COUNTER_FILE = DATA_DIR / ".newsletter_counter"
WHATSAPP_FILTER_FILE = DATA_DIR / ".whatsapp_filter.json"
ENV_FILE = DATA_DIR / ".env"
PLUGIN_ENV_FILE = DATA_DIR / "plugin-config.env"


def load_env() -> None:
    """Charge plugin-config.env puis .env sans écraser l'environnement existant."""
    from dotenv import load_dotenv
    load_dotenv(PLUGIN_ENV_FILE)
    load_dotenv(ENV_FILE)


def resolve_data_path(value: str) -> Path:
    """Chemin saisi par l'utilisateur : absolu tel quel, relatif → sous DATA_DIR."""
    p = Path(value).expanduser()
    return p if p.is_absolute() else DATA_DIR / p
