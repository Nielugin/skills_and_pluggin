"""
Fetches the latest Reuters video from their YouTube channel.

Primary: scrape https://www.youtube.com/@Reuters/videos (no API key needed)
         by extracting the ytInitialData JSON blob embedded in the page.
Fallback: YouTube Data API v3 (requires YOUTUBE_API_KEY env var).
"""

import json
import logging
import os
import re
from typing import Optional

import requests

from config import SSL_VERIFY

logger = logging.getLogger(__name__)

REUTERS_CHANNEL_URL = "https://www.youtube.com/@Reuters/videos"
YOUTUBE_API_URL     = "https://www.googleapis.com/youtube/v3/search"
YOUTUBE_CHANNEL_ID  = "UCGYXTBFeMBYhLRRnxazdIbw"

_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}


def get_latest_reuters_video() -> Optional[dict]:
    """
    Return a dict with title, video_id, video_url, thumbnail_url,
    description, published_at, channel — or None on total failure.
    """
    video = _scrape_channel_page()
    if video:
        return video

    logger.warning("Channel page scrape failed, trying YouTube Data API")
    return _youtube_api_fallback()


# ── Primary: scrape ytInitialData ──────────────────────────

def _scrape_channel_page() -> Optional[dict]:
    # Pass consent cookie so YouTube doesn't redirect to the GDPR consent page
    cookies = {"CONSENT": "YES+cb.20210615-14-p0.en+FX+946", "SOCS": "CAI"}
    try:
        resp = requests.get(
            REUTERS_CHANNEL_URL,
            headers=_HEADERS,
            cookies=cookies,
            verify=SSL_VERIFY,
            timeout=15,
        )
        resp.raise_for_status()
    except (requests.RequestException, OSError) as exc:
        logger.warning("Failed to fetch Reuters channel page: %s", exc)
        return None

    # YouTube embeds a large JSON blob: var ytInitialData = {...};
    match = re.search(r"var ytInitialData\s*=\s*(\{.*?\});\s*</script>", resp.text, re.DOTALL)
    if not match:
        # Try alternate pattern (no semicolon / different closing)
        match = re.search(r"ytInitialData\s*=\s*(\{.*?\})\s*;", resp.text, re.DOTALL)
    if not match:
        logger.warning("ytInitialData not found in Reuters channel page")
        return None

    try:
        data = json.loads(match.group(1))
    except json.JSONDecodeError as exc:
        logger.warning("Failed to parse ytInitialData: %s", exc)
        return None

    return _extract_first_video(data)


def _find_recursive(obj, key):
    """Yield every value mapped to `key` anywhere in a nested dict/list."""
    if isinstance(obj, dict):
        if key in obj:
            yield obj[key]
        for v in obj.values():
            yield from _find_recursive(v, key)
    elif isinstance(obj, list):
        for item in obj:
            yield from _find_recursive(item, key)


def _video_from_lockup(lvm: dict) -> Optional[dict]:
    """Parse a lockupViewModel (modern YouTube layout) into a video dict."""
    video_id = None
    for src in _find_recursive(lvm.get("contentImage", {}), "sources"):
        if isinstance(src, list) and src:
            m = re.search(r"/vi/([A-Za-z0-9_-]{11})/", src[0].get("url", ""))
            if m:
                video_id = m.group(1)
                break
    if not video_id:
        for act_id in _find_recursive(lvm, "animationActivationTargetId"):
            if act_id and len(act_id) == 11:
                video_id = act_id
                break
    if not video_id:
        return None

    title = (
        lvm.get("metadata", {})
           .get("lockupMetadataViewModel", {})
           .get("title", {})
           .get("content", "Latest Reuters Video")
    )

    thumb_sources = list(_find_recursive(lvm.get("contentImage", {}), "sources"))
    if thumb_sources and isinstance(thumb_sources[0], list) and thumb_sources[0]:
        raw_url = thumb_sources[0][-1].get("url", "")
        thumbnail_url = re.sub(r"\?.*", "", raw_url) or raw_url
    else:
        thumbnail_url = f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg"

    published_text = next(
        (
            part.get("text", {}).get("content", "")
            for row in _find_recursive(lvm.get("metadata", {}), "metadataParts")
            if isinstance(row, list)
            for part in row
            if part.get("text", {}).get("content")
        ),
        "",
    )

    return {
        "title":         title,
        "video_id":      video_id,
        "video_url":     f"https://www.youtube.com/watch?v={video_id}",
        "thumbnail_url": thumbnail_url,
        "description":   "",
        "published_at":  published_text,
        "channel":       "Reuters",
    }


def _video_from_renderer(vr: dict) -> Optional[dict]:
    """Parse a legacy videoRenderer into a video dict."""
    video_id = vr.get("videoId")
    if not video_id:
        return None
    title = (
        vr.get("title", {}).get("runs", [{}])[0].get("text")
        or vr.get("title", {}).get("simpleText")
        or "Latest Reuters Video"
    )
    thumbs = vr.get("thumbnail", {}).get("thumbnails", [])
    thumbnail_url = (
        thumbs[-1]["url"] if thumbs
        else f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg"
    )
    desc = vr.get("descriptionSnippet", {}).get("runs", [{}])[0].get("text", "")
    return {
        "title":         title,
        "video_id":      video_id,
        "video_url":     f"https://www.youtube.com/watch?v={video_id}",
        "thumbnail_url": thumbnail_url,
        "description":   desc[:300],
        "published_at":  vr.get("publishedTimeText", {}).get("simpleText", ""),
        "channel":       "Reuters",
    }


def _extract_first_video(data: dict) -> Optional[dict]:
    """Walk ytInitialData for the first video (modern or legacy layout)."""
    for lvm in _find_recursive(data, "lockupViewModel"):
        video = _video_from_lockup(lvm)
        if video:
            logger.info("Reuters video (lockupViewModel): %s (%s)", video["title"], video["video_id"])
            return video

    for vr in _find_recursive(data, "videoRenderer"):
        video = _video_from_renderer(vr)
        if video:
            logger.info("Reuters video (videoRenderer): %s (%s)", video["title"], video["video_id"])
            return video

    logger.warning("No video renderer found in ytInitialData")
    return None


# ── Fallback: YouTube Data API ───────────────────────────────────

def _youtube_api_fallback() -> Optional[dict]:
    api_key = os.getenv("YOUTUBE_API_KEY")
    if not api_key:
        logger.error("YOUTUBE_API_KEY not set — cannot use YouTube Data API")
        return None

    try:
        resp = requests.get(
            YOUTUBE_API_URL,
            verify=SSL_VERIFY,
            params={
                "part":      "snippet",
                "channelId": YOUTUBE_CHANNEL_ID,
                "maxResults": 1,
                "order":     "date",
                "type":      "video",
                "key":       api_key,
            },
            timeout=10,
        )
        resp.raise_for_status()
        items = resp.json().get("items", [])
        if not items:
            return None

        item    = items[0]
        vid_id  = item["id"]["videoId"]
        snippet = item["snippet"]
        thumbs  = snippet.get("thumbnails", {})
        thumb   = (
            thumbs.get("high", {}).get("url")
            or thumbs.get("medium", {}).get("url")
            or thumbs.get("default", {}).get("url")
            or f"https://img.youtube.com/vi/{vid_id}/hqdefault.jpg"
        )
        return {
            "title":         snippet.get("title", "Latest Reuters Video"),
            "video_id":      vid_id,
            "video_url":     f"https://www.youtube.com/watch?v={vid_id}",
            "thumbnail_url": thumb,
            "description":   snippet.get("description", "")[:300],
            "published_at":  snippet.get("publishedAt", ""),
            "channel":       "Reuters",
        }
    except (requests.RequestException, OSError, KeyError, ValueError) as exc:
        logger.warning("YouTube Data API failed: %s", exc)
        return None
