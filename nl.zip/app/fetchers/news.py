"""
Fetches and ranks news articles from RSS feeds.
"""

import hashlib
import io
import logging
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

import feedparser
import requests
from bs4 import BeautifulSoup
from PIL import Image

from config import RSS_FEEDS, TOPIC_KEYWORDS, MARKET_NEWS_COUNT, SSL_VERIFY

from paths import CROPS_DIR as _CROPS_DIR

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
}


def _get(url: str, timeout: int = 8) -> Optional[requests.Response]:
    """Wrapper around requests.get that respects SSL_VERIFY."""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=timeout, verify=SSL_VERIFY)
        resp.raise_for_status()
        return resp
    except Exception as exc:
        logger.debug("HTTP GET failed for %s: %s", url, exc)
    return None


def fetch_og_image(url: str, timeout: int = 8) -> Optional[str]:
    """Return the og:image URL from an article page, or None."""
    resp = _get(url, timeout)
    if not resp:
        return None
    try:
        soup = BeautifulSoup(resp.text, "html.parser")
        for prop in ("og:image", "twitter:image"):
            tag = soup.find("meta", property=prop) or soup.find("meta", attrs={"name": prop})
            if tag and isinstance(tag.get("content"), str):
                return tag["content"]  # type: ignore[index]
    except Exception as exc:
        logger.debug("Could not parse og:image from %s: %s", url, exc)
    return None


def score_article(title: str, description: str) -> tuple[int, list[str]]:
    """
    Score an article based on topic keyword matches.
    Returns (score, matched_topics).
    """
    text = (title + " " + (description or "")).lower()
    matched = []
    for topic, keywords in TOPIC_KEYWORDS.items():
        for kw in keywords:
            if kw.lower() in text:
                if topic not in matched:
                    matched.append(topic)
                break
    return len(matched), matched


def parse_published(entry) -> datetime:
    """Parse published date from a feedparser entry."""
    try:
        if hasattr(entry, "published_parsed") and entry.published_parsed:
            return datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
        if hasattr(entry, "updated_parsed") and entry.updated_parsed:
            return datetime(*entry.updated_parsed[:6], tzinfo=timezone.utc)
    except Exception:
        pass
    return datetime.now(timezone.utc)


def fetch_all_articles(max_age_days: int = 7, reference_date: Optional[datetime] = None) -> list[dict]:
    """
    Fetch articles from all configured RSS feeds.
    Returns a flat list of article dicts.

    reference_date: "now" anchor for the freshness cutoff — defaults to the
    real current time, but callers working on a past newsletter edition can
    pass that edition's date so freshness is judged relative to it instead.
    """
    cutoff = (reference_date or datetime.now(timezone.utc)) - timedelta(days=max_age_days)
    articles = []

    for feed_cfg in RSS_FEEDS:
        try:
            logger.info("Fetching %s", feed_cfg["name"])
            feed = feedparser.parse(feed_cfg["url"])
            for entry in feed.entries:
                pub = parse_published(entry)
                if pub < cutoff:
                    continue
                title = getattr(entry, "title", "") or ""
                url = getattr(entry, "link", "") or ""
                summary = getattr(entry, "summary", "") or ""
                if not url or not title:
                    continue
                # Strip HTML from summary
                summary_text = BeautifulSoup(summary, "html.parser").get_text(separator=" ")
                score, topics = score_article(title, summary_text)
                articles.append(
                    {
                        "title": title,
                        "url": url,
                        "summary": summary_text[:400],
                        "published": pub,
                        "source": feed_cfg["name"],
                        "score": score,
                        "topics": topics,
                        "image_url": None,
                    }
                )
        except Exception as exc:
            logger.warning("Failed to fetch feed %s: %s", feed_cfg["name"], exc)

    return articles


MAX_PER_SOURCE = 2


def select_top_articles(articles: list[dict], count: int = MARKET_NEWS_COUNT) -> list[dict]:
    """
    Select top N articles ensuring topic diversity and source diversity.
    Rules:
      - At most MAX_PER_SOURCE articles from the same source.
      - First pass: one best article per topic (respecting source cap).
      - Second pass: fill remaining slots by score/recency (respecting source cap).
    """
    relevant = [a for a in articles if a["score"] > 0]
    relevant.sort(key=lambda a: (a["score"], a["published"]), reverse=True)

    selected: list[dict] = []
    source_counts: dict[str, int] = {}

    def _under_cap(article: dict) -> bool:
        return source_counts.get(article["source"], 0) < MAX_PER_SOURCE

    def _pick(article: dict) -> None:
        selected.append(article)
        source_counts[article["source"]] = source_counts.get(article["source"], 0) + 1

    # First pass: best article per topic
    for topic in TOPIC_KEYWORDS.keys():
        if len(selected) >= count:
            break
        candidates = [
            a for a in relevant
            if topic in a["topics"] and a not in selected and _under_cap(a)
        ]
        if candidates:
            _pick(candidates[0])

    # Second pass: fill remaining slots
    for a in relevant:
        if len(selected) >= count:
            break
        if a not in selected and _under_cap(a):
            _pick(a)

    return selected[:count]


def _crop_and_save(image_url: str) -> Optional[str]:
    """
    Download *image_url*, center-square crop with slight top bias, resize to
    152×152, save as JPEG in the crops directory.
    Returns the local /crops/<name> path, or None on failure.
    """
    try:
        resp = requests.get(image_url, headers=HEADERS, timeout=10, verify=SSL_VERIFY)
        resp.raise_for_status()
        img = Image.open(io.BytesIO(resp.content)).convert("RGB")
        W, H = img.width, img.height
        side = min(W, H)
        left = (W - side) // 2
        top  = max(0, (H - side) // 4)   # slight top bias — captures subjects better
        cropped = img.crop((left, top, left + side, top + side)).resize(
            (152, 152), Image.Resampling.LANCZOS
        )
        _CROPS_DIR.mkdir(parents=True, exist_ok=True)
        fname = hashlib.md5(image_url.encode()).hexdigest()[:14] + ".jpg"
        cropped.save(_CROPS_DIR / fname, "JPEG", quality=85, optimize=True)
        return f"/crops/{fname}"
    except Exception as exc:
        logger.debug("Crop failed for %s: %s", image_url[:80], exc)
        return None


def enrich_with_images(articles: list[dict], delay: float = 0.3) -> list[dict]:
    """
    For each article without an image: fetch og:image, crop to 152×152 square,
    save locally and set image_url to the /crops/ path.
    """
    for article in articles:
        if not article.get("image_url"):
            raw_url = fetch_og_image(article["url"])
            if raw_url:
                article["image_url"] = _crop_and_save(raw_url) or raw_url
            time.sleep(delay)
        else:
            # Image URL already set (e.g. from RSS <media:content>) — still crop it
            cropped = _crop_and_save(article["image_url"])
            if cropped:
                article["image_url"] = cropped
    return articles


def get_market_news(reference_date: Optional[datetime] = None) -> list[dict]:
    """
    Main entry point: fetch, rank, select and enrich top market news articles.
    """
    logger.info("Fetching market news from RSS feeds…")
    articles = fetch_all_articles(reference_date=reference_date)
    logger.info("Total raw articles fetched: %d", len(articles))

    top = select_top_articles(articles)
    logger.info("Selected %d top articles, enriching with images…", len(top))

    enrich_with_images(top)
    return top
