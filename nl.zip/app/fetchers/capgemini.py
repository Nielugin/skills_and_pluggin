"""
Fetches the latest article from the Capgemini newsroom.
"""

import logging
from typing import Optional

import feedparser
import requests
from bs4 import BeautifulSoup

from config import CAPGEMINI_RSS, CAPGEMINI_NEWS_URL, SSL_VERIFY

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
}


def _fetch_article_details(url: str) -> dict:
    """Scrape title, og:image, og:description from an article page."""
    details: dict = {"image_url": None, "description": None, "title": None}
    try:
        resp = requests.get(url, headers=HEADERS, timeout=10, verify=SSL_VERIFY)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")

        og_title = soup.find("meta", property="og:title")
        if og_title and isinstance(og_title.get("content"), str):
            details["title"] = str(og_title["content"]).strip()

        og_img = soup.find("meta", property="og:image")
        if og_img and isinstance(og_img.get("content"), str):
            details["image_url"] = str(og_img["content"])

        og_desc = soup.find("meta", property="og:description") or soup.find(
            "meta", attrs={"name": "description"}
        )
        if og_desc and isinstance(og_desc.get("content"), str):
            details["description"] = str(og_desc["content"]).strip()
    except Exception as exc:
        logger.warning("Could not scrape Capgemini article %s: %s", url, exc)
    return details


def _try_rss() -> Optional[dict]:
    """Try fetching the latest Capgemini news from their RSS feed."""
    try:
        feed = feedparser.parse(CAPGEMINI_RSS)
        if feed.entries:
            entry = feed.entries[0]
            url = getattr(entry, "link", "")
            title = getattr(entry, "title", "")
            summary = getattr(entry, "summary", "")
            summary_text = BeautifulSoup(summary, "lxml").get_text(separator=" ").strip()
            details = _fetch_article_details(url)
            return {
                "title": details["title"] or title,
                "url": url,
                "summary": details["description"] or summary_text[:500],
                "image_url": details["image_url"],
                "source": "Capgemini",
            }
    except Exception as exc:
        logger.debug("Capgemini RSS failed: %s", exc)
    return None


def _try_scrape() -> Optional[dict]:
    """Scrape Capgemini newsroom page for the latest article."""
    try:
        resp = requests.get(CAPGEMINI_NEWS_URL, headers=HEADERS, timeout=10, verify=SSL_VERIFY)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "lxml")

        # Capgemini news listing — find first article card
        # Try common patterns used on capgemini.com
        article_link = None
        for selector in [
            "article a",
            ".news-card a",
            ".card a",
            '[class*="article"] a',
            '[class*="news"] a[href*="/news/"]',
        ]:
            tag = soup.select_one(selector)
            if tag and tag.get("href"):
                href = tag["href"]
                if not href.startswith("http"):
                    href = "https://www.capgemini.com" + href
                article_link = href
                break

        if not article_link:
            # Fallback: any link containing /news/ that isn't the listing itself
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if "/news/" in href and href != "/news/" and len(href) > 10:
                    if not href.startswith("http"):
                        href = "https://www.capgemini.com" + href
                    article_link = href
                    break

        if article_link:
            details = _fetch_article_details(article_link)
            return {
                "title": details["title"] or "Capgemini Latest News",
                "url": article_link,
                "summary": details["description"] or "",
                "image_url": details["image_url"],
                "source": "Capgemini",
            }
    except Exception as exc:
        logger.warning("Capgemini scrape failed: %s", exc)
    return None


def get_capgemini_news() -> Optional[dict]:
    """
    Return the latest Capgemini article dict, or None if unavailable.
    """
    logger.info("Fetching latest Capgemini news…")
    article = _try_rss()
    if article and article.get("title"):
        logger.info("Got Capgemini article via RSS: %s", article["title"])
        return article

    article = _try_scrape()
    if article and article.get("title"):
        logger.info("Got Capgemini article via scrape: %s", article["title"])
        return article

    logger.warning("Could not fetch Capgemini news")
    return None
