"""
Web search for article discovery.

Provider priority:
  1. Tavily Search API  — set TAVILY_API_KEY in .env  (recommended)
  2. DuckDuckGo HTML    — no key required, fallback
"""
import logging
import os
import urllib.parse
from typing import Optional

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
}

try:
    from config import SSL_VERIFY
except ImportError:
    SSL_VERIFY = True


# ── Public interface ──────────────────────────────────────────────────────────

def search_news(query: str, max_results: int = 5, days: int = 7) -> list[dict]:
    """
    Return up to *max_results* items as [{title, url, snippet}].
    Only returns articles published within the last *days* days.
    Tries Tavily first, then DuckDuckGo HTML.
    """
    tavily_key = os.getenv("TAVILY_API_KEY")
    if tavily_key:
        try:
            results = _tavily_search(query, tavily_key, max_results, days=days)
            if results:
                return results
        except (requests.exceptions.RequestException, ValueError, KeyError) as exc:
            logger.warning("Tavily search failed (%s) — falling back to DuckDuckGo", exc)

    return _ddg_search(query, max_results, days=days)


# ── Tavily ────────────────────────────────────────────────────────────────────

def _tavily_search(query: str, api_key: str, n: int, days: int = 7) -> list[dict]:
    resp = requests.post(
        "https://api.tavily.com/search",
        json={
            "api_key":        api_key,
            "query":          query,
            "max_results":    n,
            "search_depth":   "basic",
            "include_answer": False,
            "days":           days,
        },
        timeout=12,
        verify=SSL_VERIFY,
    )
    resp.raise_for_status()
    data = resp.json()
    return [
        {
            "title":   r.get("title", ""),
            "url":     r.get("url", ""),
            "snippet": r.get("content", ""),
        }
        for r in data.get("results", [])[:n]
        if r.get("url")
    ]


# ── DuckDuckGo HTML fallback ──────────────────────────────────────────────────

def _ddg_search(query: str, n: int, days: int = 7) -> list[dict]:
    # df=w → past week ; df=m → past month (DDG HTML parameter)
    df = "w" if days <= 7 else "m"
    try:
        resp = requests.post(
            "https://html.duckduckgo.com/html/",
            data={"q": query, "kl": "en-us", "df": df},
            headers=_HEADERS,
            timeout=12,
            verify=SSL_VERIFY,
        )
        resp.raise_for_status()
    except requests.exceptions.RequestException as exc:
        logger.error("DuckDuckGo search failed: %s", exc)
        return []

    soup = BeautifulSoup(resp.text, "html.parser")
    results: list[dict] = []

    for div in soup.select(".result"):
        a_title = div.select_one("a.result__a")
        snip_el = div.select_one(".result__snippet")
        if not a_title:
            continue
        url = _resolve_ddg_url(str(a_title.get("href", "")))
        if not url:
            continue
        results.append({
            "title":   a_title.get_text(strip=True),
            "url":     url,
            "snippet": snip_el.get_text(strip=True) if snip_el else "",
        })
        if len(results) >= n:
            break

    logger.info("DDG '%s' → %d results", query, len(results))
    return results


def _resolve_ddg_url(href: str) -> Optional[str]:
    if not href:
        return None
    if "duckduckgo.com/l/" in href:
        full = href if href.startswith("http") else "https:" + href
        qs   = urllib.parse.parse_qs(urllib.parse.urlparse(full).query)
        return qs.get("uddg", [None])[0]
    if href.startswith("http"):
        return href
    return None
