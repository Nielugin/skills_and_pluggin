"""
Checks Gmail INBOX for an edito e-mail matching the current newsletter.
Detection is based on the subject only (title + number) — the mail may be
a forward so the sender is not filtered.
"""
import email
import imaplib
import logging
import os
from datetime import datetime, timedelta
from email.header import decode_header
from email.message import Message
from typing import Optional

logger = logging.getLogger(__name__)

GMAIL_IMAP_HOST = "imap.gmail.com"
GMAIL_IMAP_PORT = 993


def _decode_str(raw) -> str:
    if raw is None:
        return ""
    parts = decode_header(str(raw))
    out = ""
    for fragment, charset in parts:
        if isinstance(fragment, bytes):
            out += fragment.decode(charset or "utf-8", errors="replace")
        else:
            out += str(fragment)
    return out


def _extract_body(msg: Message) -> tuple[str, str]:
    """Return (plain_text, html_text) from a Message."""
    plain, html = "", ""
    parts = list(msg.walk()) if msg.is_multipart() else [msg]
    for part in parts:
        ct = part.get_content_type()
        if "attachment" in str(part.get("Content-Disposition", "")):
            continue
        payload = part.get_payload(decode=True)
        if not isinstance(payload, bytes):
            continue
        charset = part.get_content_charset() or "utf-8"
        text = payload.decode(charset, errors="replace")
        if ct == "text/plain" and not plain:
            plain = text
        elif ct == "text/html" and not html:
            html = text
    return plain, html


def fetch_edito_email(
    newsletter_number: int,
    newsletter_title: str,
    lookback_days: int = 14,
) -> Optional[dict]:
    """
    Search Gmail INBOX for an e-mail whose subject contains both the
    newsletter title fragment and  #<number>.  The sender is not filtered
    (accepts forwards).

    Returns {from, subject, body_plain, body_html} or None.
    """
    gmail_user = os.getenv("GMAIL_USER")
    gmail_pass = os.getenv("GMAIL_APP_PASSWORD")
    if not gmail_user or not gmail_pass:
        logger.warning("Gmail credentials not configured — skipping edito mail check")
        return None

    since = (datetime.now() - timedelta(days=lookback_days)).strftime("%d-%b-%Y")

    # Build two complementary IMAP queries: one on title fragment, one on number.
    # We filter both conditions in Python after fetching candidates.
    title_word = newsletter_title.split()[0]          # e.g. "Capgemini"
    num_tag    = f"#{newsletter_number}"

    try:
        conn = imaplib.IMAP4_SSL(GMAIL_IMAP_HOST, GMAIL_IMAP_PORT)
        conn.login(gmail_user, gmail_pass)
        conn.select("INBOX")

        # Narrow server-side by number tag first (most selective)
        _, data = conn.search(None, f'SINCE "{since}" SUBJECT "{num_tag}"')
        ids = data[0].split() if (data and data[0]) else []

        # Also try searching by title word in case number format differs
        _, data2 = conn.search(None, f'SINCE "{since}" SUBJECT "{title_word}"')
        ids2 = data2[0].split() if (data2 and data2[0]) else []

        # Union of both result sets, most-recent first
        seen: set = set()
        combined = []
        for eid in list(reversed(ids)) + list(reversed(ids2)):
            if eid not in seen:
                seen.add(eid)
                combined.append(eid)

        for eid in combined:
            _, raw_data = conn.fetch(eid, "(RFC822)")
            if not (raw_data and raw_data[0] and isinstance(raw_data[0], tuple)):
                continue
            raw_bytes = raw_data[0][1]
            if not isinstance(raw_bytes, bytes):
                continue
            msg = email.message_from_bytes(raw_bytes)

            subject    = _decode_str(msg.get("Subject", ""))
            subj_lower = subject.lower()

            # Both fragments must appear in the subject
            if num_tag.lower() not in subj_lower:
                continue
            if title_word.lower() not in subj_lower:
                continue

            from_raw   = _decode_str(msg.get("From", ""))
            plain, htm = _extract_body(msg)
            conn.logout()

            logger.info("Edito email matched — from: %s | subject: %s", from_raw, subject)
            return {
                "from":       from_raw,
                "subject":    subject,
                "body_plain": plain,
                "body_html":  htm,
            }

        conn.logout()
        logger.info("No edito email found for '%s #%d'", newsletter_title, newsletter_number)
        return None

    except imaplib.IMAP4.error as exc:
        # Authentication / protocol error — surface explicitly
        raise RuntimeError(f"Erreur IMAP Gmail : {exc}") from exc
    except OSError as exc:
        raise RuntimeError(f"Impossible de joindre Gmail (réseau) : {exc}") from exc
