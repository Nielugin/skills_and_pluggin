"""
RSS feed sources and topic configuration for the newsletter generator.
"""

TOPICS = ["AI", "EV", "quantum", "robotics", "cloud", "venture", "energy", "industry"]

TOPIC_KEYWORDS = {
    "AI": [
        "artificial intelligence", "machine learning", "deep learning", "neural network",
        "LLM", "large language model", "GPT", "generative AI", "AI model", "chatbot",
        "computer vision", "NLP", "natural language", "OpenAI", "Anthropic", "Google AI",
        "Mistral", "Claude", "Gemini", "ChatGPT", "agentic", "foundation model",
    ],
    "EV": [
        "electric vehicle", "EV", "battery", "Tesla", "BYD", "charging", "lithium",
        "electric car", "electric truck", "electrification", "range", "kilowatt",
        "battery pack", "solid-state battery", "EV maker", "EV market",
    ],
    "quantum": [
        "quantum", "qubit", "quantum computing", "quantum processor", "entanglement",
        "superposition", "quantum error correction", "quantum supremacy",
        "IBM Quantum", "Google Quantum", "IonQ", "Rigetti",
    ],
    "robotics": [
        "robot", "robotics", "autonomous", "drone", "humanoid", "Boston Dynamics",
        "robotic arm", "automation", "self-driving", "autonomous vehicle",
        "AGV", "industrial robot",
    ],
    "cloud": [
        "cloud", "AWS", "Azure", "Google Cloud", "GCP", "Kubernetes", "serverless",
        "microservices", "SaaS", "PaaS", "IaaS", "data center", "cloud computing",
        "cloud infrastructure", "edge computing",
    ],
    "venture": [
        "venture capital", "startup", "funding", "series A", "series B", "IPO",
        "unicorn", "investment", "raise", "valuation", "seed round", "VC",
        "acquisition", "merger", "growth equity",
    ],
    "energy": [
        "energy", "solar", "wind power", "renewable", "nuclear", "hydrogen",
        "fusion", "grid", "power plant", "electricity", "carbon", "climate",
        "net zero", "sustainability", "green energy", "offshore wind",
    ],
    "industry": [
        "manufacturing", "supply chain", "semiconductor", "chip", "factory",
        "production", "industrial", "aerospace", "defense", "automotive",
        "pharma", "healthcare tech", "fintech", "digital transformation",
    ],
}

RSS_FEEDS = [
    # General tech
    {"url": "https://techcrunch.com/feed/", "name": "TechCrunch"},
    {"url": "https://www.theverge.com/rss/index.xml", "name": "The Verge"},
    {"url": "https://feeds.arstechnica.com/arstechnica/technology-lab", "name": "Ars Technica"},
    {"url": "https://www.wired.com/feed/rss", "name": "Wired"},
    {"url": "https://venturebeat.com/feed/", "name": "VentureBeat"},
    # Science & deep tech
    {"url": "https://feeds.feedburner.com/mit-technology-review", "name": "MIT Tech Review"},
    {"url": "https://interestingengineering.com/feed", "name": "Interesting Engineering"},
    # EV / energy
    {"url": "https://electrek.co/feed/", "name": "Electrek"},
    {"url": "https://cleantechnica.com/feed/", "name": "CleanTechnica"},
    # Business / venture
    {"url": "https://fortune.com/section/technology/feed/", "name": "Fortune Tech"},
    # Reuters tech
    {"url": "https://feeds.reuters.com/reuters/technologyNews", "name": "Reuters Technology"},
]

ADDITIONAL_ENG_FEEDS = [
    # Dev culture & high-signal tech
    {"url": "https://hnrss.org/frontpage", "name": "Hacker News"},
    {"url": "https://www.theregister.com/headless.xml", "name": "The Register"},
    {"url": "https://tldr.tech/tech/rss", "name": "TLDR Tech"},
    
    # Cyber security & AI
    {"url": "https://krebsonsecurity.com/feed/", "name": "Krebs on Security"},
    {"url": "https://www.schneier.com/feed/atom/", "name": "Schneier on Security"},
    {"url": "https://importai.substack.com/feed", "name": "Import AI"},
    
    # Global tech & European VC
    {"url": "https://sifted.eu/feed", "name": "Sifted (Euro Tech)"},
    {"url": "https://restofworld.org/feed/", "name": "Rest of World"}
]

RSS_FEEDS.extend(ADDITIONAL_ENG_FEEDS)

# Capgemini newsroom RSS (if available, else scrape)
CAPGEMINI_RSS = "https://www.capgemini.com/news/feed/"
CAPGEMINI_NEWS_URL = "https://www.capgemini.com/news/"

# Reuters YouTube channel
REUTERS_CHANNEL_ID = "UCGYXTBFeMBYhLRRnxazdIbw"

# Newsletter branding
NEWSLETTER_TITLE = "Capgemini Innovation Watch & Upcoming Trends"
NEWSLETTER_SUBTITLE = "Technology Weekly Digest"

# Number of market news articles to include
MARKET_NEWS_COUNT = 10

# Image display size (pixels, corresponds to ~4cm at 96dpi)
IMAGE_SIZE_PX = 152

# Set to False if you are behind a corporate proxy that intercepts SSL (e.g. Capgemini VPN)
# Can also be set via environment variable: SSL_VERIFY=false
import os as _os
SSL_VERIFY = _os.getenv("SSL_VERIFY", "true").lower() not in ("false", "0", "no")
