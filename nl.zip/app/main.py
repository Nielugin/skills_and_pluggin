"""
Newsletter Generator — main entry point.

Usage:
    python main.py [--number 541] [--no-email] [--preview]

Options:
    --number N    Newsletter edition number (default: read from .env or auto-increment)
    --no-email    Generate HTML only, do not send email
    --preview     Open the generated HTML in the default browser after generation
"""

import argparse
import logging
import os
import sys
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from paths import COUNTER_FILE, load_env

# Load .env before anything else
load_env()

from config import NEWSLETTER_TITLE, MARKET_NEWS_COUNT
from fetchers.news import get_market_news
from fetchers.capgemini import get_capgemini_news
from generator.html_gen import render_newsletter
from generator.emailer import send_newsletter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)



def read_counter() -> int:
    """Read the last used newsletter number from the counter file."""
    if COUNTER_FILE.exists():
        try:
            return int(COUNTER_FILE.read_text().strip())
        except ValueError:
            pass
    return 540


def write_counter(n: int) -> None:
    COUNTER_FILE.write_text(str(n))


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate the weekly technology newsletter")
    parser.add_argument("--number", type=int, help="Newsletter edition number")
    parser.add_argument("--no-email", action="store_true", help="Generate HTML only, skip email")
    parser.add_argument("--preview", action="store_true", help="Open HTML in browser after generation")
    args = parser.parse_args()

    # Determine edition number
    if args.number:
        newsletter_number = args.number
    elif os.getenv("NEWSLETTER_NUMBER"):
        newsletter_number = int(os.getenv("NEWSLETTER_NUMBER", "541"))
    else:
        newsletter_number = read_counter() + 1

    logger.info("=" * 60)
    logger.info("Generating %s #%d", NEWSLETTER_TITLE, newsletter_number)
    logger.info("=" * 60)

    # ── 1. Fetch market news ─────────────────────────────────────
    logger.info("\n[1/3] Fetching market technology news…")
    market_articles = get_market_news()
    logger.info("  → %d articles selected", len(market_articles))

    # ── 2. Fetch Capgemini news ──────────────────────────────────
    logger.info("\n[2/3] Fetching Capgemini news…")
    capgemini_article = get_capgemini_news()
    if capgemini_article:
        logger.info("  → %s", capgemini_article["title"])
    else:
        logger.warning("  → No Capgemini article found")

    # ── 3. Prepare Reuters example block ────────────────────────
    logger.info("\n[3/3] Preparing Reuters example block…")
    reuters_video = {
        "title": "Keep a look outside",
        "description": "Remplacez ce texte par votre résumé…",
        "video_url": "https://example.com",
        "thumbnail_url": "",
        "image_url": "",
    }
    logger.info("  → section Reuters initialisée avec un exemple éditable")

    # ── Render HTML ──────────────────────────────────────────────
    logger.info("\nRendering HTML newsletter…")
    html_path, html_content = render_newsletter(
        market_articles=market_articles,
        capgemini_article=capgemini_article,
        reuters_video=reuters_video,
        newsletter_number=newsletter_number,
        newsletter_title=NEWSLETTER_TITLE,
    )
    logger.info("  → Saved to: %s", html_path)

    # ── Send email ───────────────────────────────────────────────
    if not args.no_email:
        recipients_raw = os.getenv("EMAIL_RECIPIENTS", "")
        recipients = [r.strip() for r in recipients_raw.split(",") if r.strip()]
        if not recipients:
            logger.warning("EMAIL_RECIPIENTS not set — skipping email send")
        else:
            subject = f"{NEWSLETTER_TITLE} #{newsletter_number}"
            logger.info("\nSending newsletter to %d recipient(s)…", len(recipients))
            success = send_newsletter(html_content, subject, recipients)
            if success:
                logger.info("  → Email sent successfully!")
            else:
                logger.error("  → Email send failed (HTML file still saved)")

    # ── Update counter ───────────────────────────────────────────
    write_counter(newsletter_number)

    # ── Preview ──────────────────────────────────────────────────
    if args.preview:
        webbrowser.open(f"file:///{html_path.replace(chr(92), '/')}")

    logger.info("\nDone! Newsletter #%d complete.", newsletter_number)


if __name__ == "__main__":
    main()
