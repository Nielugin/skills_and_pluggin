"""Launch the Newsletter Generator web interface with startup checks."""
from __future__ import annotations

import importlib
import logging
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from paths import DATA_DIR, ENV_FILE, PLUGIN_ENV_FILE, load_env
load_env()

# Vérifie TLS avec le magasin de certificats de l'OS plutôt que le bundle certifi :
# un antivirus ou un proxy qui inspecte HTTPS (ex. Norton Web/Mail Shield) signe avec
# une racine connue de Windows mais absente de certifi (échec OAuth Google Drive).
try:
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass

# Lancé par scripts/nl.py (plugin) : l'accord pour installer les dépendances
# a déjà été demandé à l'utilisateur, start_web.py ne doit rien installer de lui-même.
NO_AUTO_INSTALL = os.getenv("NEWSLETTER_NO_AUTO_INSTALL") == "1"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%H:%M:%S",
    force=True,  # écrase tout handler déjà posé (par uvicorn ou une lib)
)


# ── Startup checks ────────────────────────────────────────────────────────────

def _missing_packages(packages: list[tuple[str, str]]) -> list[tuple[str, str]]:
    missing = []
    for mod, cmd in packages:
        try:
            importlib.import_module(mod)
        except ImportError:
            missing.append((mod, cmd))
    return missing


def _launch_ok() -> str | None:
    """Return the name of the first browser Playwright can launch, else None."""
    from playwright.sync_api import sync_playwright

    try:
        from generator.emailer import _BROWSER_CHANNELS as channels
    except ImportError:  # dépendance cassée : déjà signalée par la vérification des paquets
        channels = ["chrome", "msedge", None]

    with sync_playwright() as p:
        for channel in channels:
            try:
                p.chromium.launch(channel=channel, headless=True).close()
                return channel or "chromium"
            except Exception:  # noqa: BLE001 - channel unavailable, try next
                continue
    return None


def _check_pdf_browser() -> tuple[str, str, str]:
    """Ensure a browser is available for PDF generation; install Chromium if none is."""
    name = "navigateur PDF"
    found = _launch_ok()
    if found:
        return ("✅", name, found)
    if NO_AUTO_INSTALL:
        return ("⚠️ ", name, "aucun navigateur — PDF indisponible")

    print("  [PDF] Aucun navigateur trouvé — installation de Chromium (playwright)...")
    try:
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            check=True, timeout=600,
        )
    except (subprocess.SubprocessError, OSError):
        return ("⚠️ ", name, f"installez Chrome/Edge ou : {Path(sys.executable).name} -m playwright install chromium")

    found = _launch_ok()
    if found:
        return ("✅", name, f"{found} installé")
    return ("⚠️ ", name, "Chromium installé mais inutilisable — PDF indisponible")

def _check() -> bool:
    """
    Verify the environment before starting.
    Returns True if startup should proceed, False if a blocker was found.
    """
    results: list[tuple[str, str, str]] = []  # (icon, name, detail)

    # ── Configuration (plugin-config.env généré par le plugin, .env manuel) ───
    found = [f.name for f in (PLUGIN_ENV_FILE, ENV_FILE) if f.exists()]
    results.append(("✅" if found else "⚠️ ", "configuration",
                    ", ".join(found) if found else "aucune — configurer le plugin (/plugin)"))
    results.append(("·  ", "données", str(DATA_DIR)))

    results.append(("·  ", "Python", sys.executable))

    # ── Variables obligatoires ─────────────────────────────────────────────────
    # Le fournisseur LLM effectif (et sa clé requise) est résolu par
    # web.llm_client : LLM_PROVIDER explicite sinon, si les deux clés sont
    # renseignées, Anthropic par défaut ; sinon la clé disponible.
    from web import llm_client
    llm_provider = llm_client.PROVIDER
    if llm_provider == "openai":
        _required = {
            "OPENAI_API_KEY": "Clé OpenAI  →  platform.openai.com/api-keys",
        }
    else:
        _required = {
            "ANTHROPIC_API_KEY": "Clé Claude  →  console.anthropic.com",
        }
    _important = {
        "GMAIL_USER":         "Adresse Gmail pour l'envoi",
        "GMAIL_APP_PASSWORD": "myaccount.google.com/apppasswords",
        "EMAIL_RECIPIENTS":   "Destinataires de la newsletter",
    }
    _optional = {
        "TAVILY_API_KEY":          "Recherche web (fallback : DuckDuckGo)",
        "YOUTUBE_API_KEY":         "Reuters YouTube (fallback : scraping HTML)",
        "WHATSAPP_ALLOWED_NUMBERS":"Numéros autorisés WhatsApp",
        "WA_SERVICE_URL":          "URL du bridge Baileys (défaut : port 3001)",
    }

    for var, hint in _required.items():
        if os.getenv(var):
            results.append(("✅", var, "configuré"))
        else:
            results.append(("❌", var, f"REQUIS — {hint}"))

    for var, hint in _important.items():
        if os.getenv(var):
            results.append(("✅", var, "configuré"))
        else:
            results.append(("⚠️ ", var, f"non défini — {hint}"))

    for var, hint in _optional.items():
        if os.getenv(var):
            results.append(("✅", var, "configuré"))
        else:
            results.append(("·  ", var, f"optionnel — {hint}"))

    # ── Packages Python ────────────────────────────────────────────────────────
    _llm_package = ("openai", "pip install openai") if llm_provider == "openai" else ("anthropic", "pip install anthropic")
    _packages = [
        _llm_package,
        ("fastapi",    "pip install fastapi"),
        ("uvicorn",    "pip install uvicorn[standard]"),
        ("jinja2",     "pip install jinja2"),
        ("PIL.Image",  "pip install --force-reinstall Pillow"),
        ("bs4",        "pip install beautifulsoup4"),
        ("dotenv",     "pip install python-dotenv"),
        ("feedparser", "pip install feedparser"),
        ("requests",   "pip install requests"),
        ("playwright", "pip install playwright"),
    ]
    missing_pkgs = _missing_packages(_packages)

    if missing_pkgs and not NO_AUTO_INSTALL:
        print(f"  [pip] Paquets manquants ({', '.join(m for m, _ in missing_pkgs)}) "
              f"— installation via {sys.executable}...")
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")],
                check=True, timeout=900,
            )
        except (subprocess.SubprocessError, OSError):
            pass
        importlib.invalidate_caches()
        missing_pkgs = _missing_packages(_packages)

    if missing_pkgs:
        for mod, cmd in missing_pkgs:
            results.append(("❌", f"package {mod}", f"{Path(sys.executable).name} -m {cmd}"))
    else:
        results.append(("✅", "packages Python", "tous présents"))

    # ── Navigateur pour le PDF (Chrome / Edge / Chromium Playwright) ──────────
    if not any(mod == "playwright" for mod, _ in missing_pkgs):
        results.append(_check_pdf_browser())

    # ── Node.js (WhatsApp Baileys) ────────────────────────────────────────────
    try:
        out    = subprocess.check_output(["node", "--version"], stderr=subprocess.DEVNULL, timeout=5)
        ver    = out.decode().strip()           # e.g. "v22.3.0"
        major  = int(ver.lstrip("v").split(".")[0])
        if major >= 18:
            results.append(("✅", "Node.js", f"{ver} — bridge WhatsApp disponible"))
        else:
            results.append(("⚠️ ", "Node.js", f"{ver} détecté — v18+ requis  →  nodejs.org"))
    except (FileNotFoundError, subprocess.CalledProcessError, ValueError):
        results.append(("⚠️ ", "Node.js", "non installé — WhatsApp désactivé  →  nodejs.org"))

    # ── WhatsApp bridge reachable? ─────────────────────────────────────────────
    wa_url = os.getenv("WA_SERVICE_URL", "http://127.0.0.1:3001")
    try:
        import urllib.request
        urllib.request.urlopen(f"{wa_url}/status", timeout=2)
        results.append(("✅", "Bridge WhatsApp", f"en ligne  ({wa_url})"))
    except Exception:
        results.append(("·  ", "Bridge WhatsApp", "non démarré  (lancé par scripts/nl.py start)"))

    # ── Affichage ──────────────────────────────────────────────────────────────
    W = 38
    print()
    print("┌" + "─" * (W + 30) + "┐")
    title = "VERIFICATION DE L'ENVIRONNEMENT"
    print(f"│  {title:<{W + 28}}│")
    print("├" + "─" * (W + 30) + "┤")
    for icon, name, detail in results:
        line = f"  {icon}  {name:<{W}} {detail}"
        print(f"│{line:<{W + 29}}│")
    print("└" + "─" * (W + 30) + "┘")

    blockers = [r for r in results if r[0] == "❌"]
    warnings = [r for r in results if r[0].startswith("⚠")]

    if blockers:
        print(f"\n  🛑  {len(blockers)} erreur(s) bloquante(s) — démarrage annulé.\n")
        return False

    if warnings:
        print(f"\n  ⚠️   {len(warnings)} avertissement(s) — démarrage avec fonctionnalités limitées.\n")
    else:
        print()

    return True


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not _check():
        sys.exit(1)

    import uvicorn
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    print(f"  🚀  http://{host}:{port}\n")
    uvicorn.run(
        "web.server:app",
        host=host,
        port=port,
        reload=False,
        log_config=None,  # uvicorn ne configure pas le logging — notre basicConfig est seul maître
    )
