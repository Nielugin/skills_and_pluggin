#!/usr/bin/env bash
# Hook SessionStart du plugin nl.
#
# Recopie la configuration saisie dans Claude Code (userConfig du plugin, exportée
# en CLAUDE_PLUGIN_OPTION_<CLE>) dans ${CLAUDE_PLUGIN_DATA}/plugin-config.env, lu
# par le backend (app/paths.py). Chaque option porte le nom de la variable
# d'environnement attendue par l'app : anthropic_api_key → ANTHROPIC_API_KEY.
# Seules les valeurs non vides sont écrites, pour ne pas masquer un .env manuel.
#
# Bash pur (pas de Python requis) ; n'écrit rien sur stdout sauf un rappel
# quand l'environnement du plugin n'est pas encore installé.
set -u

data="${CLAUDE_PLUGIN_DATA:-}"
[ -n "$data" ] || exit 0
mkdir -p "$data" || exit 0

out="$data/plugin-config.env"
tmp="$out.tmp"
{
  echo "# Généré à chaque session par le plugin nl (scripts/sync-config.sh) — ne pas éditer."
  echo "# Modifier la configuration via /plugin → nl, ou ajouter des réglages dans .env."
  env | LC_ALL=C sort | while IFS= read -r line; do
    case "$line" in
      CLAUDE_PLUGIN_OPTION_*=*) ;;
      *) continue ;;
    esac
    key="${line%%=*}"
    key="${key#CLAUDE_PLUGIN_OPTION_}"
    val="${line#*=}"
    [ -n "$val" ] || continue
    val="${val//\\/\\\\}"
    val="${val//\'/\\\'}"
    printf "%s='%s'\n" "$key" "$val"
  done
} > "$tmp" && mv -f "$tmp" "$out"
chmod 600 "$out" 2>/dev/null

if [ ! -e "$data/venv/bin/python" ] && [ ! -e "$data/venv/bin/python.exe" ]; then
  echo "Plugin nl : environnement non installé. Pour l'utiliser, invoquer le skill nl:newsletter-server (action start) qui proposera l'installation, puis /mcp pour reconnecter le serveur newsletter."
fi
exit 0
