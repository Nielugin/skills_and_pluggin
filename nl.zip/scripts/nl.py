"""Lanceur autoporteur de la NL (backend FastAPI + bridge WhatsApp), embarqué dans le plugin.

Usage :  python nl.py [start|stop|status|restart|check] [--data DIR] [--install KEYS]
                      [--no-whatsapp] [--timeout N]

Le code vit dans <plugin>/app (lecture seule) ; tout ce qui est écrit à
l'exécution vit dans le dossier de données du plugin (--data, sinon
NEWSLETTER_DATA_DIR, sinon CLAUDE_PLUGIN_DATA) :

  venv/                    environnement Python dédié (venv/bin → venv/Scripts sous Windows)
  plugin-config.env        configuration saisie dans Claude Code (écrite par sync-config.sh)
  .env                     réglages complémentaires facultatifs
  output/                  éditions, images, logs, PID
  whatsapp-service/        node_modules + session WhatsApp (auth_info)

Non interactif : les processus sont détachés. Rien n'est installé sans accord :
`start` / `check` sortent avec le code 2 et listent ce qui manque ; une fois
l'accord obtenu, relancer avec `--install all` (ou `--install venv,pdf,...`,
ou `--install none` pour démarrer sans les dépendances optionnelles).
Stdlib uniquement : peut être lancé par n'importe quel Python 3.10+.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

PLUGIN_ROOT = Path(__file__).resolve().parents[1]
APP = PLUGIN_ROOT / "app"
WA_SRC = APP / "whatsapp-service"
EXIT_MISSING_DEPS = 2
IS_WIN = os.name == "nt"


def _data_dir(cli: str | None) -> Path:
    raw = cli or os.getenv("NEWSLETTER_DATA_DIR") or os.getenv("CLAUDE_PLUGIN_DATA")
    if not raw:
        sys.exit("❌ Dossier de données inconnu : passer --data \"${CLAUDE_PLUGIN_DATA}\".")
    return Path(raw).expanduser().resolve()


# Initialisés par _init() une fois les arguments lus.
DATA = LOG_DIR = PID_FILE = VENV = WA_DATA = Path()
HOST, PORT, WA_URL, BACKEND_URL = "127.0.0.1", 8000, "http://127.0.0.1:3001", ""


def _read_env_files() -> dict[str, str]:
    """Lecture minimale de plugin-config.env puis .env (le premier fichier prime)."""
    values: dict[str, str] = {}
    for name in (".env", "plugin-config.env"):
        path = DATA / name
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, val = line.partition("=")
                val = val.strip()
                if len(val) >= 2 and val[0] == val[-1] and val[0] in "'\"":
                    val = val[1:-1].replace("\\'", "'").replace("\\\\", "\\")
                if val:
                    values[key.strip()] = val
    return values


def _init(data: Path) -> None:
    global DATA, LOG_DIR, PID_FILE, VENV, WA_DATA, HOST, PORT, WA_URL, BACKEND_URL
    DATA = data
    DATA.mkdir(parents=True, exist_ok=True)
    LOG_DIR = DATA / "output" / "logs"
    PID_FILE = DATA / "output" / ".server_pids.json"
    VENV = DATA / "venv"
    WA_DATA = DATA / "whatsapp-service"
    env = _read_env_files()
    HOST = os.getenv("HOST") or env.get("HOST") or "127.0.0.1"
    PORT = int(os.getenv("PORT") or env.get("PORT") or "8000")
    WA_URL = os.getenv("WA_SERVICE_URL") or env.get("WA_SERVICE_URL") or "http://127.0.0.1:3001"
    BACKEND_URL = f"http://{'127.0.0.1' if HOST in ('0.0.0.0', '') else HOST}:{PORT}"


_DETACHED = (
    subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    if IS_WIN else 0
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if IS_WIN else "bin/python")


def _up(url: str, timeout: float = 2) -> bool:
    try:
        urllib.request.urlopen(url, timeout=timeout)
        return True
    except Exception:  # noqa: BLE001 - toute erreur = service indisponible
        return False


def _backend_up() -> bool:
    return _up(f"{BACKEND_URL}/api/newsletter/number")


def _wa_status() -> str | None:
    try:
        with urllib.request.urlopen(f"{WA_URL}/status", timeout=2) as r:
            return json.loads(r.read().decode()).get("status", "?")
    except Exception:  # noqa: BLE001
        return None


def _load_pids() -> dict[str, int]:
    try:
        return json.loads(PID_FILE.read_text())
    except (OSError, ValueError):
        return {}


def _save_pids(pids: dict[str, int]) -> None:
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(json.dumps(pids))


def _alive(pid: int) -> bool:
    if IS_WIN:
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                             capture_output=True, text=True).stdout
        return str(pid) in out
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _pid_on_port(port: int) -> int | None:
    if IS_WIN:
        out = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True).stdout
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 5 and parts[1].endswith(f":{port}") and parts[3] == "LISTENING":
                return int(parts[4])
        return None
    lsof = shutil.which("lsof")
    if not lsof:
        return None
    out = subprocess.run([lsof, "-ti", f"tcp:{port}", "-sTCP:LISTEN"], capture_output=True, text=True).stdout
    return int(out.split()[0]) if out.split() else None


def _kill(pid: int) -> None:
    if IS_WIN:
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)], capture_output=True)
    else:
        try:
            os.kill(pid, 15)
        except OSError:
            pass


def _tail(path: Path, n: int = 25) -> str:
    try:
        return "\n".join(path.read_text(encoding="utf-8", errors="replace").splitlines()[-n:])
    except OSError:
        return "(log vide)"


def _spawn(cmd: list[str], cwd: Path, log: Path, extra_env: dict[str, str] | None = None) -> int:
    log.parent.mkdir(parents=True, exist_ok=True)
    fh = open(log, "w", encoding="utf-8")
    env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8",
           "NEWSLETTER_NO_AUTO_INSTALL": "1", "NEWSLETTER_DATA_DIR": str(DATA),
           **(extra_env or {})}
    proc = subprocess.Popen(cmd, cwd=cwd, stdout=fh, stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL, env=env, creationflags=_DETACHED,
                            start_new_session=not IS_WIN)
    return proc.pid


def _run(cmd: list[str], cwd: Path | None = None, timeout: int = 1200) -> bool:
    print(f"   $ {' '.join(cmd)}", flush=True)
    try:
        # stdout du sous-processus redirigé sur stderr : quand le lanceur est
        # appelé par le serveur MCP, son propre stdout est capturé, jamais mêlé au protocole.
        return subprocess.run(cmd, cwd=cwd or DATA, timeout=timeout, stdout=sys.stderr,
                              stdin=subprocess.DEVNULL).returncode == 0
    except (subprocess.SubprocessError, OSError) as exc:
        print(f"   ✘ {exc}")
        return False


# ── Dépendances ───────────────────────────────────────────────────────────────

# Modules importés par le backend et le serveur MCP (cf. app/requirements.txt).
_PY_MODULES = [
    "feedparser", "requests", "bs4", "PIL", "jinja2", "dotenv", "lxml", "fastapi", "uvicorn",
    "anthropic", "openai", "websockets", "playwright", "mcp",
    "googleapiclient", "google.auth", "google_auth_oauthlib",
]


def _missing_python() -> list[str] | None:
    """Modules absents du venv ; None si le venv n'existe pas encore."""
    py = _venv_python()
    if not py.exists():
        return None
    code = ("import importlib.util as u, sys\n"
            "def ok(m):\n"
            "    try: return u.find_spec(m) is not None\n"
            "    except (ImportError, ValueError): return False\n"
            "print(','.join(m for m in sys.argv[1:] if not ok(m)))")
    try:
        out = subprocess.run([str(py), "-c", code, *_PY_MODULES], capture_output=True,
                             text=True, timeout=60).stdout.strip()
    except (subprocess.SubprocessError, OSError):
        return list(_PY_MODULES)
    return [m for m in out.split(",") if m]


def _pdf_browser() -> str | None:
    """Nom du premier navigateur que Playwright sait lancer (Chrome, Edge, Chromium), sinon None."""
    code = ("import sys; sys.path.insert(0, sys.argv[1]); from start_web import _launch_ok; "
            "print(_launch_ok() or '')")
    try:
        out = subprocess.run([str(_venv_python()), "-c", code, str(APP)], cwd=APP,
                             capture_output=True, text=True, timeout=120,
                             env={**os.environ, "NEWSLETTER_DATA_DIR": str(DATA)}).stdout
    except (subprocess.SubprocessError, OSError):
        return None
    lines = out.strip().splitlines()
    return lines[-1].strip() if lines and lines[-1].strip() else None


def _node() -> str | None:
    node = shutil.which("node")
    if not node and IS_WIN:
        default = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "nodejs"
        if (default / "node.exe").exists():
            os.environ["PATH"] += os.pathsep + str(default)
            node = shutil.which("node")
    return node


def _node_major() -> int | None:
    node = _node()
    if not node:
        return None
    try:
        ver = subprocess.check_output([node, "--version"], text=True, timeout=5).strip()
        return int(ver.lstrip("v").split(".")[0])
    except (subprocess.SubprocessError, OSError, ValueError):
        return None


def _npm_stale() -> bool:
    """Modules npm absents, ou package.json du plugin modifié depuis l'install."""
    if not (WA_DATA / "node_modules").exists():
        return True
    try:
        return (WA_DATA / "package.json").read_bytes() != (WA_SRC / "package.json").read_bytes()
    except OSError:
        return True


def detect_missing(with_whatsapp: bool) -> list[dict]:
    """Liste des dépendances manquantes : key, label, commande d'installation, bloquante ou non."""
    items: list[dict] = []
    py_missing = _missing_python()
    if py_missing is None or py_missing:
        what = ("environnement Python du plugin absent" if py_missing is None
                else f"paquets Python manquants : {', '.join(py_missing)}")
        items.append({
            "key": "venv", "blocking": True,
            "label": f"{what} — venv dans {VENV} + pip install -r requirements.txt (~300 Mo)",
            "cmd": f'"{sys.executable}" -m venv "{VENV}" && <venv python> -m pip install -r "{APP / "requirements.txt"}"',
        })
    if py_missing is None or "playwright" in py_missing:
        items.append({
            "key": "pdf", "blocking": False,
            "label": "Navigateur PDF : vérifié après l'install Python — Chromium (~150 Mo) "
                     "installé seulement si ni Chrome ni Edge ne sont utilisables",
            "cmd": "<venv python> -m playwright install chromium",
        })
    elif not _pdf_browser():
        items.append({
            "key": "pdf", "blocking": False,
            "label": "Aucun navigateur utilisable pour le PDF (Chrome/Edge/Chromium) — "
                     "envoi de la NL impossible sans lui",
            "cmd": "<venv python> -m playwright install chromium",
        })
    if with_whatsapp:
        major = _node_major()
        if major is None or major < 18:
            what = "absent" if major is None else f"v{major} trop ancien (v18+ requis)"
            cmd = ("winget install OpenJS.NodeJS.LTS --silent --accept-package-agreements "
                   "--accept-source-agreements") if IS_WIN else "installer Node.js 18+ (https://nodejs.org)"
            items.append({"key": "node", "blocking": False,
                          "label": f"Node.js {what} — nécessaire au bridge WhatsApp", "cmd": cmd})
        if _npm_stale():
            items.append({
                "key": "npm", "blocking": False,
                "label": f"Modules npm du bridge WhatsApp absents ou périmés ({WA_DATA / 'node_modules'})",
                "cmd": f'npm install (dans "{WA_DATA}")',
            })
    return items


def _base_python() -> str:
    """Python système servant à créer le venv (jamais le Python du venv lui-même)."""
    return getattr(sys, "_base_executable", None) or sys.executable


def _install_venv() -> bool:
    py = _venv_python()
    if not py.exists():
        if not _run([_base_python(), "-m", "venv", str(VENV)]):
            return False
    if IS_WIN and not (VENV / "bin").exists():
        # Chemin unique pour .mcp.json : ${CLAUDE_PLUGIN_DATA}/venv/bin/python sur tous les OS.
        subprocess.run(["cmd", "/c", "mklink", "/J", str(VENV / "bin"), str(VENV / "Scripts")],
                       capture_output=True)
    _run([str(py), "-m", "pip", "install", "--upgrade", "pip", "--quiet"])
    return _run([str(py), "-m", "pip", "install", "-r", str(APP / "requirements.txt")])


def _install_npm() -> bool:
    npm = shutil.which("npm") or (shutil.which("npm.cmd") if IS_WIN else None)
    if not npm:
        print("   ✘ npm introuvable (Node.js requis)")
        return False
    WA_DATA.mkdir(parents=True, exist_ok=True)
    for name in ("package.json", "package-lock.json"):
        if (WA_SRC / name).exists():
            shutil.copyfile(WA_SRC / name, WA_DATA / name)
    return _run([npm, "install", "--omit=dev", "--no-audit", "--no-fund"], cwd=WA_DATA)


def install(keys: set[str], with_whatsapp: bool) -> None:
    """Installe les dépendances manquantes dont la clé est dans `keys` (ou toutes si 'all')."""
    wanted = lambda k: "all" in keys or k in keys  # noqa: E731
    for key in ["venv", "pdf", "node", "npm"]:
        # Détection refaite à chaque étape : l'install Python révèle l'état du navigateur PDF,
        # celle de Node rend npm disponible.
        item = next((i for i in detect_missing(with_whatsapp) if i["key"] == key), None)
        if not item or not wanted(key):
            continue
        if key == "pdf" and "playwright" in (_missing_python() or ["playwright"]):
            print("·  Navigateur PDF non vérifié : paquets Python absents.")
            continue
        print(f"📦 {item['label']}", flush=True)
        if key == "venv":
            ok = _install_venv()
        elif key == "pdf":
            ok = _run([str(_venv_python()), "-m", "playwright", "install", "chromium"])
        elif key == "node":
            winget = shutil.which("winget") if IS_WIN else None
            ok = bool(winget) and _run([winget, *item["cmd"].split()[1:]])
            if not winget:
                print("   ✘ installation automatique indisponible — installer Node.js 18+ "
                      "depuis https://nodejs.org")
            _node()
        else:
            ok = _install_npm()
        print(f"   {'✅ installé' if ok else '❌ échec'}", flush=True)


def _report(items: list[dict]) -> None:
    print("\n🔎 Dépendances manquantes (rien n'a été installé) :")
    for i in items:
        flag = "BLOQUANT " if i["blocking"] else "optionnel"
        print(f"   [{i['key']:<6}] {flag} — {i['label']}\n            → {i['cmd']}")
    print(f"\nACCORD REQUIS : relancer avec --install all (ou --install "
          f"{','.join(i['key'] for i in items)} / --install none).")
    print("DEPS_JSON " + json.dumps(items, ensure_ascii=False))


# ── Actions ───────────────────────────────────────────────────────────────────

def start_whatsapp(pids: dict[str, int]) -> None:
    if _wa_status() is not None:
        print(f"✅ Bridge WhatsApp déjà en ligne ({WA_URL}) — statut : {_wa_status()}")
        return
    node = _node() if (_node_major() or 0) >= 18 else None
    if not node or not (WA_DATA / "node_modules").exists():
        print("⚠️  Bridge WhatsApp non démarré (Node.js v18+ et modules npm requis).")
        return
    log = LOG_DIR / "whatsapp.log"
    port = WA_URL.rsplit(":", 1)[-1].split("/")[0]
    pids["whatsapp"] = _spawn([node, str(WA_SRC / "index.js")], WA_DATA, log, {
        "NODE_PATH": str(WA_DATA / "node_modules"),
        "WA_AUTH_DIR": str(WA_DATA / "auth_info"),
        "WA_SERVICE_PORT": port,
        "PYTHON_INTERNAL_URL": BACKEND_URL,
    })
    for _ in range(20):
        if _wa_status() is not None:
            break
        time.sleep(0.5)
    status = _wa_status()
    if status is None:
        print(f"⚠️  Bridge WhatsApp lancé mais injoignable — voir {log}")
    else:
        hint = f"  → scanner le QR : {BACKEND_URL}/setup/whatsapp" if status == "qr" else ""
        print(f"✅ Bridge WhatsApp démarré ({WA_URL}) — statut : {status}{hint}")


def start_backend(pids: dict[str, int], timeout: int) -> bool:
    if _backend_up():
        print(f"✅ Backend déjà en ligne — {BACKEND_URL}")
        return True
    if not any((DATA / f).exists() for f in ("plugin-config.env", ".env")):
        print("❌ Aucune configuration : renseigner les clés dans la configuration du plugin "
              "(/plugin → nl → Configure), puis relancer une session Claude Code.")
        return False
    log = LOG_DIR / "backend.log"
    pid = _spawn([str(_venv_python()), str(APP / "start_web.py")], APP, log)
    pids["backend"] = pid
    print(f"·  Backend en cours de démarrage (PID {pid}, log : {log})...", flush=True)
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _backend_up():
            print(f"✅ Backend en ligne — {BACKEND_URL}")
            return True
        if not _alive(pid):
            print(f"❌ Le backend s'est arrêté au démarrage. Fin du log :\n{_tail(log)}")
            pids.pop("backend", None)
            return False
        time.sleep(1)
    print(f"⚠️  Backend toujours pas joignable après {timeout}s. Fin du log :\n{_tail(log)}")
    return False


def _parse_keys(raw: str | None) -> set[str] | None:
    return None if raw is None else {k.strip() for k in raw.split(",") if k.strip()}


def check(args: argparse.Namespace) -> int:
    items = detect_missing(not args.no_whatsapp)
    if items:
        _report(items)
        return EXIT_MISSING_DEPS
    print("✅ Toutes les dépendances sont présentes.")
    return 0


def start(args: argparse.Namespace) -> int:
    print(f"Code    : {APP}\nDonnées : {DATA}")
    with_wa = not args.no_whatsapp
    keys = _parse_keys(args.install)
    if not _backend_up():
        items = detect_missing(with_wa)
        if items and keys is None:
            _report(items)
            return EXIT_MISSING_DEPS
        if items and keys is not None and keys - {"none"}:
            install(keys, with_wa)
        blocking = [i for i in detect_missing(with_wa) if i["blocking"]]
        if blocking:
            print(f"❌ Démarrage impossible : {blocking[0]['label']}")
            return 1
    pids = {k: v for k, v in _load_pids().items() if _alive(v)}
    if with_wa:
        start_whatsapp(pids)
    ok = start_backend(pids, args.timeout)
    _save_pids(pids)
    if ok:
        print(f"\n   Interface  > {BACKEND_URL}\n   WhatsApp   > {BACKEND_URL}/setup/whatsapp")
    return 0 if ok else 1


def stop(_args: argparse.Namespace) -> int:
    pids = _load_pids()
    ports = {"backend": PORT, "whatsapp": int(WA_URL.rsplit(":", 1)[-1].split("/")[0])}
    for name, port in ports.items():
        pid = pids.get(name) if pids.get(name) and _alive(pids[name]) else _pid_on_port(port)
        if pid:
            _kill(pid)
            print(f"🛑 {name} arrêté (PID {pid})")
        else:
            print(f"·  {name} n'était pas lancé")
    PID_FILE.unlink(missing_ok=True)
    return 0


def status(_args: argparse.Namespace) -> int:
    up = _backend_up()
    print(f"Données : {DATA}")
    print(f"{'✅' if up else '❌'} Backend  : {BACKEND_URL} — {'en ligne' if up else 'arrêté'}")
    wa = _wa_status()
    print(f"{'✅' if wa else '·  '} WhatsApp : {WA_URL} — {wa or 'arrêté'}")
    return 0 if up else 1


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("action", nargs="?", default="start",
                        choices=["start", "stop", "status", "restart", "check"])
    parser.add_argument("--data", metavar="DIR", help="dossier de données du plugin (${CLAUDE_PLUGIN_DATA})")
    parser.add_argument("--install", metavar="KEYS",
                        help="accord donné : all, none, ou liste parmi venv,pdf,node,npm")
    parser.add_argument("--no-whatsapp", action="store_true", help="ne pas lancer le bridge WhatsApp")
    parser.add_argument("--timeout", type=int, default=240, help="attente max du backend (s)")
    args = parser.parse_args()
    _init(_data_dir(args.data))
    if args.action == "restart":
        stop(args)
        time.sleep(1)
        return start(args)
    return {"start": start, "stop": stop, "status": status, "check": check}[args.action](args)


if __name__ == "__main__":
    sys.exit(main())
